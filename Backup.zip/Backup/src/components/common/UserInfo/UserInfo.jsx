import React, { Component } from "react";
import "./userinfo.scss";
import { getUser,setUserName } from "../../../actions/userActions";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { Menu, Dropdown } from "antd";
import { Link } from "react-router-dom";

const propTypes = {
  getUser: PropTypes.func,
  userReducer: PropTypes.shape({
    user: PropTypes.any,
    username: PropTypes.string
  }),
  setUserName: PropTypes.func
};

class UserInfo extends Component {

  constructor() {
    super();
  }
  menu = (
    <Menu className="dropdown-profile">
      <Menu.Item key="0">
        <Link to="/profile">Profile</Link>
      </Menu.Item>
    </Menu>
  );

  toogleDropdown() {
    let el = document.getElementById("dropdown");
    let className = el.className;
    if (className === "user-dropdown hide-dropdown") {
      el.className = "user-dropdown show-dropdown";
    } else {
      el.className = "user-dropdown hide-dropdown";
    }
  }
  render() {
    return (
      <div className="user-info">
        { this.props.userReducer && this.props.userReducer.user &&  this.props.userReducer.user.data &&
          <Dropdown overlay={this.menu} trigger={["click"]}>
          <a className="ant-dropdown-link" href="#">
            <img
              className=""
              src={
                this.props.userReducer.user
                  ? this.props.userReducer.user.data.focusPerson.badge_image_url
                  : ""
              }
            />
          </a>
        </Dropdown>}
      </div>
    );
  }
}

UserInfo.propTypes = propTypes;

const mapStateToProps = (state) => {
  return {
    userReducer: state.user
  };
};
const matchDispatchToProps = (dispatch) => {
  return bindActionCreators(
    {
      getUser,
      setUserName
    },
    dispatch
  );
};

export default connect(mapStateToProps, matchDispatchToProps)(UserInfo);

import React, { Component } from "react";
import { Select, Spin } from "antd";
import PropTypes from "prop-types";
import debounce from "lodash/debounce";
import axios from "axios";
import Config from "../../../config/Config";
import _ from "underscore";

const conf = new Config();
const Option = Select.Option;

class UserAutoComplete extends Component {
  constructor(props) {
    super(props);
    this.lastFetchId = 0;
    this.fetchUser = debounce(this.fetchUser, 800);
  }

  state = {
    data: [],
    fetching: false
  };

  fetchUser = e => {
    this.setState({ data: [], fetching: true });

    axios({
      ...conf.getUserList,
      data: {
        category: "USERS",
        pattern: e,
        pageNumber: 1,
        pageSize: 10
      }
    }).then(resp => {
      const data = resp.data.data.autoSuggestResponse.map(user => ({
        text: `${user.label}`,
        value: {
          id: user.id,
          email: user.emailAddress
        }
      }));
      this.setState({ data, fetching: false });
    });
  };

  constructUserList = ps => {
    let arr = [];
    _.each(ps, obj => {
      arr.push({
        label: obj.MT[0].V,
        id: obj.MT[1].V,
        text: obj.MT[2].V
      });
    });
    return arr;
  };

  handleChange = value => {
    this.setState({
      fetching: false,
      data: []
    });
    value = JSON.parse(value);
    this.props.onChange(value);
  };

  render() {
    const { fetching, data } = this.state;
    return (
      <Select
        showSearch
        value={this.props.value ? this.props.value : "Select User"}
        placeholder={"Search user"}
        notFoundContent={fetching ? <Spin size="small" /> : null}
        filterOption={false}
        onSearch={e => this.fetchUser(e)}
        onChange={this.handleChange}
        style={{ width: "100%" }}
      >
        {data.map(d => (
          <Option key={JSON.stringify(d)}>{d.text}</Option>
        ))}
      </Select>
    );
  }
}

UserAutoComplete.propTypes = {
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired
};

export default UserAutoComplete;

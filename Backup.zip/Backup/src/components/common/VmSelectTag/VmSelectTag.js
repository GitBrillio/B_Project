import React, { Component } from "react";
import { Select } from "antd";
import "./VmSelectTag.scss";
import PropTypes from "prop-types";

const Option = Select.Option;

const propTypes = {
  options: PropTypes.array,
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
  id: PropTypes.string,
  value: PropTypes.string,
  default: PropTypes.string,
  defaultValue: PropTypes.string
};

export default class VmSelectTag extends Component {
  render() {
    return (
      <div className="selectTags">
        <Select
          mode="tags"
          className={this.props.className}
          defaultValue = {this.props.options}
          style={{ width: '100%' }}
          placeholder={this.props.placeholder}
          onChange={(e)=>{
            this.props.onChange(e);
          }}
        >
          {this.props.options &&
            this.props.options.map((opt, index) => (
              <Option value={opt} key={index}>
                {opt}
              </Option>
            ))}
        </Select>
        <label>{this.props.placeholder}</label>
      </div>
    );
  }
}

VmSelectTag.propTypes = propTypes;

import React, { Component } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend, Tooltip } from 'recharts';
import PropTypes from "prop-types";
import CustomizedLabel from "./CustomizedLabel";
import CustomTooltip from "./CustomizedTooltip";
import _ from 'underscore';
import { KMB } from '../../../../Services/Common';
const propTypes = {
  width: PropTypes.number,
  barSize: PropTypes.number,
  data: PropTypes.array,
  xAxisLabel: PropTypes.string,
  yAxisLabel: PropTypes.string,
  barBackgound: PropTypes.object
};

const colors = ["#8ee35f", "#ffb7a8", "#25ffc4", "#ff8073", "#ffea63", "#66c1ff", "#ffb5e8", "#8ee39f", "#7bd743", "#8377d9"];


export default class StackedBarChrt extends Component {

  getColor(arr) {

    let keys = [];
    let index;
    _.each(arr, (o, i) => {
      keys = keys.concat(Object.keys(o))
    });

    let uniq = _.uniq(keys);
    if (uniq.includes('year')) {
      index = _.findIndex(uniq, (o) => o === 'year');
    }
    else {
      index = _.findIndex(uniq, (o) => o === 'quarter');
    }
    uniq.splice(index, 1);


    return uniq;
  }

  KMB(labelValue) {

    // Nine Zeroes for Billions
    return Math.abs(Number(labelValue)) >= 1.0e+9

      ? (Number(labelValue)) / 1.0e+9 + "B"
      // Six Zeroes for Millions 
      : Math.abs(Number(labelValue)) >= 1.0e+6

        ? (Number(labelValue)) / 1.0e+6 + "M"
        // Three Zeroes for Thousands
        : Math.abs(Number(labelValue)) >= 1.0e+3

          ? (Number(labelValue)) / 1.0e+3 + "K"

          : Math.abs(Number(labelValue));

  }


  render() {
    const arr = [...this.props.barBackgound.data]
    const data = arr.splice(0, this.props.barBackgound.data.length - 1);
    console.log(this.getColor(this.props.data));
    return (
      <div>
        {this.props.data && this.props.data.length > 0 &&
          <BarChart width={this.props.width} height={300} data={this.props.data} margin={{ left: 20, bottom: 15 }} >
            <CartesianGrid strokeDasharray="0.5" />
            <XAxis dataKey={this.props.data[0].hasOwnProperty('year') ? "year" : "quarter"} />
            <YAxis tickFormatter={(item) => this.KMB(item)} />
            <Legend iconType="circle" iconSize="10" verticalAlign="bottom" height={36} align="left" />
            <Tooltip cursor={{ fill: "rgb(247, 241, 241)" }} labelStyle={{ textAlign: 'center' }} />
            {this.props.data && this.props.data.length > 0 &&
              this.getColor(this.props.data).map((info, index) => (
                <Bar
                  key={index}
                  dataKey={info}
                  stackId="a"
                  barSize={this.props.barSize}
                  radius={index === this.getColor(this.props.data).length - 1 && [8, 8, 0, 0]}
                  label={index === this.getColor(this.props.data).length - 1 && <CustomizedLabel x={this.props.x} y={this.props.y} fill={this.props.fill} value={this.props.value} />}
                  fill={colors[index]} />
              ))
            }
          </BarChart>
        }
      </div>
    );
  }
}

StackedBarChrt.propTypes = propTypes;

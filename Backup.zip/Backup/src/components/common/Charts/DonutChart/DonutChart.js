import React, { Component } from "react";

import { PieChart, Pie, Cell } from "recharts";

class DonutChart extends Component {
  render() {
    return (
      <div>
        <PieChart width={800} height={400} onMouseEnter={this.onPieEnter} className="pie-chart-container">
          <Pie
            data={this.props.data}
            cx={120}
            cy={200}
            innerRadius={60}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
          >
            {this.props.data.map((entry, index) => (
              <Cell fill={this.props.colors[index]} key={index} />
            ))}
          </Pie>
        </PieChart>
      </div>
    );
  }
}

export default DonutChart;

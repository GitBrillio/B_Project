import React from 'react';
import PropTypes from "prop-types";
import './HeaderInfo.scss'
import { Progress } from 'antd';    

const HeaderInfo = ({ accounts,percent,status}) => {

    return (
        <div className="header-container">
           <div className="accounts-cont">
               <span>{accounts.join(" » ")}</span>
           </div>
           <div>
            {/* <button className="save-btn" type="button">Save</button> 
            <button className="submit-btn" type="button">Submit</button> */}
           </div>
           <div className="progress-container">
               {/* <div className="percent"><span>{percent}</span>%</div>
               <div className="progressbar-details">
                   <span className="status">{status}</span>
                   <Progress percent={percent} />
               </div> */}
               
           </div>
        </div>
    );
};

HeaderInfo.propTypes = {
    accounts: PropTypes.array,
    percent:PropTypes.number,
    status:PropTypes.string
};
export default HeaderInfo;

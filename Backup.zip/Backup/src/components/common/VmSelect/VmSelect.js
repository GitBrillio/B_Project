import React, { Component } from "react";
import { Select } from "antd";
import "./VmSelect.scss";
import PropTypes from "prop-types";

const Option = Select.Option;

const propTypes = {
  options: PropTypes.array,
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
  id: PropTypes.string,
  value: PropTypes.string,
  default: PropTypes.string,
  defaultValue: PropTypes.string,
  disabled: PropTypes.bool
};

export default class VmSelect extends Component {
  render() {
    return (
      <div className="vm-select-floating-label">
        <Select
          className="input-select"
          placeholder={this.props.placeholder}
          disabled={this.props.disabled}
          defaultValue = {this.props.defaultValue ? this.props.defaultValue : [] }
          onChange={(e)=>{
            this.props.onChange(e);
          }}
        >
          {this.props.options &&
            this.props.options.map((opt, index) => (
              <Option value={opt[this.props.id]} key={index}>
                {opt[this.props.value]}
              </Option>
            ))}
        </Select>
        <label>{this.props.label}</label>
      </div>
    );
  }
}

VmSelect.propTypes = propTypes;

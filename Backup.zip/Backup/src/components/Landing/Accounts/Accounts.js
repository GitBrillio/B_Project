import React, { Component } from 'react';
import './accounts.scss';
import PropTypes from 'prop-types';
import Account from './Account/Account';
import Close from './Close.svg';
import { Popover, Row, Col } from 'antd';
import _ from 'underscore';
const pt = {
    accounts: PropTypes.array.isRequired,
    actions: PropTypes.any,
    selectedAccountIndex: PropTypes.number,
    selectedAccount: PropTypes.object
}

class Accounts extends Component {
    constructor() {
        super();
        this.state = {
            isSearchFieldOpened: true,
            searchedText: "",
        }
    }
    changeSearchText(e) {
        this.setState({
            searchedText: e.target.value
        })
    }
    clearOrCloseEventHandler() {
        this.setState({ searchedText: "", isSearchFieldOpened: !this.state.isSearchFieldOpened });
        //this.props.landingAction.changeSearchText("");
    }


    filter = (name) => {
        // let finalArr = _.filter(this.props.accounts,(o)=>{
        //     return o.accountName.indexOf(this.state.searchedText) >=0 
        // })
        _.mixin({

            like: function (text, likeExpr) {
                var regex = new RegExp(text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&'), 'i');
                return regex.test(likeExpr);
            }

        });

        let finalArr = _.filter(this.props.accounts, (o) => {
            return _.like(this.state.searchedText, o.accountName);
        });

        //this.props.accounts.filter((o)=>o.accountName.indexOf(this.state.searchedText) >=0 );
        let displayArr = [];
        for (let i = 0; i < finalArr.length; i++) {
            displayArr.push(
                <Account
                    selected={this.props.selectedAccountIndex}
                    index={i}
                    key={i}
                    account={finalArr[i]}
                    actions={this.props.actions}
                    selectAccount={this.props.selectAccount}
                />

            )
        }
        return displayArr;
    }
    render = () => {
        const { accounts, selectedAccountIndex, actions } = this.props
        return (
            <div className="accounts">
                <div className="Allaccounts" >
                    {this.state.isSearchFieldOpened ? <div onClick={() => { this.setState({ isSearchFieldOpened: false }) }} className="account">
                        <span className="account-lenght-text"> YOUR ACCOUNTS </span>
                        <div className="account-filter-div">
                            <clr-icon shape="filter" class="filter-icn" onClick={() =>
                                this.state.isSearchFieldOpened ?
                                    this.setState({ isSearchFieldOpened: false }) : this.setState({ isSearchFieldOpened: true })}></clr-icon>
                            {/* <img 	src= {filter} /> */}
                        </div>
                    </div> :
                        <div className="account input-field-bgcolor">
                            <input autoFocus className="Input" type="search" onChange={this.changeSearchText.bind(this)} placeholder="Type your keyword" value={this.state.searchedText} />
                            <div className="close-img">
                                <img onClick={() => this.clearOrCloseEventHandler()} src={Close} className="acc-search-close-img" />
                            </div>
                        </div>}
                </div>
                <div className="custom-scroll account-list">
                    {
                        // accounts.map((account,index)=><Account 
                        //     selected={selectedAccountIndex} 
                        //     index={index} 
                        //     key={index} 
                        //     account={account} 
                        //     actions={actions}
                        // />)
                        this.filter()
                    }
                </div>
            </div>
        )
    }
}
Accounts.propTypes = pt;
export default Accounts;
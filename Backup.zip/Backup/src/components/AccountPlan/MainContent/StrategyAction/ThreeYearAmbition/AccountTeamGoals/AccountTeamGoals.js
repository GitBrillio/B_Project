import React, { Component } from 'react';
import { Collapse, Button, Row, Col } from 'antd'; //Input
import PropTypes from 'prop-types';
import './account-team-goals.scss';
import Goal from './Goal/Goal';
const Panel = Collapse.Panel;

class AccountTeamGoals extends Component {
    state = {
        stategyActions: {
            threeYearAmbition: []
        },
        clicked: false
    }

    changeClick() {
        this.setState({ clicked: false });
    }

    render() {
        return (
            <Collapse defaultActiveKey={['1']} className="account-team-goals">
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Account Team’s Goals</span>
                </div>} key="1">
                    <section>
                        {
                            this.props.goalPlan.length == 0 ?
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-30 text-center">
                                    <Button className="dashed-button" type="dashed" onClick={() => this.props.actions.addMoreGoal()}>Add Goal</Button>
                                </div>
                                :
                                <Row className="goal-area">
                                    <Col span={24}>
                                        {this.props.goalPlan.map((goal, index) => (
                                            <Goal
                                                key={index}
                                                index={index}
                                                actions={this.props.actions}
                                                teamGoal={goal}
                                                accountPlanId={this.props.accountPlanId}
                                                accountTeamGoalId ={this.props.accountTeamGoalId}
                                                goalPlan = {this.props.goalPlan}
                                            />
                                        ))}
                                    </Col>
                                    <div className="col-lg-12 add-more plr0" onClick={() => this.props.actions.addMoreGoal()} >
                                        + Add Another
                                    </div>
                                </Row>

                        }
                    </section>
                </Panel>
            </Collapse>

        )
    }
}

AccountTeamGoals.propTypes = {
    actions: PropTypes.object,
    goalPlan: PropTypes.any,
    accountPlanId: PropTypes.string,
    accountTeamGoalId: PropTypes.string
}


export default AccountTeamGoals;
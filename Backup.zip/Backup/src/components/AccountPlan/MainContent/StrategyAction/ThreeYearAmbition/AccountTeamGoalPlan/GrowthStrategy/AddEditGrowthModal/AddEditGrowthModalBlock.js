import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Row, Col, Icon } from 'antd';
// import VmFloatingInput from '../../../../../../../common/VmFloatingInput/VmFloatingInput';
// import VmTextareaMaterial from '../../../../../../../common/VmTextarea/VmTextareaMaterial';
import Input from 'muicss/lib/react/input';
import './g-s-modal-block.scss';


class AddEditGrowthModalBlock extends Component {

    getKeyTheme() {
        let value;
        this.props.ambition.ambitionPlan !== null ? value = this.props.ambition.ambitionPlan.keyTheme : value = null;
        return value;
    }
    getTargetValue() {
        let value;
        this.props.ambition.ambitionPlan !== null ? value = this.props.ambition.ambitionPlan.targetValue : value = null;
        return value;
    }
    TargetValueCheck(e) {
        const re = /^[0-9\b]+$/;
        if (e.target.value === '' || re.test(e.target.value)) {
            //this.setState({value: e.target.value})
            this.props.actions.changeTargetValue(e.target.value, this.props.index)
        }
    }

    render = () => {
        return (
            <div>
                <Row gutter={16} className="growth-strategy-block-main">
                    <Col className="gutter-row" span={13}>
                        <Input
                            label={"Enter Key Theme/Solution"}
                            floatingLabel={true}
                            value={this.getKeyTheme()}
                            onChange={(e) => {
                                this.props.actions.changeKeyTheme(e.target.value, this.props.index)
                            }}
                        />
                    </Col>
                    <Col className="gutter-row" span={10}>
                        <Input
                            label={"Enter Target Value (USD)"}
                            floatingLabel={true}
                            value={this.getTargetValue()}
                            //onChange={(e)=>this.props.actions.changeTargetValue(e.target.value,this.props.index)}
                            onChange={(e) => this.TargetValueCheck(e)}
                        />
                    </Col>
                    <Col className="gutter-row" span={24}>

                        <ul className="list-style">
                            {this.props.ambition.ambitionPlan && this.props.ambition.ambitionPlan.growthStrategy && this.props.ambition.ambitionPlan.growthStrategy.length > 0 &&
                                this.props.ambition.ambitionPlan.growthStrategy.map((g, index) => (
                                <li key={index}>
                                    <div>
                                        <div className="width-97" style={{ padding: '0 0 0 4px' }}>
                                            <Input
                                                label={`Growth Strategy ${index + 1}`}
                                                value={g}
                                                floatingLabel={true}
                                                onChange={(e) => this.props.actions.changeGrowthStrategy(e.target.value, this.props.index, index)}
                                            />
                                        </div>
                                        <div className="width-3" style={{ marginTop: 18 }}>
                                            <Icon className="minus-circle" type="minus-circle-o" onClick={() => this.props.actions.deleteElement(this.props.index, index)} />
                                        </div>
                                    </div>
                                </li>
                            ))}
                        </ul>

                    </Col>
                </Row>


            </div>
        )
    }
}

AddEditGrowthModalBlock.propTypes = {
    actions: PropTypes.object,
    strategyReducer: PropTypes.object,
    ambition: PropTypes.any,
    index: PropTypes.any
}

export default AddEditGrowthModalBlock;
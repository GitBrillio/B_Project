import React,{Component} from 'react';
import './search-and-filter.scss';
import filterImg  from './filter.png';
import { Icon } from 'antd';
import PropTypes from 'prop-types';
import Filter from './Filter/filter';
import {filter} from 'lodash';
import _ from 'underscore';

class SearchAndFilter extends Component{
    state={
        filterStatus:false,
        detailsData:{}
    }
    filterOpenOrClosed(val){
        this.setState({filterStatus:val})
    }
    show=()=>{
        this.setState({
            filterStatus:true
        })
    }
 
    render(){
        return( 
                <div className="search">
                    <Icon className="icon-style" type="search" size={32}/>
                    <input type="text" 
                        placeholder="Search Opportunities" 
                        onChange={(e)=>{
                            this.props.actions.searchOpportunities(e)
                        }} 
                    />
                    <button className="button" onClick={this.show}><img src={filterImg} width="14px"/>Filter</button>
                    {
                        this.state.filterStatus && 
                        this.props.keyOpportunitiesReducer && <Filter 
                            actions={this.props.actions}
                            handlefilterStatus={(data)=>this.filterOpenOrClosed(data)}
                            keyOpportunitiesReducer = {this.props.keyOpportunitiesReducer}
                        />
                    }
                </div>
           
        )
    }
}
SearchAndFilter.propTypes = {
    actions: PropTypes.object,
    keyOpportunitiesReducer: PropTypes.object
}
export default SearchAndFilter;
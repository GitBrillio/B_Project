import React,{ Component } from 'react';
import './heading.scss';
import PropTypes from 'prop-types';
import Details from '../Details/details';

class Heading extends Component{
    render(){
        const {opportunity,headerText} = this.props;
        return(
                opportunity.length !== 0 && <div className="p-18">
                    <h4 className="headstyle"><span>Opportunities for </span>{headerText}</h4>
                    {
                        opportunity && opportunity.map((op,i)=>
                            <Details 
                                key={i} 
                                oppDetails = {op}
                            />
                        )
                    }

                </div>
        )
    }
}
Heading.propTypes = {
    headerText : PropTypes.string,
    opportunity: PropTypes.array
}
export default Heading;
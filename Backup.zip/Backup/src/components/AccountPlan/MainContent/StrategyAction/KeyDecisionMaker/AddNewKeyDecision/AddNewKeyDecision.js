import React, { Component } from "react";
import PropTypes from "prop-types";
import { Modal, Layout, Button, Row, Col, Select, DatePicker } from "antd";
const { Content } = Layout;
import Input from "muicss/lib/react/input";
import "./AddNewKeyDecision.scss";
import moment from "moment";
import VmSelect from "../../../../../common/VmSelect/VmSelect";
import InputDate from "../InputDate/InputDate";

const Option = Select.Option;
export default class AddNewKeyDecision extends Component {
  render = () => {
    const children = [];
    this.props.keydecisionReducer.vmwareSolutions.map((vmSolution, index) =>
      children.push(
        <Option key={index} value={vmSolution.label}>
          {" "}
          {vmSolution.label}
        </Option>
      )
    );
    // for (let i = 10; i < 36; i++) {
    //   children.push(<Option key={i.toString(36) + i}>{i.toString(36) + i}</Option>);
    // }
    return (
      <div>
        <Modal
          className="add-edit-focus-popup"
          title="Create New Key Decision Maker Coverage"
          visible={this.props.visible}
          centered
          onCancel={() => this.props.handleCancel()}
          footer={[
            <Button
              key="submit"
              disabled={
                this.props.keydecisionReducer.keydecision[this.props.index].capKeyDecisionMakerBody.kdmName === ""
              }
              className="submit-btn"
              type="primary"
              onClick={() => this.props.ok()}
            >
              {this.props.keydecisionReducer.keydecision[this.props.index].capKeyDecisionMakerBody.kdmId !== null
                ? "Update"
                : "Create"}
            </Button>
          ]}
        >
          <section className="add-key-makers">
            <Layout>
              <Content>
                <Row gutter={24}>
                  <Col span={12}>
                    <Input
                      label={"KEY DECISION MAKER*"}
                      floatingLabel={true}
                      autoComplete="off"
                      onChange={e => this.props.actions.changeKdmName(e.target.value, this.props.index)}
                      value={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmName}
                    />
                  </Col>
                  <Col span={12}>
                    <Row gutter={24} className="key-align">
                      <Col span={8}>
                        <VmSelect
                          label={"ROLE"}
                          // label={false}
                          value="label"
                          id="id"
                          placeholder={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmRoleValue}
                          options={this.props.keydecisionReducer.roledropdown}
                          onChange={e => {
                            this.props.actions.changekdmRole(this.props.index, e);
                          }}
                        />
                      </Col>
                      <Col span={8}>
                        <VmSelect
                          label={"TYPE"}
                          // label={false}
                          value="label"
                          id="id"
                          placeholder={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmTypeValue}
                          options={this.props.keydecisionReducer.typedropdown}
                          onChange={e => {
                            this.props.actions.changekdmType(this.props.index, e);
                          }}
                        />
                      </Col>
                      <Col span={8}>
                        <VmSelect
                          label={"EVP"}
                          // label={false}
                          value="label"
                          id="id"
                          placeholder={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.evpValue}
                          options={this.props.keydecisionReducer.evpdropdown}
                          onChange={e => {
                            this.props.actions.changekdmEvp(this.props.index, e);
                          }}
                        />
                      </Col>
                    </Row>
                  </Col>
                </Row>
                <Row gutter={24} className="customer-strategic">
                  <Col span={12}>
                    <Input
                      label={"CUSTOMER STRATEGIC INITIATIVE (BUSINESS ISSUES)"}
                      floatingLabel={true}
                      autoComplete="off"
                      onChange={e => this.props.actions.changeCustomerInitiative(e.target.value, this.props.index)}
                      value={
                        this.props.keydecision[this.props.index].capKeyDecisionMakerBody.customerStrategicInitiative
                      }
                    />
                  </Col>
                  <Col span={12}>
                    <label className="vmware-label">VMWARE SOLUTION</label>
                    <Select
                      mode="tags"
                      style={{ width: "100%" }}
                      placeholder="VMWARE SOLUTION"
                      defaultValue={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.vmwareSolution}
                      onChange={e => {
                        console.log(e);
                        this.props.actions.changeVmwareSolutions(this.props.index, e);
                      }}
                    >
                      {children}
                    </Select>
                  </Col>
                </Row>
                <Row gutter={24} className="target-outcome">
                  <Col span={20}>
                    <Input
                      label={"TARGET OUTCOME"}
                      floatingLabel={true}
                      autoComplete="off"
                      onChange={e => this.props.actions.changeTargetOutcome(e.target.value, this.props.index)}
                      value={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.targetOutcome}
                    />
                  </Col>
                  <Col span={4}>
                    <label className="vmware-label">DATE</label>
                    <DatePicker
                      format={"YYYY-MM-DD"}
                      onChange={(date, dateString) => {
                        this.props.actions.changekdmDate(dateString, this.props.index);
                      }}
                      value={
                        this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmDate == "" ||
                        this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmDate == null
                          ? ""
                          : moment(
                              this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmDate,
                              "YYYY-MM-DD"
                            )
                      }
                    />
                  </Col>
                </Row>

                {this.props.keydecisionReducer.keydecision[this.props.index].capKeyDecisionMakerBody.kdmId !== null ? (
                  <div>
                    <p className="Engagement-by-Quarte">Engagement by Quarter</p>
                    <Row gutter={24}>
                      <Col span={6}>
                        <p className="Quater">Quarter 1</p>

                        {this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters.hasOwnProperty(
                          "1"
                        ) &&
                          this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters[1].map(
                            (qe1, innerIndex) => {
                              return (
                                <InputDate
                                  qeName={qe1.qeName}
                                  qeDate={qe1.qeDate}
                                  kdmQuarter="1"
                                  groupByQuarters={
                                    this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters
                                  }
                                  actions={this.props.actions}
                                  index={this.props.index}
                                  innerIndex={innerIndex}
                                  kdmId={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmId}
                                />
                              );
                            }
                          )}

                        <button
                          className="add-more"
                          onClick={() => this.props.actions.addkdmQuater(this.props.index, "1")}
                        >
                          + Add Another{" "}
                        </button>
                      </Col>

                      <Col span={6}>
                        <p className="Quater">Quarter 2</p>
                        {this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters.hasOwnProperty(
                          "2"
                        ) &&
                          this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters[2].map(
                            (qe1, innerIndex) => {
                              return (
                                <InputDate
                                  qeName={qe1.qeName}
                                  qeDate={qe1.qeDate}
                                  kdmQuarter="2"
                                  groupByQuarters={
                                    this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters
                                  }
                                  actions={this.props.actions}
                                  index={this.props.index}
                                  innerIndex={innerIndex}
                                  kdmId={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmId}
                                />
                              );
                            }
                          )}
                        <button
                          className="add-more"
                          onClick={() => this.props.actions.addkdmQuater(this.props.index, "2")}
                        >
                          + Add Another{" "}
                        </button>
                      </Col>
                      <Col span={6}>
                        <p className="Quater">Quarter 3</p>
                        {this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters.hasOwnProperty(
                          "3"
                        ) &&
                          this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters[3].map(
                            (qe1, innerIndex) => {
                              return (
                                <InputDate
                                  qeName={qe1.qeName}
                                  qeDate={qe1.qeDate}
                                  kdmQuarter="3"
                                  groupByQuarters={
                                    this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters
                                  }
                                  actions={this.props.actions}
                                  index={this.props.index}
                                  innerIndex={innerIndex}
                                  kdmId={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmId}
                                />
                              );
                            }
                          )}
                        <button
                          className="add-more"
                          onClick={() => this.props.actions.addkdmQuater(this.props.index, "3")}
                        >
                          + Add Another{" "}
                        </button>
                      </Col>
                      <Col span={6}>
                        <p className="Quater">Quarter 4</p>
                        {this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters.hasOwnProperty(
                          "4"
                        ) &&
                          this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters[4].map(
                            (qe1, innerIndex) => {
                              return (
                                <InputDate
                                  qeName={qe1.qeName}
                                  qeDate={qe1.qeDate}
                                  kdmQuarter="4"
                                  actions={this.props.actions}
                                  groupByQuarters={
                                    this.props.keydecisionReducer.keydecision[this.props.index].groupByQuarters
                                  }
                                  index={this.props.index}
                                  innerIndex={innerIndex}
                                  kdmId={this.props.keydecision[this.props.index].capKeyDecisionMakerBody.kdmId}
                                />
                              );
                            }
                          )}
                        <button
                          className="add-more"
                          onClick={() => this.props.actions.addkdmQuater(this.props.index, "4")}
                        >
                          + Add Another{" "}
                        </button>
                      </Col>
                    </Row>
                  </div>
                ) : null}
              </Content>
            </Layout>
          </section>
        </Modal>
      </div>
    );
  };
}

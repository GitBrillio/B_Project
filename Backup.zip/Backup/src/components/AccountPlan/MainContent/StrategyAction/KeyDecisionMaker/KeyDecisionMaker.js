import React, { Component } from "react";
import { Layout } from "antd";
import moment from "moment";
import Input from "muicss/lib/react/input";
import "./KeyDecisionMaker.scss";
const { Content } = Layout;
import trash from "../../../../../images/trash.svg";
import { Button, Collapse, Row, Col, Icon, DatePicker } from "antd";
const Panel = Collapse.Panel;
import AddNewKeyDecision from "./AddNewKeyDecision/AddNewKeyDecision";
import DeleteFocusArea from "./DeleteFocusArea/DeleteFocusArea";

export default class KeyDecisionMaker extends Component {
  state = {
    showCreateArea: false,
    index: null,
    confirmDelete: false,
    deleteContent: null
  };

  componentDidMount() {
    this.props.actions.fetchKeyDecision(this.props.accountPlanId);
    this.props.actions.fetchRoleDropdown(this.props.accountPlanId);
    this.props.actions.fetchTypeDropdown(this.props.accountPlanId);
    this.props.actions.fetchEvpDropdown(this.props.accountPlanId);
    this.props.actions.fetchVmwareSolutions(this.props.accountPlanId);
  }

  addNewKeyDecision() {
    this.setState({
      showCreateArea: true,
      index:
        this.props.keydecisionReducer.keydecision.length > 0
          ? this.props.keydecisionReducer.keydecision.length
          : 0
    });
    this.props.actions.addKeyDecisionfeild();
  }
  handlecreateKDM() {
    let data = {
      kdmId: this.props.keydecisionReducer.keydecision[this.state.index]
        .capKeyDecisionMakerBody.kdmId,
      kdmName: this.props.keydecisionReducer.keydecision[this.state.index]
        .capKeyDecisionMakerBody.kdmName,
      kdmRoleId: this.props.keydecisionReducer.keydecision[this.state.index]
        .capKeyDecisionMakerBody.kdmRoleId,
      kdmTypeId: this.props.keydecisionReducer.keydecision[this.state.index]
        .capKeyDecisionMakerBody.kdmTypeId,
      evpId: this.props.keydecisionReducer.keydecision[this.state.index]
        .capKeyDecisionMakerBody.evpId,
      customerStrategicInitiative: this.props.keydecisionReducer.keydecision[
        this.state.index
      ].capKeyDecisionMakerBody.customerStrategicInitiative,
      vmwareSolution: this.props.keydecisionReducer.keydecision[
        this.state.index
      ].capKeyDecisionMakerBody.vmwareSolution,
      targetOutcome: this.props.keydecisionReducer.keydecision[this.state.index]
        .capKeyDecisionMakerBody.targetOutcome,
      kdmDate: this.props.keydecisionReducer.keydecision[this.state.index]
        .capKeyDecisionMakerBody.kdmDate,
      accountPlanId: this.props.accountPlanId
    };
    this.props.actions.createKDM(data, this.state.index);
    this.setState({
      showCreateArea: false
    });
  }
  handleCancel() {
    this.setState({
      showCreateArea: false
    });
    this.props.actions.checkKeyDecision(this.state.index);
  }

  handleDelete() {
    let capKeyDecisionMakerBody = this.props.keydecisionReducer.keydecision[
      this.state.index
    ].capKeyDecisionMakerBody;
    this.props.actions.deleteKdm(capKeyDecisionMakerBody, this.state.index);
    this.setState({
      confirmDelete: false
    });
  }

  ConfHandleCancel() {
    this.setState({ confirmDelete: false });
  }

  render = () => {
    const store = this.props.keydecisionReducer;
    return (
      <section className="keyDecisionMaker">
        <Layout>
          <Content style={{ padding: 24, margin: 0 }}>
            <h3 className="Strategy-Actions">Strategy & Actions</h3>
            <h1 className="Key-Decision-Maker">Key Decision Maker Coverage</h1>
            {store.keydecision.length == 0 ? (
              <div className="key-decision">
                <button
                  className="dashed-btn"
                  type="dashed"
                  onClick={() => this.addNewKeyDecision()}
                >
                  Create New Key Decision Maker Coverage
                </button>
              </div>
            ) : (
              <div>
                <button
                  className="create-newkeydecision"
                  onClick={() => this.addNewKeyDecision()}
                >
                  Create New Key Decision Maker Coverage
                </button>
                {store.keydecision.map((keydecision, index) => (
                  <Collapse defaultActiveKey={["1"]}>
                    <Panel
                      header={
                        <div className="collapse-main">
                          <span className="collapse-header">
                            Key Decision Maker :{" "}
                            {keydecision.capKeyDecisionMakerBody.kdmName}
                          </span>
                        </div>
                      }
                      key={index + 1}
                    >
                      <div>
                        <Row className="select-row">
                          <Col span={12} className="customer-initiative">
                            Customer Strategic Initiative (Business Issues)
                            <p className="capdecision">
                              {
                                keydecision.capKeyDecisionMakerBody
                                  .customerStrategicInitiative
                              }
                            </p>
                          </Col>
                          <Col span={12}>
                            <Row>
                              <Col span={8} className="select-col">
                                Role
                                <p className="capdecision">
                                  {
                                    keydecision.capKeyDecisionMakerBody
                                      .kdmRoleValue
                                  }
                                </p>
                              </Col>
                              <Col span={8} className="select-col">
                                Type
                                <p className="capdecision">
                                  {
                                    keydecision.capKeyDecisionMakerBody
                                      .kdmTypeValue
                                  }
                                </p>
                              </Col>
                              <Col span={8} className="select-col">
                                eVP
                                <p className="capdecision">
                                  {keydecision.capKeyDecisionMakerBody.evpValue}
                                </p>
                              </Col>
                            </Row>
                          </Col>
                        </Row>
                        <Row className="select-row">
                          <Col span={12}>
                            <Row>
                              <Col span={12} className="customer-initiative">
                                VMware Solution
                                <div className="solutions">
                                  {keydecision.capKeyDecisionMakerBody
                                    .vmwareSolution &&
                                    keydecision.capKeyDecisionMakerBody.vmwareSolution.map(
                                      (vmsolution, index) => (
                                        <span className="vmware-solutions">
                                          {vmsolution}
                                        </span>
                                      )
                                    )}
                                </div>
                              </Col>
                              <Col span={12} className="customer-initiative">
                                Traget Outcome
                                <p className="capdecision">
                                  {keydecision.capKeyDecisionMakerBody
                                    .kdmDate !== null &&
                                  keydecision.capKeyDecisionMakerBody
                                    .targetOutcome != "" &&
                                  keydecision.capKeyDecisionMakerBody
                                    .targetOutcome != null
                                    ? `${
                                        keydecision.capKeyDecisionMakerBody
                                          .targetOutcome
                                      }(${
                                        keydecision.capKeyDecisionMakerBody
                                          .kdmDate
                                      })`
                                    : keydecision.capKeyDecisionMakerBody
                                        .targetOutcome != null
                                    ? keydecision.capKeyDecisionMakerBody
                                        .targetOutcome
                                    : ""}
                                </p>
                              </Col>
                            </Row>
                          </Col>
                        </Row>
                        {Object.keys(keydecision.groupByQuarters).length !==
                        0 ? (
                          <div className="engagement">
                            <h3 className="Engagement-by-Quarte">
                              Engagement-by-Quarter
                            </h3>
                            <Row>
                              <Col span={6}>
                                <p className="Quater">Quarter 1</p>
                                {keydecision.groupByQuarters.hasOwnProperty(
                                  "1"
                                ) &&
                                  keydecision.groupByQuarters[1].map(
                                    (q1, innerIndex) => {
                                      return (
                                        <p className="quater-text">
                                          {q1.qeDate != null &&
                                          q1.qeDate != "" &&
                                          q1.qeName != "" &&
                                          q1.qeName != null
                                            ? `${q1.qeName}(${q1.qeDate})`
                                            : q1.qeName != null
                                            ? q1.qeName
                                            : ""}
                                        </p>
                                      );
                                    }
                                  )}
                              </Col>
                              <Col span={6}>
                                <p className="Quater">Quarter 2</p>
                                {keydecision.groupByQuarters.hasOwnProperty(
                                  "2"
                                ) &&
                                  keydecision.groupByQuarters[2].map(
                                    (q1, innerIndex) => {
                                      return (
                                        <p className="quater-text">
                                          {q1.qeDate != null &&
                                          q1.qeDate != "" &&
                                          q1.qeName != "" &&
                                          q1.qeName != null
                                            ? `${q1.qeName}(${q1.qeDate})`
                                            : q1.qeName != null
                                            ? q1.qeName
                                            : ""}
                                        </p>
                                      );
                                    }
                                  )}
                              </Col>
                              <Col span={6}>
                                <p className="Quater">Quarter 3</p>
                                {keydecision.groupByQuarters.hasOwnProperty(
                                  "3"
                                ) &&
                                  keydecision.groupByQuarters[3].map(
                                    (q1, innerIndex) => {
                                      return (
                                        <p className="quater-text">
                                          {q1.qeDate != null &&
                                          q1.qeDate != "" &&
                                          q1.qeName != "" &&
                                          q1.qeName != null
                                            ? `${q1.qeName}(${q1.qeDate})`
                                            : q1.qeName != null
                                            ? q1.qeName
                                            : ""}
                                        </p>
                                      );
                                    }
                                  )}
                              </Col>
                              <Col span={6}>
                                <p className="Quater">Quarter 4</p>
                                {keydecision.groupByQuarters.hasOwnProperty(
                                  "4"
                                ) &&
                                  keydecision.groupByQuarters[4].map(
                                    (q1, innerIndex) => {
                                      return (
                                        <p className="quater-text">
                                          {q1.qeDate != null &&
                                          q1.qeDate != "" &&
                                          q1.qeName != "" &&
                                          q1.qeName != null
                                            ? `${q1.qeName}(${q1.qeDate})`
                                            : q1.qeName != null
                                            ? q1.qeName
                                            : ""}
                                        </p>
                                      );
                                    }
                                  )}
                              </Col>
                            </Row>
                            <div className="button-wrap">
                              <button
                                className="edit-button"
                                onClick={() =>
                                  this.setState({
                                    index: index,
                                    showCreateArea: true
                                  })
                                }
                              >
                                Edit
                              </button>

                              <div
                                className="delete-icon"
                                onClick={() =>
                                  this.setState({
                                    confirmDelete: true,
                                    deleteContent:
                                      keydecision.capKeyDecisionMakerBody
                                        .kdmName,
                                    index: index
                                  })
                                }
                              >
                                <img
                                  src={trash}
                                  title="Delete mission critical system"
                                  alt="Delete System"
                                />
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="btn-wrap">
                            <button
                              className="edit-button"
                              onClick={() =>
                                this.setState({
                                  index: index,
                                  showCreateArea: true
                                })
                              }
                            >
                              Edit
                            </button>

                            <div
                              className="delete-icon"
                              onClick={() =>
                                this.setState({
                                  confirmDelete: true,
                                  deleteContent:
                                    keydecision.capKeyDecisionMakerBody.kdmName,
                                  index: index
                                })
                              }
                              // onClick={() => this.props.actions.deleteKdm(keydecision.capKeyDecisionMakerBody, index)}
                            >
                              <img
                                src={trash}
                                title="Delete mission critical system"
                                alt="Delete System"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </Panel>
                  </Collapse>
                ))}
              </div>
            )}
            {this.state.showCreateArea ? (
              <AddNewKeyDecision
                visible={this.state.showCreateArea}
                handleCancel={() => this.handleCancel()}
                actions={this.props.actions}
                index={this.state.index}
                ok={() => this.handlecreateKDM()}
                keydecisionReducer={this.props.keydecisionReducer}
                accountPlanId={this.props.accountPlanId}
                keydecision={store.keydecision}
              />
            ) : null}
            {this.state.confirmDelete ? (
              <DeleteFocusArea
                heading="Delete Key Decision Maker"
                visible={this.state.confirmDelete}
                ok={() => this.handleDelete()}
                cancel={() => this.ConfHandleCancel()}
                okText="Yes, Delete It"
                cancelText="Cancel, Keep It"
                contents={`Are you sure you want to delete the Key Decision Maker?`}
              />
            ) : null}
          </Content>
        </Layout>
      </section>
    );
  };
}

import React, { Component } from "react";
import PropTypes from "prop-types";
import { Modal, Layout, Button, Row, Col, Select, DatePicker, Icon } from "antd";
const { Content } = Layout;
import moment from "moment";
import Input from "muicss/lib/react/input";
import "./InputDate.scss";
import UserAutoComplete from "../../../../../common/UserAutoComplete/UserAutoComplete";

export default class InputDate extends Component {
  selectUser(value) {
    this.props.actions.changeQuaterValue(value.text, this.props.kdmQuarter, this.props.index, this.props.innerIndex);
    this.props.actions.createUpdateKdmQuaters(
      {
        qeId: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeId,
        qeName: value.text,
        emailAddress: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].emailAddress,
        qeDate: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeDate,
        kdmQuarter: this.props.kdmQuarter,
        kdmId: this.props.kdmId
      },
      this.props.index,
      this.props.innerIndex
    );
  }

  render = () => {
    return (
      <section className="input-date">
        <Layout>
          <Content>
            <Row gutter={24} className="input-style">
              <Col span={10}>
                <label className="vmware-label">NAME</label>

                <UserAutoComplete
                  value={this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeName}
                  onChange={value => {
                    this.selectUser(value);
                  }}
                />
              </Col>
              <Col span={10} className="date-picker">
                <label className="vmware-label">DATE</label>
                <DatePicker
                  format={"YYYY-MM-DD"}
                  value={
                    this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeDate == "" ||
                    this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeDate == null
                      ? ""
                      : moment(
                          this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeDate,
                          "YYYY-MM-DD"
                        )
                  }
                  onChange={(date, dateString) => {
                    this.props.actions.changeQeDate(
                      dateString,
                      this.props.kdmQuarter,
                      this.props.index,
                      this.props.innerIndex
                    );
                    this.props.actions.createUpdateKdmQuaters(
                      {
                        qeId: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeId,
                        qeName: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeName,
                        emailAddress: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex]
                          .emailAddress,
                        qeDate: dateString,
                        kdmQuarter: this.props.kdmQuarter,
                        kdmId: this.props.kdmId
                      },
                      this.props.index,
                      this.props.innerIndex
                    );
                  }}
                />
              </Col>
              <Col span={4}>
                <div
                  className="delete-action"
                  onClick={() =>
                    this.props.actions.deleteKdmQuater(
                      {
                        qeId: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeId,
                        qeName: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeName,
                        emailAddress: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex]
                          .emailAddress,
                        qeDate: this.props.groupByQuarters[this.props.kdmQuarter][this.props.innerIndex].qeDate,
                        kdmQuarter: this.props.kdmQuarter,
                        kdmId: this.props.kdmId
                      },
                      this.props.index,
                      this.props.innerIndex
                    )
                  }
                >
                  <Icon type="minus-circle-o" />
                </div>
              </Col>
            </Row>
          </Content>
        </Layout>
      </section>
    );
  };
}

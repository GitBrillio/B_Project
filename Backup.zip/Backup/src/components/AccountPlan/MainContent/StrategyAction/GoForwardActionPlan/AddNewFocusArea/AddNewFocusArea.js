import React, { Component } from "react";
import PropTypes from "prop-types";
import { Modal, Button } from "antd";
import "./AddNewFocusArea.scss";

import AddEditActionPlan from "../AddEditActionPlan/AddEditActionPlan";

export default class AddNewFocusArea extends Component {
  render = () => {
    return (
      <div className="add-edit-actions">
        <Modal
          className="add-edit-focus-popup"
          title="Create New Focus Area"
          visible={this.props.visible}
          centered
          onCancel={() => this.props.handleCancel()}
          footer={[
            <Button
              key="submit"
              disabled={this.props.forwardActionReducer.actionPlans[this.props.index].opportunityName === ""}
              className="submit-btn"
              type="primary"
              onClick={() => this.props.ok()}
            >
              {this.props.forwardActionReducer.actionPlans[this.props.index].hasOwnProperty("actionPlanId")
                ? "Update"
                : "Create"}
            </Button>
          ]}
        >
          <AddEditActionPlan
            actions={this.props.actions}
            forwardActionReducer={this.props.forwardActionReducer}
            index={this.props.index}
          />
        </Modal>
      </div>
    );
  };
}

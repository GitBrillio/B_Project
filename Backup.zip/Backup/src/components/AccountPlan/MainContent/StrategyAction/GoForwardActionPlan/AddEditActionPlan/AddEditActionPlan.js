import React, { Component } from "react";
import PropTypes from "prop-types";
import Input from "muicss/lib/react/input";
import { Button, Collapse, Row, Col, Icon, DatePicker } from "antd";

import VmSelect from "../../../../../common/VmSelect/VmSelect";
import "./AddEditActionPlan.scss";

export default class AddEditActionPlan extends Component {
  render = () => {
    const dateFormat = "DD-MM-YYYY";
    return (
      <section className="addEditActionPlan">
        <div>
          <Row>
            <Col span={12}>
              {/* <p className="opportunity-heading">Opportunity or Focus Area*</p> */}
              <Input
                label={"Opportunity or Focus Area*"}
                floatingLabel={true}
                autoComplete="off"
                onChange={e => this.props.actions.changeOpportuniy(e.target.value, this.props.index)}
                value={this.props.forwardActionReducer.actionPlans[this.props.index].opportunityName}

                // onBlur={() =>
                //   this.props.actions.createOpportunity(
                //     this.props.forwardActionReducer.actionPlans[this.props.index].opportunityName,
                //     this.props.accountPlanId,
                //     this.props.index
                //   )
                // }
              />
            </Col>
            <Col span={12} />
          </Row>
        </div>
      </section>
    );
  };
}

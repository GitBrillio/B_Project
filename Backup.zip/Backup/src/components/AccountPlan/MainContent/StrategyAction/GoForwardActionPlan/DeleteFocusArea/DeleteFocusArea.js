import React, { Component } from "react";
import PropTypes from "prop-types";
import { Modal, Button } from "antd";

export default class DeleteFocusArea extends Component {
  render = () => {
    const { visible, ok, cancel, okText, cancelText, contents, heading, subContents = null } = this.props;
    return (
      <div className="delete-popup-group">
        <Modal
          className="delete-popup"
          title={heading}
          visible={visible}
          onCancel={cancel}
          centered
          footer={[
            <Button key="back" onClick={cancel}>
              Cancel, Keep it
            </Button>, //
            <Button key="submit" type="primary" onClick={ok}>
              Yes, Delete it
            </Button> //Yes Delete it
          ]}
        >
          {contents}
        </Modal>
      </div>
    );
  };
}

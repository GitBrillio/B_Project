import React, { Component } from "react";
import { Layout } from "antd";
import "./GoForwardActionPlan.scss";
import moment from "moment";
import Input from "muicss/lib/react/input";
const { Content } = Layout;
import { Button, Collapse, Row, Col, Icon, DatePicker } from "antd";
const Panel = Collapse.Panel;
import trash from "../../../../../images/trash.svg";
import VmSelect from "../../../../common/VmSelect/VmSelect";

import AddNewFocusArea from "./AddNewFocusArea/AddNewFocusArea";
import DeleteFocusArea from "./DeleteFocusArea/DeleteFocusArea";
import UserAutoComplete from "../../../../common/UserAutoComplete/UserAutoComplete";

export default class GoForwardActionPlan extends Component {
  state = {
    showCreateArea: false,
    confirmDelete: false,
    deleteContent: null,
    index: null,
    innerIndex: null
  };

  componentDidMount() {
    this.props.actions.fetchActionPlan(this.props.accountPlanId);
    this.props.actions.fetchActionStatus(this.props.accountPlanId);
  }
  addNewFocus() {
    this.setState({
      showCreateArea: true,
      index:
        this.props.forwardActionReducer.actionPlans.length > 0
          ? this.props.forwardActionReducer.actionPlans.length
          : 0
    });
    this.props.actions.addfocusfield();
  }

  createOpportunity() {
    let actionIndex = this.props.forwardActionReducer.actionPlans.length - 1;
    this.setState({
      showCreateArea: false
    });
    let data;
    if (
      !this.props.forwardActionReducer.actionPlans[
        this.state.index
      ].hasOwnProperty("actionPlanId")
    ) {
      data = {
        actionPlanId: null,
        opportunityName: this.props.forwardActionReducer.actionPlans[
          this.state.index
        ].opportunityName,
        accountPlanId: this.props.accountPlanId,
        opportunityActionId: null,
        actionPlan: null,
        actionOwner: null,
        emailAddress: null,
        dueDate: null,
        actionStatus: null
      };
    } else {
      data = {
        actionPlanId: this.props.forwardActionReducer.actionPlans[
          this.state.index
        ].actionPlanId,
        opportunityName: this.props.forwardActionReducer.actionPlans[
          this.state.index
        ].opportunityName,
        accountPlanId: this.props.accountPlanId,
        opportunityActionId: null,
        actionPlan: null,
        actionOwner: null,
        emailAddress: null,
        dueDate: null,
        actionStatus: null
      };
    }
    this.props.actions.createOpportunity(data, this.state.index);
  }

  handleDelete(index) {
    let actionPlanId = this.props.forwardActionReducer.actionPlans[index]
      .actionPlanId;
    this.props.actions.deleteActionsPlan(
      this.props.accountPlanId,
      actionPlanId,
      index
    );
    this.setState({
      confirmDelete: false
    });
  }

  handleCancel() {
    this.setState({
      showCreateArea: false
    });
    this.props.actions.checkActionPlan(this.state.index);
  }

  ConfHandleCancel() {
    this.setState({ confirmDelete: false });
  }

  selectUser(opportunityAction, actionPlan, index, innerIndex, value) {
    this.props.actions.changeActionOwner(value.text, index, innerIndex);
    this.props.actions.createUpdateOpportunityActions(
      {
        accountPlanId: this.props.accountPlanId,
        actionPlanId: actionPlan.actionPlanId,
        opportunityName: actionPlan.opportunityName,
        opportunityActionId: opportunityAction.opportunityActionId,
        actionPlan: opportunityAction.actionPlan,
        actionOwner: value.text,
        emailAddress: opportunityAction.emailAddress,
        dueDate: opportunityAction.dueDate,
        actionStatusId: opportunityAction.actionStatus.actionStatusId
      },
      index,
      innerIndex
    );
  }

  render = () => {
    const dateFormat = "YYYY-MM-DD";

    const options = this.props.forwardActionReducer.data;
    return (
      <section className="goForwardActions">
        <Layout>
          <Content style={{ padding: 24, margin: 0 }}>
            <h3 className="Strategy-Actions">Strategy & Actions</h3>
            <h1 className="Go-Forward-Action">Go-Forward Action Plan</h1>
            {this.props.forwardActionReducer.actionPlans.length == 0 ||
            this.props.forwardActionReducer.actionPlans[0].actionPlanId ==
              null ? (
              <div>
                <div className="action-plan">
                  <button
                    className="dashed-btn"
                    type="dashed"
                    onClick={() => this.addNewFocus()}
                  >
                    Create New Focus Area
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <button
                  className="create-newfocus"
                  onClick={() => this.addNewFocus()}
                >
                  Create New Focus Area
                </button>
                {this.props.forwardActionReducer.actionPlans.map(
                  (actionPlan, index) => (
                    <div>
                      <Collapse defaultActiveKey={["1"]}>
                        <Panel
                          header={
                            <div className="collapse-main">
                              <span className="collapse-header">
                                {actionPlan.opportunityName}
                              </span>
                            </div>
                          }
                          key={index + 1}
                        >
                          {actionPlan.hasOwnProperty("opportunityActions") &&
                          actionPlan.opportunityActions.length > 0 ? (
                            <div>
                              {actionPlan.opportunityActions.map(
                                (opportunityAction, innerIndex) => (
                                  <section className="actionPlansData">
                                    <Row gutter={24}>
                                      <Col span={8}>
                                        <Input
                                          label={"ACTION"}
                                          floatingLabel={true}
                                          autoComplete="off"
                                          onChange={e =>
                                            this.props.actions.changeActionPlan(
                                              e.target.value,
                                              index,
                                              innerIndex
                                            )
                                          }
                                          value={opportunityAction.actionPlan}
                                          onBlur={() =>
                                            this.props.actions.createUpdateOpportunityActions(
                                              {
                                                accountPlanId: this.props
                                                  .accountPlanId,
                                                actionPlanId:
                                                  actionPlan.actionPlanId,
                                                opportunityName:
                                                  actionPlan.opportunityName,
                                                opportunityActionId:
                                                  opportunityAction.opportunityActionId,
                                                actionPlan:
                                                  opportunityAction.actionPlan,
                                                actionOwner:
                                                  opportunityAction.actionOwner,
                                                emailAddress:
                                                  opportunityAction.emailAddress,
                                                dueDate:
                                                  opportunityAction.dueDate,
                                                actionStatusId:
                                                  opportunityAction.actionStatus
                                                    .actionStatusId
                                              },
                                              index,
                                              innerIndex
                                            )
                                          }
                                        />
                                      </Col>

                                      <Col span={16}>
                                        <Row gutter={24}>
                                          <Col span={8}>
                                            <p className="opportunity-heading">
                                              OWNER
                                            </p>
                                            <UserAutoComplete
                                              value={
                                                opportunityAction.actionOwner
                                              }
                                              onChange={value => {
                                                this.selectUser(
                                                  opportunityAction,
                                                  actionPlan,
                                                  index,
                                                  innerIndex,
                                                  value
                                                );
                                              }}
                                            />
                                          </Col>

                                          <Col span={7}>
                                            <p className="opportunity-heading">
                                              DUE DATE
                                            </p>

                                            <DatePicker
                                              format={dateFormat}
                                              placeholder=""
                                              value={
                                                opportunityAction.dueDate ==
                                                  "" ||
                                                opportunityAction.dueDate ===
                                                  null
                                                  ? ""
                                                  : moment(
                                                      opportunityAction.dueDate,
                                                      dateFormat
                                                    )
                                              }
                                              onChange={(date, dateString) => {
                                                this.props.actions.changeDate(
                                                  dateString,
                                                  index,
                                                  innerIndex
                                                );
                                                this.props.actions.createUpdateOpportunityActions(
                                                  {
                                                    accountPlanId: this.props
                                                      .accountPlanId,
                                                    actionPlanId:
                                                      actionPlan.actionPlanId,
                                                    opportunityName:
                                                      actionPlan.opportunityName,
                                                    opportunityActionId:
                                                      opportunityAction.opportunityActionId,
                                                    actionPlan:
                                                      opportunityAction.actionPlan,
                                                    actionOwner:
                                                      opportunityAction.actionOwner,
                                                    emailAddress:
                                                      opportunityAction.emailAddress,
                                                    dueDate: dateString,
                                                    actionStatusId:
                                                      opportunityAction
                                                        .actionStatus
                                                        .actionStatusId
                                                  },
                                                  index,
                                                  innerIndex
                                                );
                                              }}
                                            />
                                          </Col>
                                          <Col span={7}>
                                            <p className="opportunity-heading">
                                              STATUS
                                            </p>
                                            <VmSelect
                                              label={""}
                                              value="label"
                                              id="actionStatusId"
                                              placeholder={
                                                opportunityAction.actionStatus
                                                  .label
                                              }
                                              options={options}
                                              onChange={e => {
                                                this.props.actions.changeStatusKey(
                                                  index,
                                                  innerIndex,
                                                  e
                                                );

                                                this.props.actions.createUpdateOpportunityActions(
                                                  {
                                                    accountPlanId: this.props
                                                      .accountPlanId,
                                                    actionPlanId:
                                                      actionPlan.actionPlanId,
                                                    opportunityName:
                                                      actionPlan.opportunityName,
                                                    opportunityActionId:
                                                      opportunityAction.opportunityActionId,
                                                    actionPlan:
                                                      opportunityAction.actionPlan,
                                                    actionOwner:
                                                      opportunityAction.actionOwner,
                                                    emailAddress:
                                                      opportunityAction.emailAddress,
                                                    dueDate:
                                                      opportunityAction.dueDate,
                                                    actionStatusId: e
                                                  },
                                                  index,
                                                  innerIndex
                                                );
                                              }}
                                            />
                                          </Col>

                                          <Col span={2}>
                                            <div
                                              className="delete-action"
                                              onClick={() =>
                                                this.props.actions.deleteOpportunity(
                                                  index,
                                                  innerIndex,
                                                  this.props.accountPlanId,
                                                  opportunityAction.opportunityActionId
                                                )
                                              }
                                            >
                                              <Icon type="minus-circle-o" />
                                            </div>
                                          </Col>
                                        </Row>
                                      </Col>
                                    </Row>
                                  </section>
                                )
                              )}
                              <div className="button-wrap">
                                <button
                                  className="edit-button"
                                  onClick={() =>
                                    this.setState({
                                      index: index,
                                      showCreateArea: true
                                    })
                                  }
                                >
                                  Edit
                                </button>

                                <button
                                  className="add-more"
                                  onClick={() =>
                                    this.props.actions.addAnotherActions(index)
                                  }
                                >
                                  + Add Another Action
                                </button>
                                <div
                                  className="delete-icon"
                                  onClick={() =>
                                    this.setState({
                                      confirmDelete: true,
                                      deleteContent: actionPlan.opportunityName,
                                      index: index
                                    })
                                  }
                                >
                                  <img
                                    src={trash}
                                    title="Delete mission critical system"
                                    alt="Delete System"
                                  />
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div>
                              <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-30 text-center">
                                <Button
                                  className="dashed-button"
                                  type="dashed"
                                  onClick={() =>
                                    this.props.actions.addOpportunityActions(
                                      index
                                    )
                                  }
                                >
                                  Add Action
                                </Button>
                              </div>
                              <div className="button-wrap">
                                <button
                                  className="edit-button"
                                  onClick={() =>
                                    this.setState({
                                      index: index,
                                      showCreateArea: true
                                    })
                                  }
                                >
                                  Edit
                                </button>

                                <div
                                  className="delete-icon"
                                  onClick={() =>
                                    this.setState({
                                      confirmDelete: true,
                                      deleteContent: actionPlan.opportunityName,
                                      index: index
                                    })
                                  }
                                >
                                  <img
                                    src={trash}
                                    title="Delete mission critical system"
                                    alt="Delete System"
                                  />
                                </div>
                              </div>
                            </div>
                          )}
                        </Panel>
                      </Collapse>
                    </div>
                  )
                )}
              </div>
            )}
            {this.state.showCreateArea ? (
              <AddNewFocusArea
                visible={this.state.showCreateArea}
                handleCancel={() => this.handleCancel()}
                actions={this.props.actions}
                index={this.state.index}
                ok={() => this.createOpportunity()}
                forwardActionReducer={this.props.forwardActionReducer}
              />
            ) : null}
            {this.state.confirmDelete ? (
              <DeleteFocusArea
                heading="Delete Focus Area"
                visible={this.state.confirmDelete}
                ok={() => this.handleDelete(this.state.index)}
                cancel={() => this.ConfHandleCancel()}
                okText="Yes, Delete It"
                cancelText="Cancel, Keep It"
                contents={`Are you sure you want to delete the "${
                  this.state.deleteContent
                }" Focus Area?`}
              />
            ) : null}
          </Content>
        </Layout>
      </section>
    );
  };
}

import React, { Component } from "react";
import { Layout, Button, Upload, message, Row, Col } from "antd";
import AddPrompterUrl from "./AddPrompterUrl/AddPrompterUrl"
import PropTypes from "prop-types";
import "./ValuePrompter.scss";
const { Content } = Layout;
import trash from "../../../../../images/trash.svg";
import DeletePopup from '../../../../common/DeletePopup/DeletePopup';

export default class ValuePrompter extends Component {

  constructor(props) {
    super(props);
    this.state = {
      addPrompterUrl: false,
      deletePopupUrl: false,
      deletePopupImage: false,
      url: "",
      baseimage: ""
    }
  }
  componentDidMount() {
    this.props.actions.getVpData(this.props.accountPlanId);
  }
  handleCancel() {
    this.setState({ addPrompterUrl: false })
  }
  saveUrl() {
    var re = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
    if (re.test(this.props.strategyReducer.valuePrompterPost.vpUrl)) {
      this.props.actions.ValuePrompterActions(this.props.strategyReducer.valuePrompterPost, this.props.accountPlanId);
      this.setState({ addPrompterUrl: false })
    } else {
      message.error("Wrong URL formate", 1);
    }
  }
  handleChange(e) {
    this.props.actions.vpPostDataChange(e.target.value, this.props.accountPlanId)
  }
  imageUpload(e) {
    let postDataC = { ...this.props.strategyReducer.valuePrompterPost }
    let fileToLoad = e.file;
    let fileReader = new FileReader();

    fileReader.onload = (fileLoadedEvent) => {
      let srcData = fileLoadedEvent.target.result; // <--- data: base64
      postDataC.encodedImage = srcData;
      this.props.actions.ValuePrompterActions(postDataC, this.props.accountPlanId);
    }
    fileReader.readAsDataURL(fileToLoad);
  }
  deleteVpUrl() {
    let postDataC = { ...this.props.strategyReducer.valuePrompterPost }
    postDataC.vpUrl = null;
    this.props.actions.ValuePrompterActions(postDataC, this.props.accountPlanId);
    this.setState({ deletePopupUrl: false })
  }
  deleteVpImage() {
    let postDataC = { ...this.props.strategyReducer.valuePrompterPost }
    postDataC.encodedImage = null;
    this.props.actions.ValuePrompterActions(postDataC, this.props.accountPlanId);
    this.setState({ deletePopupImage: false })
  }
  ConfHandleCancel() {
    this.setState({ deletePopupUrl: false })
    this.setState({ deletePopupImage: false })
  }
  render = () => {
    return (
      <section className="value-prompter">
        <Layout>
          <Content
            style={{
              background: "#F3F9FB",
              padding: 24,
              margin: 0,
              minHeight: 280
            }}
          >
            <h3 className="h3-style">Strategy & Actions</h3>
            <h1>Value Prompter</h1>
            {(this.props.strategyReducer.valuePrompterPost.vpUrl == null) &&
              <div className="prompter-url" style={{ minHeight: 160 }}>
                <Button className="dashed-btn" type="dashed" onClick={() => this.setState({ addPrompterUrl: true })}>
                  Add Value Prompter URL
                </Button>
              </div>
            }

            {(this.props.strategyReducer.valuePrompterPost.vpUrl != null) &&
              <div className="details-cont prompter-url" >
                <section className="details-sec">
                  <Row className="div-style">
                    <Col span={22} className="padding0">
                      <p className="para-style"><span>URL</span></p>
                    </Col>
                    <Col span={1} className="padding0">
                      <p className="edit-button">
                        <span onClick={() => this.setState({ addPrompterUrl: true })}>EDIT</span>
                      </p>
                    </Col>
                    <Col span={1} className="padding0">
                      <p className="delete-icon"><span onClick={() => this.setState({ deletePopupUrl: true })}> <img src={trash} title="Delete mission critical system" alt="Delete System" /></span></p>
                    </Col>
                  </Row>
                  <Row className="details-body">
                    <span className="url-link"> <a target="_blank" href={this.props.strategyReducer.valuePrompterPost.vpUrl}>Click to open the URL</a></span>
                  </Row>
                </section>
              </div>
            }

            {(this.props.strategyReducer.valuePrompterPost.encodedImage == null) &&
              <div className="prompter-image">
                <p className="prompter-image-text">Upload the file by clicking on below button</p>
                <Upload
                  customRequest={e => this.imageUpload(e)}>
                  <Button className="dashed-btn" type="dashed" >
                    Browse File
                </Button>
                </Upload>
              </div>
            }

            {(this.props.strategyReducer.valuePrompterPost.encodedImage != null) &&
              <div className="details-cont prompter-image">
                <section className="details-sec">
                  <Row className="div-style">
                    <Col span={22} className="padding0">
                      <p className="para-style"><span>Screenshort</span></p>
                    </Col>
                    <Col span={1} className="padding0">
                      <p className="edit-button">
                        <Upload
                          customRequest={e => this.imageUpload(e)}>
                          <span>EDIT</span>
                        </Upload>
                      </p>
                    </Col>
                    <Col span={1} className="padding0">
                      <p className="delete-icon"><span onClick={() => this.setState({ deletePopupImage: true })}> <img src={trash} title="Delete mission critical system" alt="Delete System" /></span></p>
                    </Col>
                  </Row>
                  <Row className="div-style">
                    <img className="ecodedImg" src={this.props.strategyReducer.valuePrompterPost.encodedImage} />
                  </Row>
                </section>
              </div>
            }

          </Content>

        </Layout>
        {this.state.addPrompterUrl ?
          <AddPrompterUrl
            visible={this.state.addPrompterUrl}
            title="Add Value Prompter URL"
            handleCancel={() => this.handleCancel()}
            handleChange={e => this.handleChange(e)}
            handleSave={() => this.saveUrl()}
            value={this.props.strategyReducer.valuePrompterPost.vpUrl}
          /> : null
        }
        {this.state.deletePopupUrl &&
          <DeletePopup
            heading="Delete Value Prompter URL"
            visible={this.state.deletePopupUrl}
            ok={() => this.deleteVpUrl(this.state)}
            cancel={() => this.ConfHandleCancel()}
            okText="Yes delete it"
            cancelText="No, cancel it"
            contents="Are you sure you want to delete this Value Prompter?"
          />}
        {this.state.deletePopupImage &&
          <DeletePopup
            heading="Delete Value Prompter Image"
            visible={this.state.deletePopupImage}
            ok={() => this.deleteVpImage(this.state)}
            cancel={() => this.ConfHandleCancel()}
            okText="Yes delete it"
            cancelText="No, cancel it"
            contents="Are you sure you want to delete this Value Prompter?"
          />}
      </section>
    );
  };
}


ValuePrompter.propTypes = {
  strategyReducer: PropTypes.object,
  actions: PropTypes.object,
  accountPlanId: PropTypes.string
};


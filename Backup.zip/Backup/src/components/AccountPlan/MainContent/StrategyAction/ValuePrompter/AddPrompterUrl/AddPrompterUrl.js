import React, { Component } from 'react';
import { Modal, Button} from 'antd';
import './AddPrompterUrl.scss';
import Input from 'muicss/lib/react/input';

class AddPrompterUrl extends Component{
    constructor(props) {
        super(props);
    }
    render = () =>{   
        return (
            <div>
            {this.props.visible && <Modal
                className="add-prompter-url"
                title={this.props.title}
                visible={true}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    <Button key="submit" type="primary" onClick={()=>this.props.handleSave()} >
                        Save
                    </Button>
                ]}
                >
                <Input 
                    value={this.props.value}
                    label={"URL"}
                    floatingLabel={true}
                    onChange={(e)=>this.props.handleChange(e)}
                    />                  

                </Modal>
                }
            
        </div>
        )
    }

}



export default AddPrompterUrl;
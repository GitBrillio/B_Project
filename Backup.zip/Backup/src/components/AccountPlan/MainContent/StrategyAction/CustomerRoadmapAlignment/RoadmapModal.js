import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button, Row, Col, DatePicker, Select, Icon } from 'antd';
const Option = Select.Option;
const { RangePicker } = DatePicker;
import './RoadmapModal.scss';
import Input from "muicss/lib/react/input";
import moment from "moment";
import _ from 'underscore';

class RoadmapModal extends Component {

    componentDidMount(){
        this.props.actions.getBIdropdown(this.props.accountPlanId)
    }

    disableButton = () => {
        let index = _.findIndex(this.props.strategyReducer.roadmap.roadmap.initiativeList,(o)=>{
            return o.businessInitiativeId == this.props.strategyReducer.workstreamDetails.businessInitiativeId
        });
        if(index >= 0 ){
            return true
        }

        return false
    }
    
    render = () => {
        const { visible, heading, handleCancel, okText, strategyReducer, handleSubmit } = this.props;
        return (
            <div className="">
                <Modal
                    className="roadmap-modal"
                    title={heading}
                    visible={visible}
                    centered
                    onCancel={handleCancel}
                    footer={[<Button key="submit" disabled={this.disableButton()} className="create-btn" onClick={handleSubmit}>
                        {"Save"}
                    </Button>]}
                >
                    <div>
                        <Row gutter={16}>
                            <Col span={6} className="select-cont">
                                <label className="label-style">Select Business Initiative*</label>
                                <Select
                                    disabled={!this.props.isCreating}
                                    className="select-main"
                                    placeholder={this.props.workstreamDetails.businessInitiativeName }
                                    value={this.props.workstreamDetails.businessInitiativeName}
                                    onChange={(e) => this.props.actions.roadmapInputChange(e)}
                                    // disabled={!this.props.workstreamDetails.businessInitiativeId ? false : true}
                                >
                                    {strategyReducer.roadmap.BIdropdown.map((opt, idx) => {
                                        return (
                                            <Option key={idx} value={JSON.stringify(opt)}>
                                                {opt.label}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Col>
                        </Row>
                        <Row className="label-head">
                            <Col span={16}>
                                <label className="label-style label-style-desc">DESCRIBE WORKSTREAM</label>
                            </Col>
                            <Col span={8}>
                                <label className="label-style label-style-date">START & END DATE</label>
                            </Col>
                        </Row>
                        {
                                this.props.workstreamDetails.workstreamList.map((workstream, index) => {
                                    return (
                                        <Row gutter={16} className="second-row" key={index}>
                                            <Col span={15} className="desc-main">
                                                <Input
                                                    placeholder="Describe Workstream"
                                                    onChange={(e) => this.props.actions.changeDescriptionRWS(e.target.value, index)}
                                                    value={workstream ? workstream.description : ""}
                                                />
                                            </Col>
                                            <Col span={8} className="calendear-main">
                                                <RangePicker
                                                    className="calendar-select"
                                                    placeholder={["From..", "To.."]}
                                                    value={workstream ? [
                                                        moment(!workstream.startDate ? new Date(): workstream.startDate),
                                                        moment(!workstream.endDate ? new Date() : workstream.endDate)
                                                    ] : ""}
                                                    onChange={(dateString) => {
                                                        this.props.actions.roadmapDateChange(dateString, index)
                                                    }}
                                                />
                                            </Col>
                                            <Col span={1}>
                                                <div className="delete-icon" onClick={() => this.props.actions.removeRoadmapWorksream(
                                                    index
                                                )}>
                                                    <Icon className="minus-circle" type="minus-circle-o" />
                                                </div>
                                            </Col>
                                        </Row>
                                    )
                                })
                                

                        }
                        <button className="add-another" onClick={() => this.props.actions.addMoreDesc()}>
                            + Add Another
                    </button>
                    </div>
                </Modal>
            </div>)
    }
}

RoadmapModal.propTypes = {
    visible: PropTypes.bool.isRequired,
    handleSubmit: PropTypes.func,
    handleCancel: PropTypes.func,
    actions: PropTypes.object,
    index: PropTypes.number,
    heading: PropTypes.string,
    strategyReducer: PropTypes.object,
    accountPlanId: PropTypes.string,
    workstreamDetails: PropTypes.object,
    okText: PropTypes.string
}

export default RoadmapModal;

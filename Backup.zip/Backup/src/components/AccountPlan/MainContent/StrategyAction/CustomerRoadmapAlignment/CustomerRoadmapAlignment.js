import React, { Component } from 'react';
import { Layout, Icon, Popover, Row, Col } from 'antd';
import PropTypes from 'prop-types';
const { Content } = Layout;
import './Customer-roadmap-alignment.scss';
import RoadmapModal from './RoadmapModal';
import DeleteBusinessInitiative from './DeleteBusinessInitiative';
import trash from "../../../../../images/trash.svg";

class CustomerRoadmapAlignment extends Component {
    state = {
        showCreateArea: false,
        showCreateAreaEdit: false,
        deleteInitiative: false,
        index: null,
        noOfWorkstreams: 0,
        localworkstreamDetails: null,
        isCreating: false
    }
    componentDidMount() {
        this.props.actions.getBIdropdown(this.props.accountPlanId);
        this.props.actions.getRoadmap(this.props.accountPlanId);
        this.setState({
            localworkstreamDetails: this.props.strategyReducer.roadmap.roadmap.initiativeList
        });
    }
    addNewRoadmap(type) {
        this.props.actions.resetRoadmap();
        if (type == "create") {
            this.setState({
                isCreating: true,
                showCreateArea: true,
            });
        }
        else {
            this.setState({
                showCreateAreaEdit: true,
                index: index
            });
        }
    }
    handleSubmit() {
        this.setState({ showCreateArea: false });
        this.props.actions.createUpdateRoadmap(
            this.props.strategyReducer.workstreamDetails,
            this.props.accountPlanId
        );
    }

    handleCancel() {
        this.setState({
            showCreateArea: false
        });
    }
    handleEditCancel() {
        this.setState({
            showCreateAreaEdit: false
        });
    }

    getQuarter = (workstream) => {
        let quarterStart = workstream.startQuarter;
        switch (quarterStart) {
            case "Q1":
                return "26%";
            case "Q2":
                return "34.5%";
            case "Q3":
                return "41.4%";
            case "Q4":
                return "48.3%";
            case "Q5":
                return "55.2%";
            case "Q6":
                return "62.1%";
            case "Q7":
                return "69%";
            case "Q8":
                return "75.9%";
            case ">2years":
                return "82.8%";
            default:
                return "26%";
        }
    };
    getTimelineWidth = (workstream) => {
        switch (workstream.startQuarter) {
            case "Q":
                var quarterStart = 1;
                break;
            case ">2years":
                quarterStart = 8;
                break;
            default:
                quarterStart = workstream && workstream.startQuarter && workstream.startQuarter.substring(1);
                break;
        }
        switch (workstream.endQuarter) {
            case "Q":
                var quarterEnd = 1;
                break;
            case ">2years":
                quarterEnd = 8;
                break;
            default:
                quarterEnd = workstream && workstream.endQuarter && workstream.endQuarter.substring(1);
                break;
        }
        return ((quarterEnd - quarterStart) * 7)
    };
    getCellHeight = (timelineLength) => {
        if (timelineLength === 0) {
            return 50;
        }
        else {
            return (25 * timelineLength + 25);
        }
    };
    handleDelete() {
        this.props.actions.removeInitiativeRoadmap(this.state.businessInitiativeId,this.props.accountPlanId)
        this.setState({
            deleteInitiative: false
        });
    }

    handleDeleteCancel() {
        this.setState({
            deleteInitiative: false
        });
    }
    render = () => {
        const roadmap = this.props.strategyReducer.roadmap.roadmap;
        return (
            <section className="customer-roadmap-alignment">
                <Layout>
                    <Content style={{ padding: 24, margin: 0 }}>
                        <h3 className="heading">Strategy & Actions</h3>
                        <h1 className="sub-heading">Customer Roadmap Alignment</h1>
                        {
                            this.props.strategyReducer.roadmap.roadmap.initiativeList.length == 0 ?
                                <div className="new-roadmap">
                                    <button className="dashed-btn" type="dashed" onClick={() => this.addNewRoadmap("create", null)}>
                                        Create New Roadmap
                                    </button>
                                </div>
                                :
                                <div>
                                    <button className="create-newroadmap" onClick={() => this.addNewRoadmap("create", null)}>
                                        Create New Roadmap
                                </button>
                                    <div className="roadmap-table">
                                        <div className="roadmap-table-row">
                                            <div className="roadmap-table-head"><span>Business Initative</span></div>
                                            {
                                                roadmap.quarterList && roadmap.quarterList.map((value, idx) => {
                                                    return (
                                                        <div key={idx} className="roadmap-table-head"><span>{value.quarter}</span></div>
                                                    )
                                                })
                                            }
                                            <div className="roadmap-table-head"><span style={{ visibility: 'hidden' }}>A</span></div>
                                        </div>
                                        {
                                            roadmap.initiativeList && roadmap.initiativeList.map((value, idx) => {
                                                var timelineLength = value.workstreamList && value.workstreamList.length;
                                                return (
                                                    <div className="roadmap-table-row" key={idx}>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>
                                                            <span>{value.businessInitiativeName}</span>
                                                            {
                                                                timelineLength > 0 ?
                                                                    <Icon type="plus-circle"
                                                                        theme="filled"
                                                                        style={{ color: '#0375b7', fontSize: '20px', cursor: "pointer" }}
                                                                        onClick={() => {
                                                                            this.props.actions.setRoadmapWS(value, idx);
                                                                            setTimeout(() => {
                                                                                this.setState({
                                                                                    showCreateArea: true,
                                                                                    isCreating: false
                                                                                })
                                                                            }, 0)
                                                                        }}
                                                                    />
                                                                    :
                                                                    ""
                                                            }
                                                        </div>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        {
                                                            timelineLength > 0 ?
                                                                value.workstreamList && value.workstreamList.map((val, key) => {
                                                                    let quarter = this.getQuarter(val, key);
                                                                    let timelineWidth = this.getTimelineWidth(val, key);
                                                                    return (
                                                                        <div key={key}>
                                                                            <Popover content={
                                                                                <div className="pop_over popover-custom">
                                                                                    <Row>
                                                                                        <Col>
                                                                                            <div className="popover-head">WORKSTREAM</div>
                                                                                            <div className="txt">{val.description}</div>
                                                                                        </Col>
                                                                                    </Row>
                                                                                    <Row className="second-row">
                                                                                        <Col span={12}>
                                                                                            <div className="popover-head">START DATE</div>
                                                                                            <div className="txt">{val.startDate}</div>
                                                                                        </Col>
                                                                                        <Col span={12}>
                                                                                            <div className="popover-head">END DATE</div>
                                                                                            <div className="txt">{val.endDate}</div>
                                                                                        </Col>
                                                                                    </Row>
                                                                                </div>

                                                                            }
                                                                                placement="right"
                                                                                trigger="hover">
                                                                                <div className="timeline" style={{ left: quarter, top: (key * 25) + 15 + "px", width: timelineWidth + "%" }}>
                                                                                    {val.description}
                                                                                </div>
                                                                            </Popover>

                                                                        </div>
                                                                    )
                                                                })
                                                                :
                                                                <div className="add-workstream" 
                                                                onClick={() => {
                                                                    this.props.actions.setRoadmapWS(value, idx);
                                                                    setTimeout(() => {
                                                                        this.setState({
                                                                            showCreateArea: true,
                                                                            isCreating: false
                                                                        })
                                                                    }, 0)
                                                                }
                                                                }
                                                                >+ ADD WORKSTREAM</div>
                                                        }

                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        <div className="roadmap-table-cell" style={{ height: this.getCellHeight(timelineLength) + "px" }}>&nbsp;</div>
                                                        <div className="roadmap-table-cell table-cell-action" style={{ height: this.getCellHeight(timelineLength) + "px" }}>
                                                            <span className="edit-btn"
                                                                onClick={() => {
                                                                    this.props.actions.setRoadmapWS(value, idx);
                                                                    setTimeout(() => {
                                                                        this.setState({
                                                                            showCreateArea: true,
                                                                            isCreating: false
                                                                        })
                                                                    }, 0)
                                                                }
                                                                }
                                                            >
                                                                EDIT
                                                        </span>
                                                            <img src={trash}
                                                                title="Delete business initiative"
                                                                alt="Delete Business Initiative"
                                                                className="delete-btn"
                                                                onClick={() =>
                                                                    this.setState({
                                                                        deleteInitiative: true,
                                                                        noOfWorkstreams: timelineLength,
                                                                        businessInitiativeId:value.businessInitiativeId
                                                                    })
                                                                }
                                                            />
                                                        </div>
                                                    </div>
                                                )
                                            })
                                        }

                                    </div>
                                </div>
                        }



                        {this.state.showCreateArea &&
                            <RoadmapModal
                                visible={this.state.showCreateArea}
                                handleSubmit={() => this.handleSubmit()}
                                handleCancel={() => this.handleCancel()}
                                actions={this.props.actions}
                                heading={this.state.isCreating ? "Create New Roadmap" : "Modify Roadmap"}
                                okText={this.state.isCreating ? "Save" : "Update"}
                                isCreating={this.state.isCreating}
                                workstreamDetails={this.props.strategyReducer.workstreamDetails}
                                strategyReducer={this.props.strategyReducer}
                                accountPlanId={this.props.accountPlanId}
                            />
                        }

                        {this.state.deleteInitiative ? (
                            <DeleteBusinessInitiative
                                heading="Delete Business Initiative"
                                visible={this.state.deleteInitiative}
                                ok={() => this.handleDelete()}
                                cancel={() => this.handleDeleteCancel()}
                                noOfWorkstreams={this.state.noOfWorkstreams}
                            />
                        ) : null
                        }
                    </Content>
                </Layout>

            </section>
        )
    }
}

CustomerRoadmapAlignment.propTypes = {
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    strategyReducer: PropTypes.object,
    customerId: PropTypes.string
}

export default CustomerRoadmapAlignment;

import React, { Component } from "react";
import PropTypes from "prop-types";
import { Modal, Button, Row} from "antd";
import './DeleteBusinessInitiative.scss';

class DeleteBusinessInitiative extends Component {
  render = () => {
    const { visible, ok, cancel, heading, noOfWorkstreams } = this.props;
    return (
      <div className="delete-popup-group">
        <Modal
          className="delete-popup"
          title={heading}
          visible={visible}
          onCancel={cancel}
          centered
          footer={[
            <Button key="back" className="cancel-btn" onClick={cancel}>
              Cancel, Keep it
            </Button>, //
            <Button key="submit" type="primary" onClick={ok}>
              Yes, Delete it
            </Button>
          ]}
        >
          <div>
            <Row className="txt txt-one">Are you sure you want to delete the Business Initiative?</Row>
            <Row className="txt txt-two">Will also delete the </Row>
            <Row className="txt txt-three">{noOfWorkstreams + " Workstream"} </Row>

          </div>
        </Modal>
      </div>
    );
  };
}
DeleteBusinessInitiative.propTypes = {
    actions: PropTypes.object,
    heading: PropTypes.string,
    visible: PropTypes.bool,
    ok: PropTypes.func,
    cancel: PropTypes.func,
    noOfWorkstreams: PropTypes.number
}

export default DeleteBusinessInitiative;
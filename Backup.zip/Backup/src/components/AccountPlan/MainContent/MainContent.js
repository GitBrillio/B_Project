import React, { Component } from "react";
import PropTypes from "prop-types";
import "./MainContent.scss";
import { Layout } from "antd"; //Collapse

import LeftNavBar from "../LeftNavBar/LeftNavBar";
import CustomerProfile from "./CustomerProfile/CustomerProfile";
import Footprint from "./Footprint/Footprint";
import ITLandscape from "./Footprint/ITLandscape/ITLandscape";
import FootPrintAndWhiteSpace from "./Footprint/WhiteSpace/FootPrintAndWhiteSpace";
import KeyMetrics from "./Footprint/KeyMetrics/KeyMetrics";
import ThreeYearAmbition from "./StrategyAction/ThreeYearAmbition/ThreeYearAmbition";
import KeyOpportunities from "./StrategyAction/KeyOpportunities/KeyOpportunities";
import ValuePrompter from "./StrategyAction/ValuePrompter/ValuePrompter";
import BusinessITAlignment from "./CustomerProfile/BusinessITAlignment/BusinessITAlignment";
import VMwareContracts from "./Footprint/VMwareContracts/VMwareContracts";
import ApplicationPortfolioEvolution from "./CustomerProfile/ApplicationPortfolioEvolution/ApplicationPortfolioEvolution";
import CustomerSuccess from "./Footprint/CustomerSuccess/CustomerSuccess";
import GoForwardActionPlan from "./StrategyAction/GoForwardActionPlan/GoForwardActionPlan";
import KeyDecisionMaker from "./StrategyAction/KeyDecisionMaker/KeyDecisionMaker";
import KnowledgeGap from "./CustomerProfile/KnowledgeGap/KnowledgeGap";
import Partners from "./Footprint/Partner/Partner";
import KeyCompetitorAnalysis from "./Footprint/KeyCompetitorAnalysis/KeyCompetitorAnalysis";
import CustomerRoadmapAlignment from "./StrategyAction/CustomerRoadmapAlignment/CustomerRoadmapAlignment";
import CustomerStrategy from "./CustomerProfile/CustomerStrategy/CustomerStrategy";
import OrgStructure from "./CustomerProfile/OrgStructure/OrgStructure";
// import StrategyAction from './StrategyAction/StrategyAction';
//const Panel = Collapse.Panel;

class MainContent extends Component {
  state = {
    currentTab: "Overview" //ITLandscape
  };
  constructor(props) {
    super(props);
  }
  renderTab = () => {
    switch (this.state.currentTab) {
      case "Overview": {
        return (
          <CustomerProfile
            overviewReducer={this.props.overviewReducer}
            actions={this.props.actions}
            accountPlanId={this.props.accountPlanId}
            landingReducer={this.props.landingReducer}
          />
        );
      }
      case "VMwareBookings": {
        return (
          <Footprint
            footprintReducer={this.props.footprintReducer}
            actions={this.props.actions}
            landingReducer={this.props.landingReducer.selectedAccount}
            accountPlanId={this.props.accountPlanId}
          />
        );
      }
      case "ITLandscape": {
        return (
          <ITLandscape
            footprintReducer={this.props.footprintReducer}
            actions={this.props.actions}
            accountPlanId={this.props.accountPlanId}
            keyMetricsReducer={this.props.keyMetricsReducer}
            account={this.props.landingReducer.selectedAccount}
          />
        );
      }
      case "FootprintWhitespace": {
        return (
          <FootPrintAndWhiteSpace
            footprintReducer={this.props.footprintReducer}
            actions={this.props.actions}
            accountPlanId={this.props.accountPlanId}
            customerId={this.props.landingReducer.selectedAccount.customerId}
          />
        );
      }
      case "KeyMetrics": {
        return (
          <KeyMetrics
            keyMetricsReducer={this.props.keyMetricsReducer}
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            account={this.props.landingReducer.selectedAccount}
          />
        );
      }
      case "VmwareContracts": {
        return (
          <VMwareContracts
            actions={this.props.actions}
            footprintReducer={this.props.footprintReducer}
            accountPlanId={this.props.accountPlanId}
            account={this.props.landingReducer.selectedAccount}
          />
        );
      }
      case "KeyCompetitorAnalysis": {
        return ( 
          <KeyCompetitorAnalysis 
            actions={this.props.actions}
            footprintReducer={this.props.footprintReducer}
            accountPlanId={this.props.accountPlanId}
          /> 
          );
      }
      case "3yearAmbition": {
        return (
          <ThreeYearAmbition
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            strategyReducer={this.props.strategyReducer}
            customerId={this.props.landingReducer.selectedAccount.customerId}
            footprintReducer={this.props.footprintReducer}
          />
        );
      }
      case "CustomerRoadmapAlignment": {
        return (
          <CustomerRoadmapAlignment
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            strategyReducer={this.props.strategyReducer}
            //customerId={this.props.landingReducer.selectedAccount.customerId}
          />
        );
      }
      case "KeyOpportunities": {
        return (
          <KeyOpportunities
            actions={this.props.actions}
            strategyReducer={this.props.strategyReducer}
            accountId={this.props.accountId}
          />
        );
      }
      case "ValuePrompter": {
        return (
          <ValuePrompter
            actions={this.props.actions}
            strategyReducer={this.props.strategyReducer}
            accountId={this.props.accountId}
            accountPlanId={this.props.accountPlanId}
          />
        );
      }
      case "BusinessITAlignment": {
        return (
          <BusinessITAlignment
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            businessGoalReducer={this.props.businessGoalReducer}
          />
        );
      }
      case "CustomerStrategy": {
        return <CustomerStrategy 
                accountPlanId={this.props.accountPlanId}
                actions={this.props.actions}
                customerStrategyReducer={this.props.customerStrategyReducer}
              />;
      }
      case "ApplicationPortfolioEvolution": {
        return (
          <ApplicationPortfolioEvolution
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            portfolio={this.props.portfolio}
          />
        );
      }
      case "CustomerSuccess": {
        return (
          <CustomerSuccess
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            customerSuccess={this.props.customerSuccess}
          />
        );
      }
      case "GoForwardActionPlan": {
        return (
          <GoForwardActionPlan
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            forwardActionReducer={this.props.forwardActionReducer}
          />
        );
      }
      case "KeyDecisionMakerCoverage": {
        return (
          <KeyDecisionMaker
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            keydecisionReducer={this.props.keydecisionReducer}
          />
        );
      }

      case "KnowledgeGap": {
        return (
          <KnowledgeGap
            gotoActionPlan={()=>{
              this.setState({
                currentTab: 'GoForwardActionPlan'
              });
            }}
            accountPlanId={this.props.accountPlanId}
            actions={this.props.actions}
            knowledgeGapReducer={this.props.knowledgeGapReducer}
          />
        );
      }
      case "Partners": {
        return <Partners 
          accountPlanId={this.props.accountPlanId} 
          actions={this.props.actions} 
          partnerReducer={this.props.partnerReducer}
        />;
      }
      case "BusinessOrganization":{
        return <OrgStructure 
          accountPlanId={this.props.accountPlanId}
          actions={this.props.actions}
          title="BUSINESS"
          overviewReducer={this.props.overviewReducer}
        />
      }
      case "ITOrganization":{
        return <OrgStructure 
          accountPlanId={this.props.accountPlanId}
          actions={this.props.actions}
          title="IT"
          overviewReducer={this.props.overviewReducer}
        />
      }
      default: {
        return null;
      }
    }
  };


  menuChange = menu => {
    this.setState({
      currentTab: menu
    });
  };

  render() {
    return (
      <div className="main-content">
        <Layout className="gradient">
          <LeftNavBar onMenuChange={this.menuChange} />
          {this.renderTab()}
        </Layout>
      </div>
    );
  }
}

MainContent.propTypes = {
  overviewReducer: PropTypes.object,
  landingReducer:PropTypes.object,
  businessGoalReducer:PropTypes.object,
  portfolio:PropTypes.object,
  customerSuccess:PropTypes.object,
  forwardActionReducer:PropTypes.object,
  keydecisionReducer:PropTypes.object,
  knowledgeGapReducer:PropTypes.object,
  keyMetricsReducer: PropTypes.object,
  strategyReducer: PropTypes.object,
  footprintReducer: PropTypes.object,
  partnerReducer:PropTypes.object,
  actions: PropTypes.object,
  accountPlanId: PropTypes.string.isRequired,
  businessGoal: PropTypes.object,
  accountId: PropTypes.string,
  customerStrategyReducer: PropTypes.object
};

export default MainContent;

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Input from 'muicss/lib/react/input';
import trash from '../../../../../../images/trash.svg';
import './System.scss';
import { Provider } from './Provider';


class System extends Component {
    render = () => {
        const {system,actions,type,systemIndex,deleteSystem} = this.props;
        const placeholder = type === 'MISSION_CRITICAL_SYSTEM' ? 'Mission Critical System Name' : 'Information System Name';
        return (
            <section className="system">
                <div className="delete-icon" onClick={()=>deleteSystem(type,systemIndex,system)}>
                    <img src={trash} title="Delete mission critical system" alt="Delete System" />
                </div>
                <div className="col-lg-11 plr0" style={{paddingRight:'15px'}}>
                    <Input 
                        label={placeholder}
                        value={system.landscape.landscapeName} 
                        floatingLabel={true} 
                        onChange={(e)=>actions.changeSystem(e.target.value,systemIndex,type)}
                        onBlur={()=>actions.updateSystem(system,systemIndex,type)}
                    />
                </div>
                <div className="col-lg-12 plr0">
                    {
                        system.providerInfo.map((obj,index)=>
                            <Provider 
                                key={index}
                                systemIndex={systemIndex}
                                providerIndex={index} 
                                actions={actions}
                                deleteProvider={(provider,type,systemIndex,providerIndex)=>{
                                    actions.deleteProvider(provider,type,systemIndex,providerIndex)
                                    setTimeout(()=>{
                                        actions.updateSystem(
                                            this.props.system,
                                            systemIndex,
                                            type
                                        )
                                    },1000)
                                }} 
                                provider={obj}
                                type={type} 
                                updateSystem={()=>actions.updateSystem(system,systemIndex,type)}
                            />
                        )
                    }
                </div>
                <div className="col-lg-12 add-more plr0" onClick={()=>actions.pushProvider(type,systemIndex,system.landscape.landscapeId)}>
                    + Add Another Provider 
                </div>
            </section>
        )
    }
}

System.propTypes = {
    system: PropTypes.object,
    actions: PropTypes.object
}

export default System;
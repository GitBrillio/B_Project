import React, { Component } from "react";
import { Icon } from "antd";
import Arrow from './arrow.png';
import DonutChart from "../../../../common/Charts/DonutChart/DonutChart";
import "./customerSuccess.scss";

const data = [{ name: "Group A", value: 100 }, { name: "Group B", value: 100 }, { name: "Group C", value: 100 }];
const COLORS = ["#f5b43e", "#e74c3c", "#399D33", "#FF8042"];

const arrowSvg = (angle = 45) => () => (
  <svg viewBox="-100 -100 200 200">
    <g transform={`rotate(${angle})`}>
      <defs>
        <marker id="head" orient="auto" markerWidth="2" markerHeight="4" refX="0.1" refY="2">
          <path d="M0,0 V4 L2,2 Z" fill="black" />
        </marker>
      </defs>

      <path id="arrow-line" markerEnd="url(#head)" strokeWidth="5" fill="none" stroke="black" d="M0,10,0,90" />
    </g>
  </svg>
);

class SatisfactionGraph extends Component {
    getcustomClass = (color1, color2) => {
    if (color1 === "RED" && color2 === "RED") return "red";
    if (color1 === "ORANGE" && color2 === "ORANGE") return "orange";
    if (color1 === "GREEN" && color2 === "GREEN") return "green";
    if ((color1 === "RED" && color2 === "ORANGE") || (color1 === "ORANGE" && color2 === "RED")) return "red-orange";
    if ((color1 === "RED" && color2 === "GREEN") || (color1 === "GREEN" && color2 === "RED")) return "red-green";
    if ((color1 === "GREEN" && color2 === "ORANGE") || (color1 === "ORANGE" && color2 === "GREEN")) return "green-orange";
    if (color1 === "RED" || color2 === "RED") return "red";
    if (color1 === "ORANGE" || color2 === "ORANGE") return "orange";
    if (color1 === "GREEN" || color2 === "GREEN") return "green";
  };

//   getClass = arrowAngle => {
//     if (arrowAngle === 75) return "red";
//     if (arrowAngle === 220) return "orange";
//     if (arrowAngle === 330) return "green";
//     if (arrowAngle === 150) return "red-orange";
//     if (arrowAngle === 30) return "red-green";
//     if (arrowAngle === 270) return "green-orange";
//   };
  render() {
    var customClass;
    const [button1, button2] = this.props.questions.map(question =>
      question.csqOptions.filter(button => button.selected)
    );
    const hasData = button1[0] && button2[0];
    if (hasData) {
      customClass = this.getcustomClass(button1[0].color, button2[0].color);
    }

    if (!hasData) return null;
    return (
      <div>
        <DonutChart data={data} colors={COLORS} />
        {customClass && (
        //   <Icon component={arrowSvg(arrowAngle)} className={`piechart-arrow ${this.getClass(arrowAngle)}`} />
        <img src={Arrow}  className={customClass} />
        )}
      </div>
    );
  }
}

export default SatisfactionGraph;

import React, { Component } from "react";
import { Button, Collapse, Row, Col, Icon } from "antd";
import SatisfactionGraph from "./SatisfactionGraph";
import VmTextarea from "../../../../common/VmTextarea/VmTextarea";
import "./customerSuccess.scss";

const Panel = Collapse.Panel;
class Overall extends Component {
  state = {
    active: ""
  };

  submitResponse = (
    csqTypeId,
    csqTypeLabel,
    question,
    csqOptions,
    accountPlanId,
    isButton
  ) => {
    this.props.actions.submitCustomerSuccess(
      csqTypeId,
      csqTypeLabel,
      question,
      csqOptions,
      accountPlanId,
      isButton
    );
  };

  renderPanelContent = (
    question,
    outerIndex,
    innerIndex,
    csqTypeId,
    csqTypeLabel
  ) => {
    let csqOptions = question.csqOptions;
    let questionText = question.question;
    let rationale = question.rationale;

    return (
      <div className="gutter-row content">
        <div className="question-container">
          <div>
            <span className="question-number">{`Q${innerIndex + 1}:`}</span>
          </div>
          <div>
            <div className="question">{questionText}</div>
            <Row type="flex" gutter={16} className="button-container">
              {csqOptions.map((button, index) => {
                return (
                  <Col className="gutter-row" key={button.csqOptionId}>
                    <Button
                      key={button.csqOptionId}
                      className={
                        question.selectedOptionId == button.csqOptionId
                          ? `overall-button button${index}`
                          : "overall-button"
                      }
                      onClick={() => {
                        // this.submitResponse(
                        //   csqTypeId,
                        //   csqTypeLabel,
                        //   question,
                        //   csqOptions[index],
                        //   this.props.accountPlanId,
                        //   true
                        // );
                        
                        this.props.actions.updateButton(
                          outerIndex,innerIndex,index,
                          this.props.csReducer.data[outerIndex].questions[innerIndex].csqOptions[index].csqOptionId
                        );

                        setTimeout(()=>{
                          this.props.actions.updateCSXData(
                            this.props.csReducer.data[outerIndex],
                            this.props.accountPlanId,
                            index,
                            innerIndex
                          );
                        },0)
                        //console.log(outerIndex,innerIndex,index)
                        //this.setState({ active: button.csqOptionsLabel });
                      }}
                    >
                      <span
                        className={
                          question.selectedOptionId == button.csqOptionId
                            ? "button-text-active"
                            : "button-text"
                        }
                      >
                        {button.csqOptionsLabel}
                      </span>
                    </Button>
                  </Col>
                );
              })}
            </Row>
          </div>
        </div>
        <div>
          <VmTextarea
            title="Rationale"
            value={rationale}
            placeholder="Type here..."
            onChange={e => {
              this.props.actions.changeRationale(
                outerIndex,
                innerIndex,
                e.target.value
              );
            }}
            onBlur={() =>{
              // this.submitResponse(
              //   csqTypeId,
              //   csqTypeLabel,
              //   question,
              //   csqOptions[innerIndex],
              //   this.props.accountPlanId,
              //   false
              // )
              // setTimeout(()=>{
              //   this.props.actions.updateCSXData(this.props.csReducer.data[outerIndex].questions[innerIndex],this.props.accountPlanId);
              // },0)
              setTimeout(()=>{
                this.props.actions.updateCSXData(
                  this.props.csReducer.data[outerIndex],
                  this.props.accountPlanId,
                  null,
                  innerIndex
                );
              },0)
            }}
            maxLength={500}
            key={csqTypeId}
            customClass="custom-title"
          />
        </div>
      </div>
    );
  };
  renderCollapsiblePanel = customerSuccessData => {
    return (
      <div className="overall">
        {customerSuccessData.length &&
          customerSuccessData.map((element, outerIndex) => {
            return (
              <Collapse
                className="collapse-margin"
                defaultActiveKey={["1"]}
                key={element.csqTypeId}
              >
                <Panel
                  header={
                    <div className="collapse-main">
                      <span className="collapse-header">
                        {element.csqTypeLabel}
                      </span>
                    </div>
                  }
                  key={outerIndex + 1}
                >
                  <Row gutter={16}>
                    <Col span={18}>
                      {element.questions.map((question, innerIndex) => {
                        return this.renderPanelContent(
                          question,
                          outerIndex,
                          innerIndex,
                          element.csqTypeId,
                          element.csqTypeLabel
                        );
                      })}
                    </Col>
                    <Col span={6} className="chart-arrow-container">
                      <SatisfactionGraph questions={element.questions} />
                    </Col>
                  </Row>
                </Panel>
              </Collapse>
            );
          })}
      </div>
    );
  };
  render() {
    return this.renderCollapsiblePanel(this.props.data);
  }
}

export default Overall;

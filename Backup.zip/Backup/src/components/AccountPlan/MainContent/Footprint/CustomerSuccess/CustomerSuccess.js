import React, { Component } from "react";
import { Layout, Collapse } from "antd";
import PropTypes from "prop-types";
import Overall from "./Overall";
import Response from "./Response";
import "./customerSuccess.scss";
const Panel = Collapse.Panel;
const { Content } = Layout;

class CustomerSuccess extends Component {
  componentDidMount() {
    this.props.actions.getCustomerSuccess(this.props.accountPlanId);
  }
  render() {
    //console.log(this.props.customerSuccess);

    return (
      <div className="customer-success">
        <section>
          <Layout>
            <Content
              style={{
                background: "#F3F9FB",
                padding: 24,
                margin: 0,
                minHeight: 280
              }}
            >
              <h3>Footprint</h3>
              <h1>Customer Success & Satisfaction</h1>
              {this.props.customerSuccess.data.length > 0 && (
                <div>
                  <Overall
                    data={this.props.customerSuccess.data.filter(
                      e => e.hasGraph
                    )}
                    actions={this.props.actions}
                    accountPlanId={this.props.accountPlanId}
                    csReducer={this.props.customerSuccess}
                  />
                  <Response
                    response={this.props.customerSuccess.data.filter(
                      e => !e.hasGraph
                    )}
                    actions={this.props.actions}
                    accountPlanId={this.props.accountPlanId}
                  />
                </div>
              )}
            </Content>
          </Layout>
        </section>
      </div>
    );
  }
}

export default CustomerSuccess;

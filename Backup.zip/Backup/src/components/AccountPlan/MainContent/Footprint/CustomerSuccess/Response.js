import React, { Component } from "react";
import { Collapse } from "antd";
import VmTextarea from "../../../../common/VmTextarea/VmTextarea";
import "./customerSuccess.scss";

const Panel = Collapse.Panel;

class Response extends Component {
  submitResponse = (csqTypeId, csqTypeLabel, question, csqOptions, accountPlanId) => {
    this.props.actions.submitCustomerSuccess(csqTypeId, csqTypeLabel, question, csqOptions, accountPlanId);
  };
  render() {
    return (
      <div>
        {this.props.response.length &&
          this.props.response.map((element, outerIndex) => {
            return (
              <Collapse className="collapse-margin" key={element.csqTypeId}>
                <Panel
                  header={
                    <div className="collapse-main">
                      <span className="collapse-header">{element.csqTypeLabel}</span>
                    </div>
                  }
                  key={element.csqTypeId}
                >
                  {element.questions.map((response, innerIndex) => {
                    return (
                      <div className="response-textarea" key={response.csqId}>
                        <div className="question-response">{response.question}</div>
                        <VmTextarea
                          value={response.rationale}
                          key={response.csqId}
                          placeholder="Type here..."
                          onChange={e => {
                            this.props.actions.changeResponse(
                              element.csqTypeId,
                              outerIndex,
                              innerIndex,
                              e.target.value
                            );
                          }}
                          onBlur={
                            () =>
                              this.submitResponse(
                                element.csqTypeId,
                                element.csqTypeLabel,
                                element.questions[innerIndex],
                                [],
                                this.props.accountPlanId
                              ) //empty array is csqOptions
                          }
                          maxLength={500}
                        />
                      </div>
                    );
                  })}
                </Panel>
              </Collapse>
            );
          })}
      </div>
    );
  }
}

export default Response;

import React, { Component } from "react";
import { Icon, Row, Col, Collapse } from "antd";
import PropTypes from "prop-types";
import "../VMware-contracts.scss";
const Panel = Collapse.Panel;
import Filter from "../filter.png";
import VmstarContractDetails from "../Details/VmstarContractDetails";
import FilterBlock from "../FilterBlock/FilterBlock";
import { cloneDeep } from "lodash";

class VmstarContracts extends Component {
  constructor(props) {
    super(props);
  }
  state = {
    filterStatus: false,
    scopeFieldEdited: false,
    scopeVal: ""
  };
  filterOpenOrClosed(val) {
    this.setState({ filterStatus: val });
  }
  componentDidMount() {
    let data;
    data = {
      //customerId: "CUST-0002424795", // this.props.account.customerId
      customerId: this.props.account.customerId,
      limitFrom: 1,
      limitTo: 1000
    };
    this.props.actions.fetchHanaContracts(data, this.props.accountPlanId);
  }
  onChangeScope(data, index) {
    let newVmstarContract = cloneDeep(this.props.vmstarReducer.vmstarContracts);
    newVmstarContract.hanaOpportunityList[index].opportunityScope = data;
    this.props.actions.updateVmstarContracts(newVmstarContract);
  }
  render = () => {
    const { vmstarReducer, actions, accountPlanId } = this.props;
    return (
      <Collapse defaultActiveKey={["2"]} style={{ marginTop: "2.5%" }}>
        <Panel
          header={
            <div className="collapse-main">
              {vmstarReducer.vmstarContracts.hanaOpportunityList && (
                <span className="collapse-header">
                  VMstar Contracts ({vmstarReducer.vmstarContracts.hanaOpportunityList.length})
                </span>
              )}
            </div>
          }
          key="2"
        >
          <section className="vmware-contracts">
            <Row className="vmware-contracts-sel-cont">
              <Col xs={{ span: 10 }} lg={{ span: 10 }}>
                <div className="search">
                  <Icon className="icon-style" type="search" size={32} />
                  <input
                    type="text"
                    placeholder="Search Contracts"
                    onChange={e => {
                      this.props.actions.searchContracts(e);
                    }}
                  />
                </div>
              </Col>
              <Col xs={{ span: 14 }} lg={{ span: 14 }}>
                <button className="filter-btn" onClick={() => this.setState({ filterStatus: true })}>
                  <img src={Filter} width="14px" />
                  <span>Filter</span>
                </button>
              </Col>
            </Row>
            {this.state.filterStatus && (
              <FilterBlock
                handlefilterStatus={data => this.filterOpenOrClosed(data)}
                vmstarReducer={vmstarReducer}
                accountPlanId={this.props.accountPlanId}
                actions={actions}
                customerId={this.props.account.customerId}
                //customerId={"CUST-0002424795"}
              />
            )}
            {vmstarReducer.vmstarContracts.hanaOpportunityList &&
              vmstarReducer.vmstarContracts.hanaOpportunityList.map((vmstarContract, index) => {
                return (
                  <VmstarContractDetails
                    key={index}
                    actions={actions}
                    accountPlanId={accountPlanId}
                    index={index}
                    vmstarContractData={vmstarContract}
                    vmstarReducer={vmstarReducer}
                    customerId={this.props.account.customerId}
                    //customerId={"CUST-0002424795"}
                    onChangeScope={(data, index) => this.onChangeScope(data, index)}
                  />
                );
              })}
          </section>
        </Panel>
      </Collapse>
    );
  };
}

VmstarContracts.propTypes = {
  vmstarReducer: PropTypes.object,
  actions: PropTypes.object,
  accountPlanId: PropTypes.string,
  account: PropTypes.object
};

export default VmstarContracts;

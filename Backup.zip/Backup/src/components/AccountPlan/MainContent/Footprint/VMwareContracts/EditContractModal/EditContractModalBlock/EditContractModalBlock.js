import React, { Component } from "react";
import PropTypes from "prop-types";
import { Row, Col, Icon, DatePicker, Select } from "antd";
const { RangePicker } = DatePicker;
import Input from "muicss/lib/react/input";
import "./contract-modal-block.scss";
import {
  CheckboxDataArrayContracts,
  CheckedboxLabelDataString,
  ProductsArray,
  CheckedboxLabelDataArray
} from "../../../../../../../Services/CheckboxData";
import CustomDropdown from "../../../../../../common/customDropdown/CustomDropdown";
import { cloneDeep } from "lodash";
import moment from "moment";
const Option = Select.Option;

class EditContractModalBlock extends Component {
  state = {
    dropdownProduct:
      this.props.customContactsReducer.products &&
      CheckboxDataArrayContracts(
        ProductsArray(this.props.customContactsReducer.products),
        CheckedboxLabelDataArray(this.props.clickedDetailsData.products)
      ),
    labelsProduct:
      this.props.clickedDetailsData.products && CheckedboxLabelDataArray(this.props.clickedDetailsData.products),
    status: ProductsArray(this.props.customContactsReducer.status),
    renewalClick: false,
    clickedDetailsData: this.props.clickedDetailsData
  };

  onChangeCheckbox(e, i, val) {
    let checkedBox = cloneDeep(val);
    checkedBox[i].status = e.target.checked;
    this.setState({ dropdownProduct: checkedBox });
    this.setState({ labelsProduct: CheckedboxLabelDataString(checkedBox) });
    this.props.editCustomContractModalFields("products", CheckedboxLabelDataString(checkedBox), this.props.index);
    //this.props.actions.changeCustomContractModalFields("products",CheckedboxLabelDataString(checkedBox))
  }

  removeScopeOfOppurtunity = index => {
    this.setState({ renewalClick: true });
    this.props.editCustomContractModalFields("scopeOfRenewalOpportunity", "", index);
  };

  render = () => {
    const { actions } = this.props;
    return (
      <div>
        {this.props.clickedDetailsData && (
          <div className="contract-modal-block-main">
            <Row gutter={16} className="contract-block-main">
              <Col className="gutter-row custom-contract-period-main" span={8}>
                <span className="label-style-contract">CONTRACT PERIOD</span>
                <RangePicker
                  className="contract-period-select"
                  placeholder={["From..", "To.."]}
                  //onChange={this.onChangeDates}
                  value={[
                    moment(this.props.clickedDetailsData.contractFrom),
                    moment(this.props.clickedDetailsData.contractTo)
                  ]}
                  onChange={(date, dateString) => {
                    this.props.editCustomContractModalFields("contractPeriod", dateString, this.props.index);
                  }}
                />
              </Col>
              <Col span={6} className="status-main">
                <label className="label-style">Status</label>
                <Select
                  className="status-select"
                  value={this.props.clickedDetailsData.stage}
                  onChange={e => {
                    this.props.editCustomContractModalFields("status", e, this.props.index);
                  }}
                >
                  {this.state.status.map((opt, idx) => {
                    return (
                      <Option key={idx} value={opt}>
                        {opt}
                      </Option>
                    );
                  })}
                </Select>
              </Col>
              <Col span={3} className="ela-main">
                <label className="label-style">ELA</label>
                <Select
                  defaultValue="Yes"
                  value={this.props.clickedDetailsData.elaFlag ? "Yes" : "No"}
                  className="ELA-select"
                  onChange={e => {
                    this.props.editCustomContractModalFields("ela", e, this.props.index);
                  }}
                >
                  <Option value="Yes">Yes</Option>
                  <Option value="No">No</Option>
                </Select>
              </Col>
            </Row>
            <Row gutter={16} className="contract-block-row-2">
              <Col className="gutter-row" span={21}>
                <Input
                  label={"Opportunity Name *"}
                  floatingLabel={true}
                  value={this.props.clickedDetailsData.opportunityName}
                  onChange={e => {
                    this.props.editCustomContractModalFields("opportunityName", e.target.value, this.props.index);
                  }}
                />
              </Col>
              <Col className="gutter-row" span={3}>
                <Input
                  label={"Deal Value (USD)"}
                  floatingLabel={true}
                  value={this.props.clickedDetailsData.dealValue}
                  onChange={e => {
                    this.props.editCustomContractModalFields("dealValue", e.target.value, this.props.index);
                  }}
                />
              </Col>
            </Row>
            <Row gutter={16} className="contract-block-row-3">
              <Col className="gutter-row" span={24}>
                <CustomDropdown
                  class="custom-dropdown custom-grid-dropdown"
                  title="PRODUCT"
                  val={this.state.dropdownProduct}
                  selectedCheckboxes={this.state.labelsProduct}
                  products
                  placeholder="Select Product"
                  onChange={(e, key, val, title) => this.onChangeCheckbox(e, key, val, title)}
                />
              </Col>
            </Row>
            <div className="add-custom-contract">
              {this.state.renewalClick ? (
                <button onClick={() => this.setState({ renewalClick: false })}>
                  + Add Scope of Renewal Opportunity
                </button>
              ) : (
                <div className="scope-body">
                  <Input
                    label={"Scope of Renewal Opportunity"}
                    floatingLabel={true}
                    value={this.props.clickedDetailsData.opportunityScope}
                    onChange={e => {
                      this.props.editCustomContractModalFields(
                        "scopeOfRenewalOpportunity",
                        e.target.value,
                        this.props.index
                      );
                    }}
                  />
                  {/* <div className="delete-icon" onClick={()=>this.setState({renewalClick:true})}> */}
                  <div className="delete-icon" onClick={() => this.removeScopeOfOppurtunity(this.props.index)}>
                    <Icon className="minus-circle" type="minus-circle-o" />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };
}

EditContractModalBlock.propTypes = {
  customContactsReducer: PropTypes.object,
  actions: PropTypes.object,
  accountPlanId: PropTypes.string,
  type: PropTypes.string,
  clickedDetailsData: PropTypes.object,
  index: PropTypes.number,
  editCustomContractModalFields: PropTypes.func
};

export default EditContractModalBlock;

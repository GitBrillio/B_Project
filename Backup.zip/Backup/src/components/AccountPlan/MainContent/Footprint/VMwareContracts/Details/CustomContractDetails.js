import React,{Component} from 'react';
import './details.scss';
import arrow  from './arrow-key.png';
import { Row, Col, Icon,message} from 'antd';
import Input from 'muicss/lib/react/input';
import PropTypes from 'prop-types';
import EditContractModal from '../EditContractModal/EditContractModal';
import { CheckedboxLabelDataArray } from '../../../../../../Services/CheckboxData';
import {cloneDeep} from 'lodash';

class CustomContractDetails extends Component{
    state = {
        editContractModal: false,
        localEditContract: {}
    }
    editContract(){
        if(this.props.customContractData.opportunityName === null){
            message.error(`Please enter Opportunity Name`);
        }
        else{
            this.setState({ editContractModal: false });
            let newCustomContracts = cloneDeep(this.props.customContactsReducer.customContacts);
            newCustomContracts[this.props.index] = this.props.customContractData;
            this.props.actions.updateCustomContracts(newCustomContracts);
            this.props.actions.submitCustomContract(this.props.customContractData,this.props.accountPlanId,"Edit")
        }
    }
    editContractModalCancel() {
        this.setState({
            editContractModal: false
        });
        this.props.actions.resetEditContract(this.state.localEditContract,this.props.index);
    }
    deleteContract(){
        this.setState({ editContractModal: false });
        let newCustomContracts = cloneDeep(this.props.customContactsReducer.customContacts);
        newCustomContracts.splice(this.props.index,1);
        this.props.actions.updateCustomContracts(newCustomContracts);
        this.props.actions.DeleteCustomContract(this.props.customContractData,this.props.accountPlanId)
    }
    render(){
        const {customContractData,customContactsReducer} = this.props;
        return(
                <div className="details-cont">
                    <section className="details-sec">
                        <Row className="div-style">
                            <p className="para-style">No Opportunity ID available<span className="pull-right" style={{cursor:'pointer'}} onClick = {()=> this.setState({editContractModal:true,localEditContract: this.props.customContractData})}>Edit</span></p>         
                        </Row>
                        <Row className ="details-body">
                            <Col span={13} className="padding0">
                                <p className="heading-style">Opportunity Name</p>
                                <p className="regular-font">{customContractData.opportunityName}</p>
                            </Col>
                            <Col span={4} className="align-right padding0">
                                <p className="heading-style">Status</p>
                                <p className="regular-font">{customContractData.stage}</p>
                            </Col>
                            <Col span={5} className="align-right padding0">
                                <p className="heading-style">Contract Period</p>
                                <p className="regular-font">{customContractData.contractFrom && customContractData.contractTo && customContractData.contractFrom + " - " + customContractData.contractTo}</p>
                            </Col>
                            <Col span={2} className="align-right padding0">
                                <p className="heading-style">ELA</p>
                                <p className="regular-font">{customContractData.elaFlag ? "Yes":"No"}</p>
                            </Col>
                        </Row>
                        <Row className="product-main">
                                <div className="left-product">
                                    <p className="heading-style">Products</p>
                                    <div className="product-list">
                                    {
                                        customContractData.products && CheckedboxLabelDataArray(customContractData.products).map((val,idx)=>(
                                            <span key={idx}>{val}</span>
                                        ))
                                    }
                                    </div>
                                </div>
                                <div className="right-product">
                                    <span>Deal Value: </span>
                                    <span className="semi-bold-font"> $ {customContractData.dealValue}</span>
                                </div>
                        </Row>
                        <Row className="add-scope">
                                <div className="scope-body-custom">
                                    <label>Scope of Renewal Opportunity</label>
                                    <div>{customContractData.opportunityScope}</div>
                                </div>
                        </Row>
                        {customContractData && <EditContractModal
                                    actions={this.props.actions}
                                    customContactsReducer = {customContactsReducer}
                                    clickedDetailsData = {customContractData}
                                    visible={this.state.editContractModal}
                                    heading = {"Edit Contract"}
                                    edit = {()=>this.editContract()}
                                    delete = {()=>this.deleteContract()}
                                    okText= {"Save" }
                                    index = {this.props.index}
                                    handleCancel={() => this.editContractModalCancel()}
                                    accountPlanId={this.props.accountPlanId}
                                    editCustomContractModalFields={this.props.editCustomContractModalFields}
                                />
                        }
                    </section>
                </div>
                
        )
    }
}
CustomContractDetails.propTypes = {
    index: PropTypes.number,
    customContractData: PropTypes.object,
    handleContractEdit: PropTypes.any,
    actions: PropTypes.any,
    accountPlanId:PropTypes.string,
    customContactsReducer: PropTypes.object,
    editCustomContractModalFields: PropTypes.func
}

export default CustomContractDetails;
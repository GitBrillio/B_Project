import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button} from 'antd';
import './contract-modal.scss';
import EditContractModalBlock from './EditContractModalBlock/EditContractModalBlock';

class EditContractModal extends Component {
    render = () => {
        const { visible,heading,okText,handleCancel} = this.props
      
        return (
            <div className="contract-modal-main">
                <Modal
                    className="contract-modal"
                    title={heading}
                    visible={visible}
                    centered
                    onCancel={handleCancel}
                    footer={[
                        <Button key="submit" disabled={this.props.clickedDetailsData.opportunityName === '' ? true : false} className="pull-right" type="primary" onClick={this.props.edit}>
                            {okText} 
                        </Button>,
                        <Button key="submit" className="delete-btn" type="danger" onClick={this.props.delete}>
                            Delete
                        </Button>,
                    ]}
                >
                    <EditContractModalBlock 
                        actions={this.props.actions} 
                        customContactsReducer ={this.props.customContactsReducer}
                        accountPlanId={this.props.accountPlanId}
                        type={this.props.type}
                        clickedDetailsData = {this.props.clickedDetailsData}
                        index = {this.props.index}
                        editCustomContractModalFields={this.props.editCustomContractModalFields}
                    />
                </Modal>
                
        </div>)
    }
}

EditContractModal.propTypes = {
    actions: PropTypes.object,
    customContactsReducer:PropTypes.object,
    visible: PropTypes.bool.isRequired,
    heading:PropTypes.string,
    okText: PropTypes.string,  
    handleCancel: PropTypes.func,
    edit: PropTypes.any,
    delete: PropTypes.func,
    type: PropTypes.string,
    accountPlanId: PropTypes.string,
    clickedDetailsData: PropTypes.object,
    index: PropTypes.number,
    editCustomContractModalFields: PropTypes.func
}

export default EditContractModal;

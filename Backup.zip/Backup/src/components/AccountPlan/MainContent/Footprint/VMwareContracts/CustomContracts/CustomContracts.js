import React, { Component } from "react";
import { Collapse, message } from "antd";
import PropTypes from "prop-types";
import "../VMware-contracts.scss";
const Panel = Collapse.Panel;
import CustomContractDetails from "../Details/CustomContractDetails";
import ContractModal from "../ContractModal/ContractModal";
import { cloneDeep } from "lodash";

class CustomContracts extends Component {
  constructor(props) {
    super(props);
  }
  state = {
    newContractModal: false,
    filterStatus: false,
    index: 0,
    clickedDetailsData: {}
  };
  createContract() {
    if (this.props.customContactsReducer.inputs.opportunityName === null) {
      message.error(`Please enter Opportunity Name`);
    } else {
      this.setState({ newContractModal: false });
      this.props.actions.submitCustomContract(
        this.props.customContactsReducer.inputs,
        this.props.accountPlanId,
        "Create"
      );
    }
    //this.props.actions.updateCustomContracts([]);
  }
  newContractModalCancel() {
    this.setState({
      newContractModal: false
    });
  }
  filterOpenOrClosed(val) {
    this.setState({ filterStatus: val });
  }
  handleContractEdit(modalVisibility, idx, clickedDetailsData) {
    this.setState({
      newContractModal: modalVisibility,
      type: "Edit",
      index: idx,
      clickedDetailsData: clickedDetailsData
    });
  }
  editCustomContractModalFields(title, val, index) {
    let newCustomContracts = cloneDeep(this.props.customContactsReducer.customContacts);

    switch (title) {
      case "contractPeriod":
        newCustomContracts[index].contractFrom = val[0];
        newCustomContracts[index].contractTo = val[1];
        this.props.actions.updateCustomContracts(newCustomContracts);
        break;
      case "status":
        newCustomContracts[index].stage = val;
        this.props.actions.updateCustomContracts(newCustomContracts);
        break;
      case "ela":
        if (val === "Yes") {
          newCustomContracts[index].elaFlag = 1;
        } else {
          newCustomContracts[index].elaFlag = 0;
        }
        this.props.actions.updateCustomContracts(newCustomContracts);
        break;
      case "opportunityName":
        newCustomContracts[index].opportunityName = val;
        this.props.actions.updateCustomContracts(newCustomContracts);
        break;
      case "dealValue":
        newCustomContracts[index].dealValue = val;
        this.props.actions.updateCustomContracts(newCustomContracts);
        break;
      case "scopeOfRenewalOpportunity":
        newCustomContracts[index].opportunityScope = val;
        this.props.actions.updateCustomContracts(newCustomContracts);
        break;
      case "products":
        newCustomContracts[index].products = val;
        this.props.actions.updateCustomContracts(newCustomContracts);
        break;
    }
  }
  render = () => {
    const { customContactsReducer, actions, accountPlanId } = this.props;

    return (
      <Collapse>
        <Panel
          header={
            <div className="collapse-main">
              {customContactsReducer.customContacts && (
                <span className="collapse-header">
                  Custom Contracts ({customContactsReducer.customContacts.length})
                </span>
              )}
            </div>
          }
          key="1"
        >
          <section className="vmware-contracts">
            <div className="new-contract-btn text-center">
              <button className="new-contract-sub-btn" onClick={() => this.setState({ newContractModal: true })}>
                Create New Contract
              </button>
            </div>
            {customContactsReducer.customContacts &&
              customContactsReducer.customContacts.map((customContract, index) => {
                return (
                  <CustomContractDetails
                    key={index}
                    actions={actions}
                    accountPlanId={accountPlanId}
                    index={index}
                    customContractData={customContract}
                    customContactsReducer={customContactsReducer}
                    editCustomContractModalFields={(title, val, index) =>
                      this.editCustomContractModalFields(title, val, index)
                    }
                    handleContractEdit={(modalVisibility, idx, customContractData) =>
                      this.handleContractEdit(modalVisibility, index, customContractData)
                    }
                  />
                );
              })}
            {this.state.newContractModal && customContactsReducer && (
              <ContractModal
                actions={actions}
                customContactsReducer={customContactsReducer}
                clickedDetailsData={this.state.clickedDetailsData}
                visible={this.state.newContractModal}
                heading={"Create New Contract"}
                create={() => this.createContract()}
                okText={"Create"}
                handleCancel={() => this.newContractModalCancel()}
                accountPlanId={this.props.accountPlanId}
                index={this.state.index}
              />
            )}
          </section>
        </Panel>
      </Collapse>
    );
  };
}

CustomContracts.propTypes = {
  customContactsReducer: PropTypes.object,
  actions: PropTypes.object,
  accountPlanId: PropTypes.string
};

export default CustomContracts;

import React, { Component } from "react";
import { Layout, Icon, Collapse } from "antd"; //Input
import "./compute-network-storage.scss";
import PropTypes from "prop-types";
import FWComponents from './../EndUserComputing/FWComponents';
import FWHeader from './../Header/FWHeader';

const Panel = Collapse.Panel;

class ComputeNetworkStorage extends Component {
  constructor(props) {
    super(props);
    this.state = {
        header: {
          title: "Compute, Network and Storage",
          revenue: "$14M",
          booking: "Bookings FY18",
          infoIcon: {
            title: "CNS Title",
            content: "CNS Content"
          },
          timestamp: {
            title: "Last Updated",
            author: "John Smith",
            date: "Aug 11 2017"
          }
        }
      };
  }
  render() {
    const {items, status} = this.props.footprint.footPrintAndWhiteSpace;
    let endUserComputingProducts = [];
    let footprintWhitespaceId = null
    if(typeof items !== 'undefined' && items.length > 0){
       endUserComputingProducts = items[2].products;
       footprintWhitespaceId = items[2].footprintWhitespaceId
    }
    
    return (
        <Collapse className="euc">
        <Panel header={<FWHeader headerInfo={this.state.header} />} key="1">
          <section>
            <div className="iot-wrapper">
              {endUserComputingProducts.map((product, i) => {
                let productDeploymentStatus = status.filter(statusObj => statusObj.deploymentStatusId === product.deploymentStatusId);
                let productStatus = productDeploymentStatus[0];
                return <FWComponents 
                  product={product}
                  key={i}
                  status={productStatus}
                  statusMenu={status}
                  actions={this.props.actions}
                  accountPlanId={this.props.accountPlanId}
                  footprintWhitespaceId={footprintWhitespaceId}
                  />;
              })}
            </div>
          </section>
        </Panel>
      </Collapse>
    )
  }
}

ComputeNetworkStorage.propTypes = {
    actions: PropTypes.object,
    footprintReducer: PropTypes.object,
    accountPlanId: PropTypes.string
}

ComputeNetworkStorage.defaultProps = {
    actions: {},
    footprintReducer: {},
    accountPlanId: ""
}

export default ComputeNetworkStorage;

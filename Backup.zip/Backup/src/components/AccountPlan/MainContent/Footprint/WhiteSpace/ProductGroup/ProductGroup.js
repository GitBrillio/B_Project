import React, { Component } from "react";
import {  Collapse } from "antd";
import "../EndUserComputing/end-user-computing.scss";
import PropTypes from "prop-types";
import FWHeader from "../Header/FWHeader";
import FWComponents from "../EndUserComputing/FWComponents";

const Panel = Collapse.Panel;

const panelHeader = {
    EUC: 'End User Computing',
    SERVICES: 'Services',
    SDDC: 'SDDC',
    CPS: 'Cloud Provider Software'
}

class ProductGroup extends Component {
  constructor(props) {
    super(props);
    
  }
  render() {
    const { status,footprint,accountPlanId,actions,previousBookings} = this.props;
    
    return (
      <Collapse defaultActiveKey={["1"]} className="euc">
        <Panel header={<FWHeader 
          headerInfo={panelHeader[footprint.productCategory]} 
          bookings={previousBookings.service[footprint.productCategory]}
        />} key="1">
          <section>
            <div className="iot-wrapper">
              {footprint.products.map((product, i) => {
                let productDeploymentStatus = status.filter(statusObj => statusObj.deploymentStatusId === product.deploymentStatusId);
                let productStatus = productDeploymentStatus[0];
                return <FWComponents 
                product={product}
                key={i}
                accountPlanId={accountPlanId}
                status={productStatus}
                footprintWhitespaceId={footprint.footprintWhitespaceId}
                statusMenu={status}
                actions={actions}
                />;
              })}
            </div>
          </section>
        </Panel>
      </Collapse>
    );
  }
}

ProductGroup.propTypes = {
  actions: PropTypes.object,
  accountPlanId: PropTypes.string,
  footprint: PropTypes.array,
  status: PropTypes.array
};

ProductGroup.defaultProps = {
  actions: {},
  footprint: {},
  accountPlanId: ""
};

export default ProductGroup;

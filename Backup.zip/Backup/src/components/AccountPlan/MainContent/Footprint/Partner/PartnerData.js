import React from 'react';
import {  Row, Col} from "antd";
import trash from "../../../../../images/trash.svg";
import PropTypes from 'prop-types';

const PartnerData = ({data,editPartner,deletePartner}) => {
    return (
        <div>
            <section>
                    <div className="partnerTypes">
                        <h3 className="heading">{data.partnerName}</h3>
                        <div className="bottomLine" />
                        <Row style={{ margin: 12 }}>
                            <Col span={12}>
                                <h3 className="focusArea">Focus Area</h3>
                                <div className="focusArea-data">{data.focusArea}</div>
                            </Col>
                            <Col span={12}>
                                <Row>
                                    <Col span={8}>
                                        <h3 className="type-heading">Role</h3>
                                        <span>{data.roleName}</span>
                                    </Col>
                                    <Col span={8}>
                                        <h3 className="type-heading">Attitude</h3>
                                        <span>{data.attitudeName}</span>
                                    </Col>
                                    <Col span={8}>
                                        <h3 className="type-heading">Engagement</h3>
                                        <span>{data.engagementName}</span>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                        <Row style={{ margin: 12 }}>
                            <Col span={12}>
                                <Row>
                                    <Col span={12}>
                                        <h3 className="focusArea">Key People</h3>
                                        {
                                            data.keyPeoples.map((kp,i)=>(
                                                <div key={i}>
                                                    <span>{kp.keyPeopleName}</span>
                                                    <span>({kp.keyPeopleRole})</span>
                                                </div>
                                            ))
                                        }
                                    </Col>
                                    
                                </Row>
                            </Col>
                            <Col span={12}>
                                <div className="revenue-amount">
                                    <Row>
                                        <Col span={12}>
                                            <span className="revenueAmount-heading">Annual Revenues:</span>
                                            <span><b> ${data.annualRevenue}</b></span>
                                        </Col>
                                        <Col span={12}>
                                            <span className="revenueAmount-heading">Opportunity Amount:</span>
                                            <span>
                                                <b> ${data.opportunityAmount}</b>
                                            </span>
                                        </Col>
                                    </Row>
                                </div>
                            </Col>
                        </Row>

                        <h3 className="nextStep">Next Steps</h3>
                        <ul className="next-steps">
                            {
                                data.nextStep.map((nextStep,index)=>(
                                    <li key={index}>{nextStep}</li>
                                ))
                            }
                        </ul>
                        <div className="button-wrap">
                            <button onClick={()=>editPartner(data)} className="edit-button">Edit</button>
                            <div className="delete-icon" onClick={()=>deletePartner(data)}>
                                <img src={trash} title="Delete mission critical system" alt="Delete System" />
                            </div>
                        </div>
                    </div>
                </section>
        </div>
    );
};
PartnerData.propTypes = {
    data: PropTypes.object,
    editPartner: PropTypes.func,
    deletePartner: PropTypes.func
}
export default PartnerData;
import React from 'react';
import {  Collapse} from "antd";
import PartnerData from './PartnerData';
import PropTypes from 'prop-types';
const Panel = Collapse.Panel;


const PartnerBox = ({partner,editPartner,deletePartner}) => {
    return (
        <Collapse defaultActiveKey={["1"]}>
            <Panel
                header={
                    <div className="collapse-main">
                        <span className="collapse-header">{partner.label} ({partner.footprintPartners.length})</span>
                    </div>
                }
                key={1}
            >
                {
                    partner.footprintPartners.map((fp,i)=>(
                        <PartnerData deletePartner={deletePartner} editPartner={editPartner} key={i} data={fp} />
                    ))
                }
                
            </Panel>
        </Collapse>
    );
};
PartnerBox.propTypes = {
    partner: PropTypes.object,
    editPartner: PropTypes.func,
    deletePartner: PropTypes.func
}
export default PartnerBox;
import React, { Component } from "react";
import PropTypes from "prop-types";
import { Modal, Button, Row, Col, Icon, Layout, Radio } from "antd";
const { Content } = Layout;
const RadioGroup = Radio.Group;
import Input from "muicss/lib/react/input";
import "./AddNewPartner.scss";

export default class AddNewPartner extends Component {
  componentDidMount() {
    this.props.actions.fetchPartnerTypes(this.props.accountPlanId);
    if (this.props.partnerStructure.fpId !== null) {
      this.props.actions.getRadios(this.props.partnerStructure.partnerTypeId, this.props.accountPlanId);
    }
  }
  TargetValueCheckAnnualRevenue(e) {
    const re = /^[0-9\b]+$/;
    if (e.target.value === "" || re.test(e.target.value)) {
      this.props.actions.changeKeyPartner("annualRevenue", e.target.value);
    }
  }
  TargetValueCheckOpportunityAmount(e) {
    const re = /^[0-9\b]+$/;
    if (e.target.value === "" || re.test(e.target.value)) {
      this.props.actions.changeKeyPartner("opportunityAmount", e.target.value);
    }
  }

  render = () => {
    const { partnerStructure } = this.props;
    return (
      <div className="add-partner-modal">
        <Modal
          className="add-edit-focus-popup"
          title="Add New Partner"
          visible={this.props.visible}
          centered
          onCancel={() => this.props.handleCancel()}
          footer={[
            <Button
              key="submit"
              disabled={!partnerStructure.partnerTypeId || partnerStructure.partnerName.length === 0}
              className="submit-btn"
              type="primary"
              onClick={() => this.props.savePartner(!this.props.partnerStructure.fpId ? "Save" : "Update")}
            >
              {!this.props.partnerStructure.fpId ? "Save" : "Update"}
            </Button>
          ]}
        >
          <section className="add-partner">
            <Layout>
              <Content>
                <h3 className="partner-type">Select Partner Type</h3>

                <div>
                  <Radio.Group
                    value={partnerStructure.partnerTypeId}
                    onChange={e => {
                      this.props.actions.changeKeyPartner("partnerTypeId", e.target.value);
                      this.props.actions.getRadios(e.target.value, this.props.accountPlanId);
                    }}
                    buttonStyle="solid"
                  >
                    {this.props.partnerReducer.partnerTypes.map((p, i) => (
                      <Radio.Button key={i} value={p.id}>
                        {p.label}
                      </Radio.Button>
                    ))}
                  </Radio.Group>
                </div>
                <Row gutter={24} style={{ marginTop: 25 }}>
                  <Col span={6}>
                    <Input
                      label={"ENTER COMPANY NAME*"}
                      value={partnerStructure.partnerName}
                      onChange={e => this.props.actions.changeKeyPartner("partnerName", e.target.value)}
                      floatingLabel={true}
                      autoComplete="off"
                    />
                  </Col>
                  <Col span={6} />
                  <Col span={6}>
                    <Input
                      label={"ENTER ANNUAL REVENUES"}
                      value={partnerStructure.annualRevenue}
                      onChange={e => this.TargetValueCheckAnnualRevenue(e)}
                      floatingLabel={true}
                      autoComplete="off"
                    />
                  </Col>
                  <Col span={6}>
                    <Input
                      label={"ENTER OPPORTUNITY AMOUNT"}
                      value={partnerStructure.opportunityAmount}
                      onChange={e => this.TargetValueCheckOpportunityAmount(e)}
                      floatingLabel={true}
                      autoComplete="off"
                    />
                  </Col>
                </Row>
                <Row gutter={24}>
                  <Col span={18}>
                    <Input
                      label="ENTER FOCUS AREA"
                      value={partnerStructure.focusArea}
                      onChange={e => this.props.actions.changeKeyPartner("focusArea", e.target.value)}
                      floatingLabel={true}
                      autoComplete="off"
                    />
                  </Col>
                  {/* <Col span={6}>
                    {" "}
                    <Input label={"Attach JOINT OPPORTUNITY"}
                      value={partnerStructure.opportunityId}
                      onChange={(e) => this.props.actions.changeKeyPartner('opportunityId', e.target.value)}
                      floatingLabel={true} autoComplete="off" />
                  </Col> */}
                </Row>
                <Row className="partner-group">
                  <Col span={5} className="partner-type">
                    Select SiSo role
                  </Col>
                  <Col span={19}>
                    <RadioGroup
                      name="radiogroup"
                      onChange={e => this.props.actions.changeKeyPartner("roleId", e.target.value)}
                      value={partnerStructure.roleId}
                    >
                      {this.props.partnerReducer.role.map((p, i) => (
                        <Radio key={i} value={p.id}>
                          {p.label}
                        </Radio>
                      ))}
                    </RadioGroup>
                  </Col>
                </Row>
                <Row className="partner-group">
                  <Col span={5} className="partner-type">
                    Attitude vs VMW
                  </Col>
                  <Col span={19}>
                    <RadioGroup
                      onChange={e => this.props.actions.changeKeyPartner("attitudeId", e.target.value)}
                      name="radiogroup"
                      value={partnerStructure.attitudeId}
                    >
                      {this.props.partnerReducer.attitude.map((p, i) => (
                        <Radio key={i} value={p.id}>
                          {p.label}
                        </Radio>
                      ))}
                    </RadioGroup>
                  </Col>
                </Row>
                <Row className="partner-group">
                  <Col span={5} className="partner-type">
                    Engagement with Partner
                  </Col>
                  <Col span={19}>
                    <RadioGroup
                      name="radiogroup"
                      onChange={e => this.props.actions.changeKeyPartner("engagementId", e.target.value)}
                      value={partnerStructure.engagementId}
                    >
                      {this.props.partnerReducer.engagement.map((p, i) => (
                        <Radio key={i} value={p.id}>
                          {p.label}
                        </Radio>
                      ))}
                    </RadioGroup>
                  </Col>
                </Row>
                <Row style={{ marginTop: 25 }}>
                  <Col span={12}>
                    {partnerStructure.keyPeoples.map((keyPeople, index) => (
                      <Row gutter={24} key={index}>
                        <Col span={11}>
                          <Input
                            label={"ENTER KEY PEOPLE"}
                            value={keyPeople.keyPeopleName}
                            floatingLabel={true}
                            onChange={e => this.props.actions.changeKeyPeople("keyPeopleName", index, e.target.value)}
                            autoComplete="off"
                          />
                        </Col>
                        <Col span={11}>
                          <Input
                            label={"ENTER KEY PEOPLE ROLE"}
                            value={keyPeople.keyPeopleRole}
                            onChange={e => this.props.actions.changeKeyPeople("keyPeopleRole", index, e.target.value)}
                            floatingLabel={true}
                            autoComplete="off"
                          />
                        </Col>
                        <Col>
                          <Icon
                            style={{ marginTop: "20px", cursor: "pointer" }}
                            type="minus-circle"
                            onClick={() => this.props.actions.deletePartnerKeyPeople(index)}
                          />
                        </Col>
                      </Row>
                    ))}
                    <button onClick={() => this.props.actions.addNewKeyPeople()} className="add-more">
                      + Add {partnerStructure.keyPeoples.length > 0 ? "Another" : "Key People"}
                    </button>
                  </Col>
                  <Col span={12} />
                </Row>
                <div style={{ marginTop: 12 }}>
                  {partnerStructure.nextStep.map((nextStep, index) => (
                    <Row key={index}>
                      <Col span="22">
                        <Input
                          label={`NEXT STEP ${index + 1}`}
                          key={index}
                          value={nextStep}
                          onChange={e => this.props.actions.changePartnerNextStep(index, e.target.value)}
                          floatingLabel={true}
                          autoComplete="off"
                        />
                      </Col>
                      <Col span="2">
                        <Icon
                          style={{ marginTop: "20px", cursor: "pointer" }}
                          type="minus-circle"
                          onClick={() => this.props.actions.deletePartnerNextStep(index)}
                        />
                      </Col>
                    </Row>
                  ))}
                  <button onClick={() => this.props.actions.addPartnerNextStep()} className="add-more">
                    + Add {partnerStructure.nextStep.length > 0 ? "Another" : "Next Step"}
                  </button>
                </div>
              </Content>
            </Layout>
          </section>
        </Modal>
      </div>
    );
  };
}
AddNewPartner.propTypes = {
  actions: PropTypes.object,
  accountPlanId: PropTypes.string,
  partnerReducer: PropTypes.object,
  visible: PropTypes.bool,
  handleCancel: PropTypes.func,
  ok: PropTypes.func,
  partnerStructure: PropTypes.object,
  savePartner: PropTypes.func
};

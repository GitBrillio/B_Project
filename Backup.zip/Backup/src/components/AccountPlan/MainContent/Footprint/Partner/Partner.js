import React, { Component } from "react";
import "./Partner.scss";
import { Row, Col, Icon, Layout } from "antd";
const { Content } = Layout;
import AddNewPartner from "./AddNewPartner/AddNewPartner";
import PartnerBox from "./PartnerBox";
import DeletePopup from "../../../../common/DeletePopup/DeletePopup";
import PropTypes from 'prop-types';

class Partners extends Component {
  state = {
    showCreateArea: false,
    confirmDelete: false,
    deleteContent: null,
    index: null,
    innerIndex: null,
    deletePopup: false,
    searching: false
  };


  componentDidMount() {
    this.props.actions.fetchPartners(this.props.accountPlanId)
  }

  addNewPartner() {
    this.setState({
      showCreateArea: true
    });
  }

  addPartner() {
    this.setState({
      showCreateArea: false
    });
  }

  handleDelete(index) {
    this.setState({
      confirmDelete: false
    });
  }

  handleCancel() {
    this.setState({
      showCreateArea: false
    });
  }

  ConfHandleCancel() {
    this.setState({ confirmDelete: false });
  }

  savePartner(type) {

    this.props.actions.savePartner(
      this.props.partnerReducer.partnerStructure,
      this.props.accountPlanId,
      type === 'Save' ? 'create' : 'update'
    );
    this.setState({ showCreateArea: false });


  }


  editPartner(partner) {
    this.props.actions.setPartner(partner);
    this.setState({ showCreateArea: true });
  }


  // Delete 

  deletePartner(partner) {
    this.setState({ deleting: true, delObj: partner });
  }

  deleteOk() {
    this.props.actions.deletePartner(this.props.accountPlanId, this.state.delObj);
    this.setState({ deleting: false });
  }

  deleteCancel() {
    this.setState({ deleting: false });
  }
  
  handleKeyPress(e) {
  
    this.setState({
      searching: true
    })
    this.props.actions.searchPartners(this.props.accountPlanId, e.target.value);
  
  }

  render = () => {
    const { partners } = this.props.partnerReducer
    return (
      <section className="partners">
        <Layout>
          <Content style={{ padding: 24, margin: 0 }}>
            <h3 className="Footprint">Footprint</h3>
            <h1 className="Partners">Partners</h1>

            {partners.length === 0 && !this.state.searching ? (
              <div>
                <div className="add-partners">
                  <button className="dashed-btn" type="dashed" onClick={() => this.addNewPartner()}>
                    Add New Partner Details
                  </button>
                </div>
              </div>
            ) : (
                <div>
                  <Row>
                    <Col span={12}>
                      <Icon className="icon-style" type="search" size={32} />
                      <input type="text"
                        placeholder="Search Partners"
                        value={this.state.searchText}
                        onKeyUp={(e) => this.handleKeyPress(e)}
                        style={{ paddingLeft: 25 }}
                      />
                    </Col>
                    <Col span={12}>
                      <button className="create-new-partner" onClick={() => this.addNewPartner()}>
                        Add New Partner
                    </button>
                    </Col>
                  </Row>

                  <div style={{ marginTop: 20 }}>
                    {
                      this.props.partnerReducer.partners.map((p, i) => (
                        <PartnerBox
                          editPartner={this.editPartner.bind(this)}
                          key={i}
                          partner={p}
                          deletePartner={this.deletePartner.bind(this)}
                        />
                      ))
                    }

                  </div>
                </div>
              )}
            {this.state.showCreateArea ? (
              <AddNewPartner
                visible={this.state.showCreateArea}
                handleCancel={() => this.handleCancel()}
                actions={this.props.actions}
                ok={() => this.addPartner()}
                partnerStructure={this.props.partnerReducer.partnerStructure}
                accountPlanId={this.props.accountPlanId}
                partnerReducer={this.props.partnerReducer}
                savePartner={this.savePartner.bind(this)}
              />
            ) : null}
          </Content>
        </Layout>
        {
          this.state.deleting &&
          <DeletePopup
            heading="Delete Mission Critical System"
            visible={this.state.deleting}
            ok={() => this.deleteOk()}
            cancel={() => this.deleteCancel()}
            okText="Yes delete it"
            cancelText="No, cancel it"
            contents="Are you sure you want to delete this partner?"
          />
        }
      </section>
    );
  };
}

Partners.propTypes = {
  actions: PropTypes.object,
  accountPlanId: PropTypes.string,
  partnerReducer: PropTypes.object
}

export default Partners;

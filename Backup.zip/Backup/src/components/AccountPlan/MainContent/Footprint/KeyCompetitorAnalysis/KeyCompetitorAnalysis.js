import React, { Component } from "react";
import AddNewKeyCompetitor from "./AddNewKeyCompetitor/AddNewKeyCompetitor";
import "./KeyCompetitorAnalysis.scss";
import trash from "../../../../../images/trash.svg";
import { Layout, Button, Collapse, Row, Col } from 'antd';
const { Content } = Layout;
import _ from 'underscore';
import PropTypes from "prop-types";
import DeletePopup from "../../../../common/DeletePopup/DeletePopup";

const propTypes = {
  footprintReducer: PropTypes.object,
  actions: PropTypes.object,
  accountPlanId: PropTypes.string
};

export default class KeyCompetitorAnalysis extends Component {
  state = {
    showKeyCompetitorArea: false,
    editing: false
  };
  componentDidMount() {
    this.props.actions.getCometitorsName(this.props.accountPlanId);
    this.props.actions.getRelativeRating(this.props.accountPlanId);
    this.props.actions.getELA(this.props.accountPlanId);
    this.props.actions.getKeyCompetitor(this.props.accountPlanId);
  }

  saveKCA() {
    this.props.actions.saveKCA(this.props.accountPlanId, this.props.footprintReducer.kcaPostData);
    this.handleCancel();
  }

  updateKCA() {
    this.props.actions.updateKCA(this.props.accountPlanId, this.props.footprintReducer.kcaPostData);
    this.handleCancel();
  }

  deleteKCA(kcaId, index) {
    let curCompetitorDel = _.filter(this.props.footprintReducer.keyCompetitor, (curCompetitor, key) => {
      return curCompetitor.kcaId == kcaId;
    });
    this.props.actions.deleteKCA(this.props.accountPlanId, curCompetitorDel[0], index);
    this.handleCancel();
  }

  handleCancel() {
    this.setState({
      showKeyCompetitorArea: false
    });
    this.props.actions.resetkcaPostData();
  }

  getCompetitorForEdit(kcaId) {
    let curCompetitor = _.filter(this.props.footprintReducer.keyCompetitor, (curCompetitor) => {
      return curCompetitor.kcaId == kcaId;
    });
    this.props.actions.getCompetitorForEdit(curCompetitor[0]);
    setTimeout(() => {
      this.setState({
        showKeyCompetitorArea: true,
        editing: true
      });
    }, 0)
  }

  addNewKeyCompetitor() {
    this.setState({
      showKeyCompetitorArea: true,
      editing: false
    });
  }

  getLabel(id, keyName) {
    let labelName = _.filter(this.props.footprintReducer[`${keyName}`], (val) => {
      return val.id == id;
    });
    if (labelName[0]) {
      return labelName[0].label;
    }
  }

  render() {
    const { footprintReducer, actions, accountPlanId } = this.props;
    console.log("footprintReducer", footprintReducer);
    return (
      <section className="keyCompetitorAnalysis">
        <Layout>
          <Content style={{ padding: 24, margin: 0 }}>
            <h3 className="Footprint">Footprint</h3>
            <h1 className="Key-Competitor-Analysis">Key Competitor Analysis</h1>

            {footprintReducer.keyCompetitor.length == 0 ? (
              <div className="key-competitor">
                <Button className="dashed-btn" type="dashed" onClick={() => this.addNewKeyCompetitor()}>
                  Create New Key Competitor Analysis
                </Button>
              </div>
            ) : (
                <div>
                  <button className="create-newkeycompetitor" onClick={() => this.addNewKeyCompetitor()}>
                    Create New Key Competitor Analysis
                </button>

                  {footprintReducer.keyCompetitor && footprintReducer.keyCompetitor.map((keycompetitor, index) => (
                    <div className="details-cont" key={index}>
                      <section className="details-sec">
                        <Row className="div-style">
                          <Col span={22} className="padding0">
                            <p className="para-style"><span>{this.getLabel(keycompetitor.competitorId, "keyCompetitorName")}</span></p>
                          </Col>
                          <Col span={1} className="padding0">
                            <p className="edit-button">
                              <span onClick={() => this.getCompetitorForEdit(keycompetitor.kcaId)}>EDIT</span>
                            </p>
                          </Col>
                          <Col span={1} className="padding0">
                            <p className="delete-icon"><span onClick={() => {
                              this.setState({
                                isDeleting: true,
                                kcaId: keycompetitor.kcaId,
                                index: index
                              })
                            }}> <img src={trash} title="Delete Key compitator" alt="Delete System" /></span></p>
                          </Col>
                        </Row>
                        <Row className="details-body">
                          <Col span={12} className="padding0">
                            <p className="heading-style">Current Customer Relationship</p>
                            <p className="regular-font">
                              {keycompetitor.customerRelationship}
                            </p>
                          </Col>
                          <Col span={4} className="align-right padding0">
                            <p className="heading-style">Relative Rating</p>
                            <p className="regular-font">
                              {this.getLabel(keycompetitor.severityId, "keyCompetitorRR")}
                            </p>
                          </Col>
                          <Col span={4} className="align-right padding0">
                            <p className="heading-style">Existing ELA</p>
                            <p className="regular-font">
                              {this.getLabel(keycompetitor.elaId, "keyCompetitorELA")}
                            </p>
                          </Col>
                          <Col span={4} className="align-right padding0">
                            <p className="heading-style">Expiry Date</p>
                            <p className="regular-font">
                              {keycompetitor.expiryDate}
                            </p>
                          </Col>
                        </Row>
                        <Row className="details-body">
                          <Col span={6} className="padding0">
                            <p className="heading-style">Data Center Solution</p>
                            <p className="regular-font">
                              {keycompetitor.dataCenterSolution.toString()}
                            </p>
                          </Col>
                          <Col span={6} className="padding0">
                            <p className="heading-style">Hybrid cloud Solution</p>
                            <p className="regular-font">
                              {keycompetitor.hybridCloudSolution.toString()}
                            </p>
                          </Col>
                          <Col span={6} className="padding0">
                            <p className="heading-style">Security Solution</p>
                            <p className="regular-font">
                              {keycompetitor.securitySolution.toString()}
                            </p>
                          </Col>
                          <Col span={6} className="padding0">
                            <p className="heading-style">Digital Workspace Solution</p>
                            <p className="regular-font">
                              {keycompetitor.digitalWorkspaceSolution.toString()}
                            </p>
                          </Col>
                        </Row>
                        <Row className="details-body">
                          <Col span={24} className="padding0">
                            <p className="heading-style">Providers Key Strength/Key Weakness</p>
                            <p className="regular-font">
                              {keycompetitor.strengthOrWeakness}
                            </p>
                          </Col>
                        </Row>
                        <Row className="details-body">
                          <Col span={24} className="padding0">
                            <p className="heading-style">VMW Opportunity/Threat</p>
                            <p className="regular-font">
                              {keycompetitor.opportunityOrThreat}
                            </p>
                          </Col>
                        </Row>
                      </section>
                    </div>
                  ))}
                  {
                    this.state.isDeleting &&
                    <DeletePopup 
                        heading="Delete Key Competator"
                        visible={this.state.isDeleting} 
                        ok={()=>{
                          this.deleteKCA(this.state.kcaId, this.state.index);
                          this.setState({
                            isDeleting: false
                          })
                        }} 
                        cancel={()=>{
                          this.setState({
                            isDeleting: false
                          })
                        }} 
                        okText="Yes delete it" 
                        cancelText="No, cancel it" 
                        contents="Are you sure you want to delete this key competator?" 
                    /> 
                  }
                </div>
              )}
            {this.state.showKeyCompetitorArea ? (
              <AddNewKeyCompetitor
                visible={this.state.showKeyCompetitorArea}
                handleCancel={() => this.handleCancel()}
                saveKCA={() => this.saveKCA()}
                updateKCA={() => this.updateKCA()}
                footprintReducer={footprintReducer}
                actions={actions}
                editing={this.state.editing}
                accountPlanId={accountPlanId}
              />
            ) : null}
          </Content>
        </Layout>
      </section>
    );
  }
}

KeyCompetitorAnalysis.propTypes = propTypes;

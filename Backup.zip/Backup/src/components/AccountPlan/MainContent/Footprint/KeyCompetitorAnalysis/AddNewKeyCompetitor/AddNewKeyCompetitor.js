import React, { Component } from "react";
import { Modal, Layout, Button, Row, Col, DatePicker } from "antd";
import PropTypes from "prop-types";
const { Content } = Layout;
import Input from "muicss/lib/react/input";
import "./addNewKeyCompetitor.scss";
import moment from "moment";
import VmSelect from "../../../../../common/VmSelect/VmSelect";
import VmSelectTag from "../../../../../common/VmSelectTag/VmSelectTag";
import _ from 'underscore';

const propTypes = {
    footprintReducer: PropTypes.object,
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    handleCancel: PropTypes.func,
    updateKCA: PropTypes.func,
    saveKCA: PropTypes.func,
    visible: PropTypes.bool,
};
export default class AddNewKeyCompetitor extends Component {
    constructor(props) {
        super(props);
    }

    handleChange = (e, src) => {
        if (src == "ccRel" || src == "keyStrength" || src == "VMWOP") {
            this.props.actions.kcaPostData(e.target.value, src, this.props.accountPlanId);
        } else if (src == "exDate") {
            this.props.actions.kcaPostData(e._d.getFullYear() + '/' + (e._d.getMonth() + 1) + '/' + e._d.getDate(), src, this.props.accountPlanId);
        } else {
            this.props.actions.kcaPostData(e, src, this.props.accountPlanId);
        }
    };

    getDefault(keyName, id){
        try{
            // let x =  _.filter(this.props.footprintReducer.keyCompetitorName,(o)=>{
            //     return o.id == this.props.footprintReducer.kcaPostData.competitorId
            // })
            // return x[0].label
            let labelName = _.filter(this.props.footprintReducer[`${keyName}`], (val) => {
                return val.id == id;
              });
              if (labelName[0]) {
                return labelName[0].label;
              }
        
        
        }catch(e){
            return null
        }         
    }

    render = () => {
        let disableButton = !this.props.footprintReducer.kcaPostData.competitorId;
        console.log("disableButton", this.props.footprintReducer.kcaPostData.competitorId ? this.props.footprintReducer.keyCompetitorName[0].label : []);
        return (
            <div>
                <Modal className="add-edit-focus-popup-key-competitor"
                    title="New Key Competitor Analysis"
                    visible={
                        this.props.visible
                    }
                    centered onCancel={
                        () => this.props.handleCancel()
                    }
                    footer={
                        this.props.footprintReducer.kcaPostData.kcaId != null ?
                            [<Button
                                key="submit"
                                className="submit-btn"
                                type="primary"
                                disabled={disableButton}
                                onClick={() => this.props.updateKCA()}>Update
                            </Button>]
                            :
                            [<Button
                                key="submit"
                                className="submit-btn"
                                type="primary"
                                disabled={disableButton}
                                onClick={() => this.props.saveKCA()}>Create
                            </Button>]
                    }
                >
                    <section className="add-key-makers">
                        <Layout>
                            <Content>
                                <Row gutter={24}>
                                    <Col span={6}>
                                        <VmSelect
                                            label={"Select Competitor Name*"}
                                            value="label"
                                            id="id"
                                            disabled={this.props.editing}
                                            placeholder={
                                                this.getDefault('keyCompetitorName', this.props.footprintReducer.kcaPostData.competitorId)
                                            }
                                            options={this.props.footprintReducer.keyCompetitorName}
                                            onChange={(e) => { this.handleChange(e, "cName") }}
                                        />
                                    </Col>
                                    <Col span={6}>
                                        <VmSelect
                                            label={"Select Relative Rating"}
                                            value="label"
                                            id="id"
                                            // this.getDefault('keyCompetitorName', this.props.footprintReducer.kcaPostData.competitorId)
                                            placeholder={this.getDefault('keyCompetitorRR', this.props.footprintReducer.kcaPostData.severityId)}
                                            // defualtValue={this.props.footprintReducer.kcaPostData.severityId}
                                            defualtValue={this.getDefault('keyCompetitorRR', this.props.footprintReducer.kcaPostData.severityId)}
                                            options={this.props.footprintReducer.keyCompetitorRR}
                                            onChange={(e) => { this.handleChange(e, "RR") }}
                                        />
                                    </Col>
                                </Row>
                                <Row gutter={24} className="customer-strategic">
                                    <Col span={16}>
                                        <Input
                                            label={"Enter Current Customer Relationship"}
                                            value={this.props.footprintReducer.kcaPostData.customerRelationship}
                                            floatingLabel={true}
                                            autoComplete="off"
                                            onChange={(e) => { this.handleChange(e, "ccRel") }}
                                        />
                                    </Col>
                                    <Col span={8}>
                                        <Row gutter={24}>
                                            <Col span={12} style= {{marginTop:12}}>
                                                <VmSelect
                                                    label={"Existing ELA"}
                                                    value="label"
                                                    id="id"
                                                    placeholder={this.getDefault('keyCompetitorELA', this.props.footprintReducer.kcaPostData.elaId)}
                                                    defualtValue={this.getDefault('keyCompetitorELA', this.props.footprintReducer.kcaPostData.elaId)}
                                                    options={this.props.footprintReducer.keyCompetitorELA}
                                                    onChange={(e) => { this.handleChange(e, "ELA") }}
                                                />
                                            </Col>
                                            <Col span={12} style={{marginTop:'7px'}}>
                                                <span>Expiry date</span>
                                                <DatePicker
                                                    // value = {this.props.footprintReducer.kcaPostData.expiryDate}
                                                    
                                                    value={
                                                        !this.props.footprintReducer.kcaPostData.expiryDate || this.props.footprintReducer.kcaPostData.expiryDate == "" ? ""
                                                            : moment(this.props.footprintReducer.kcaPostData.expiryDate, "YYYY-MM-DD")
                                                    }
                                                    format={"YYYY-MM-DD"} placeholder="Expiry Date"
                                                    onChange={(e) => { this.handleChange(e, "exDate") }}
                                                />
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>
                                <Row gutter={24} style={{marginTop:10}}>
                                    <Col span={6}>
                                        <VmSelectTag
                                            placeholder={"Data Center Solution"}
                                            className={"dataCenter"}
                                            options={this.props.footprintReducer.kcaPostData.dataCenterSolution ? this.props.footprintReducer.kcaPostData.dataCenterSolution : []}
                                            onChange={(e) => { this.handleChange(e, "dataCS") }}
                                        />
                                    </Col>
                                    <Col span={6}>
                                        <VmSelectTag
                                            placeholder={"Hybrid Cloud Solution"}
                                            className={"hybridCloud"}
                                            options={this.props.footprintReducer.kcaPostData.hybridCloudSolution ? this.props.footprintReducer.kcaPostData.hybridCloudSolution : []}
                                            onChange={(e) => { this.handleChange(e, "HybridCS") }}
                                        />
                                    </Col>
                                    <Col span={6}>
                                        <VmSelectTag
                                            placeholder={"Security Solution"}
                                            className={"securitySolution"}
                                            options={this.props.footprintReducer.kcaPostData.securitySolution ? this.props.footprintReducer.kcaPostData.securitySolution : []}
                                            onChange={(e) => { this.handleChange(e, "securityS") }}
                                        />
                                    </Col>
                                    <Col span={6}>
                                        <VmSelectTag
                                            placeholder={"Digital Work-space Solution"}
                                            className={"digitalSolution"}
                                            options={this.props.footprintReducer.kcaPostData.digitalWorkspaceSolution ? this.props.footprintReducer.kcaPostData.digitalWorkspaceSolution : []}
                                            onChange={(e) => { this.handleChange(e, "digWS") }}
                                        />
                                    </Col>
                                </Row>
                                <Row gutter={24}>
                                    <Col span={24}>
                                        <Input
                                            label={"Solution Provider's Key Strength/Key Weakness"}
                                            floatingLabel={true}
                                            value={this.props.footprintReducer.kcaPostData.strengthOrWeakness}
                                            autoComplete="off"
                                            onChange={(e) => { this.handleChange(e, "keyStrength") }}
                                        />
                                    </Col>
                                </Row>
                                <Row gutter={24}>
                                    <Col span={24}>
                                        <Input
                                            label={"Key VMW Opportunity/Threat"}
                                            floatingLabel={true}
                                            autoComplete="off"
                                            value={this.props.footprintReducer.kcaPostData.opportunityOrThreat}
                                            onChange={(e) => { this.handleChange(e, "VMWOP") }}
                                        />
                                    </Col>
                                </Row>
                            </Content>
                        </Layout>
                    </section>
                </Modal>
            </div>
        );
    }
}

AddNewKeyCompetitor.propTypes = propTypes;
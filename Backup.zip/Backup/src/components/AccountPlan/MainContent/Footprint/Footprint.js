import React, { Component } from 'react';
//import PropTypes from "prop-types";
import '../MainContent.scss';
import './Footprint.scss';
import { Layout, Icon, Collapse, Popover, Input, message } from 'antd';
const { TextArea } = Input;
const { Content } = Layout;
import VmFloatingInput from '../../../common/VmFloatingInput/VmFloatingInput';
import StackedBarChrt from '../../../common/Charts/StackedBarChart/StackedBarChrt';
import Footprintjson1 from '../../../../constants/json/footprintData.json';
import Footprintcolor from '../../../../constants/json/footprintcolor';
import Config from '../../../../config/Config';
import axios from 'axios';
import { BarCh } from '../../../common/Charts/StackedBarChart/BarCh';
import _ from 'underscore';
const Panel = Collapse.Panel;
// const productGroupData = Footprintjson.data.productGroupData;
// const productClassData = Footprintjson.data.productClassData;
// const elaData = Footprintjson.data.elaData;
// const pipelineData = Footprintjson.data.pipelineData;

const config = new Config();

export default class Footprint extends Component {
    constructor(props) {
        super(props);
    }
   
  state ={
    Footprintjson : null
  }
  componentDidMount(){
    const msg = message.loading("Please wait while we load the data",0)
    axios.get(`${config.capUrl}/${this.props.accountPlanId}/hana/bookings?custid=${this.props.landingReducer.customerId}`)
    .then(resp=>{
      if(resp.status === 200){
          this.setState({Footprintjson: resp.data});  //Footprintjson1
      }
      msg()
    })
   }

    getColorData(GroupData){
        const colors =  ["#8377d9","#8ee35f","#ffb7a8","#25ffc4","#ff8073","#ffea63","#66c1ff","#ffb1e8","#8377d9","#7bd743"];
        let data = this.getData(GroupData);
        let res = [];
        let i =0;
        Object.keys(data[0]).forEach(function(key) {
            if(key !="year"){
                res.push([key,colors[i]]);
                i++;
            }
        });
        return res;
    }
   
   
    getData(GroupData){
        if(GroupData.length>0){
            var groupData= [];
            var i,j;
            for (i = 0; i < GroupData.length; i++) { 
                let res ={};
                let year,quarter;
                if(GroupData[i].hasOwnProperty('year')){
                    year = GroupData[i].year;
                    res.year = "FY" + (year-2000);
                }
                else{
                    quarter = GroupData[i].quarter;
                    res.quarter = quarter;
                }
                
                
                let value;
                if(GroupData[i].hasOwnProperty('productGroups')){
                    value = "productGroups";
                }
                else if(GroupData[i].hasOwnProperty('productClasses')){
                    value = "productClasses";
                }
                else if(GroupData[i].hasOwnProperty('pipelines')){
                    value = "pipelines";
                }
                else if(GroupData[i].hasOwnProperty('elas')){
                    value = "elas";
                }
                for (j = 0; j < GroupData[i][value].length; j++){
                    let keys = [];
                    Object.keys(GroupData[i][value][j]).forEach(function(key) {
                        keys.push(GroupData[i][value][j][key]);
                    });
                    var group = keys[0];
                    res[group] = parseInt(keys[1]);
    
                }
                groupData.push(res);
            }
            if(groupData[0].hasOwnProperty('year')){
                return _.sortBy(groupData,'year');
            }
            else{
                return _.sortBy(groupData,'quarter');
            }
          
        }
        else{
            return null;
        }       
    }



    

   
   
    render() {

        if(this.state.Footprintjson !=null){
            const Jsonpoc1 = this.getData(this.state.Footprintjson.data.productGroupData);
            console.log(Jsonpoc1)
            const Jsonpoc2 = this.getData(this.state.Footprintjson.data.productClassData);
            console.log(Jsonpoc2)
            const Jsonpoc3 = this.getData(this.state.Footprintjson.data.elaData);
            console.log(Jsonpoc3)
            const Jsonpoc4 = this.getData(this.state.Footprintjson.data.pipelineData)
            console.log(Jsonpoc4)
        }
       
      
      
        const content = <div>
            <div>
                <sapn>John Smith</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Megan Cole</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Ruby Dasmond</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
        </div>
        const tagContent = <div className="tag-content">
            <Input
                placeholder="Type Name/E-mail ID"
                prefix={<Icon type="plus-circle-o" style={{ color: '#d8d8d8' }} />}
            // suffix={<Icon type="close-circle"/>}
            />
            <div className="no-tag"> No team member tagged</div>
            <div className="select-section">
                <span className="section-txt">Select Sections</span>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>By Product Group</span>
                </div>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>By Product Class</span>
                </div>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>Spend History: ELA & Transaction Purchases</span>
                </div>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>Future Pipeline: By Product Group</span>
                </div>
            </div>
            <TextArea placeholder="Type your comment" className="comment" rows={4} />
            <div className="notify-btn">
                <span className="notify">Notify</span>
            </div>
        </div>
        return (
            <div className="footprint">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <div className="menu-selected">Footprint</div>
                        <div className="submenu-tag-info">
                            <span className="submenu-selected">VMware Bookings</span>
                            {/* <Popover placement="bottomRight" content={tagContent} trigger="click">
                                <span className="tag-team-membr-cont">
                                    <span className="tag-team-membr">Tag a Team Member</span>
                                    <Icon type="caret-down" theme="outlined" style={{ color: '#0375b7' }} />
                                </span>
                            </Popover> */}
                        </div>

                        <Collapse defaultActiveKey={['1']}>
                            <Panel header={<div className="collapse-main by-prod-grp">
                                <span className="collapse-header">By Product Group</span>
                                {/* <span className="red-star">*</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover> */}
                            </div>} key="1">
                                
                        
                                       {this.state.Footprintjson && this.state.Footprintjson.data.productGroupData.length > 0 ? 
                                        <StackedBarChrt
                                            barSize={20}
                                            width={1000}
                                            data= {this.state.Footprintjson !=null ? this.getData(this.state.Footprintjson.data.productGroupData): null }
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={Footprintcolor.byProdGrpbarBackgrnd}
                                        /> :
                                        <div className="no-data">
                                            No Data available
                                        </div>
                                    }
                                       
                            </Panel>
                        </Collapse>

                        <Collapse className="collapse-margin">
                            <Panel header={<div className="collapse-main">
                                <span className="collapse-header">By Product Class</span>
                                {/* <span className="red-star">*</span>
                                <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover> */}
                            </div>} key="2">
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                {this.state.Footprintjson && this.state.Footprintjson.data.productClassData.length > 0 ? 
                                        <StackedBarChrt
                                            barSize={20}
                                            width={1000}
                                            data= {this.state.Footprintjson !=null ? this.getData(this.state.Footprintjson.data.productClassData): null }
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={Footprintcolor.byProdClassbarBackgrnd}
                                        /> :
                                        <div className="no-data">
                                            No Data available
                                        </div>
                                }
                                </div>

                            </Panel>
                        </Collapse>

                        <Collapse className="collapse-margin">
                            <Panel header={<div className="collapse-main">
                                <span className="collapse-header">Spend History: ELA and Transaction Purchases</span>
                                {/* <span className="red-star">*</span>
                                <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover> */}
                            </div>} key="3">
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                {this.state.Footprintjson && this.state.Footprintjson.data.elaData.length > 0 ? 
                                        <StackedBarChrt
                                            barSize={20}
                                            width={1000}
                                            data= {this.state.Footprintjson !=null ? this.getData(this.state.Footprintjson.data.elaData): null }
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={Footprintcolor.ELAtransPurchaseBackgrnd}
                                        /> :
                                        <div className="no-data">
                                            No Data available
                                        </div>
                                }
                                </div>

                            </Panel>
                        </Collapse>

                        <Collapse className="collapse-margin">
                            <Panel header={<div className="collapse-main">
                                <span className="collapse-header">Future Pipeline: by Product Group</span>
                                {/* <span className="red-star">*</span>
                                <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover> */}
                            </div>} key="4">
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                {this.state.Footprintjson && this.state.Footprintjson.data.elaData.length > 0 ? 
                                        <StackedBarChrt
                                            barSize={20}
                                            width={1000}
                                            data= {this.state.Footprintjson !=null ? this.getData(this.state.Footprintjson.data.pipelineData): null }
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={Footprintcolor.futurePipelineBackgrnd}
                                        /> :
                                        <div className="no-data">
                                            No Data available
                                        </div>
                                }
                                </div>

                            </Panel>
                        </Collapse>


                    </Content>
                </Layout>
            </div>
        );
    }
};

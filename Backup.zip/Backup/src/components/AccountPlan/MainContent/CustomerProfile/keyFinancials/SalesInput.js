import React from 'react';
import VmInput from '../../../../common/VmInput/VmInput';
import {anyZero} from '../../../../../Services/Validate'
import {Icon} from 'antd';

export const SalesInput = ({data,actions,title}) => {
    return (
        <section className="net-sales-container">
            <div className="net-sales">{title}</div>
            {
                data.map((obj,index)=>(
                    <div className="net-sales-info" key={index}>
                        <span className="year-info">FY{parseInt(obj.fiscalYear) - 2000}</span>
                        <VmInput
                            placeholder="Enter Value"
                            value={obj.financialValue}
                            onChange={(e)=>{
                                actions.updateKeyFinenceField(obj.id, e.target.value);
                            }}
                            pattern="^([0-9]*)\.?([0-9]{1,2})?$"
                            onBlur={()=>actions.updateKeyFinencialsAPI(obj)}
                            max={10000000000000}
                        />
                    </div>
                ))
            }
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12" style={{}}>
                {  !anyZero(data,'financialValue') &&
                    <div className="pull-right reqrd-txt">
                        <Icon type="warning" style={{ color: '#ff153f' }} />
                        <span className="required-txt">Text fields incomplete!</span>
                    </div>
                }
            </div>
        </section>
    )
}
import React from "react";
import VmInput from "../../../../common/VmInput/VmInput";
import { Icon } from "antd";
import VmLabelInput from "../../../../common/VmLabelInput/VmLabelInput";
import _ from "underscore";
import { segmentGrowthValidation } from "../../../../../Services/Validate";

export const SegmentGrowth = ({ title, segments, actions, accountPlanId }) => {
  // const years = _.groupBy(segments,'fiscalYear');
  return (
    <section className="segment-growth">
      <div className="col-lg-12 net-sales" style={{ marginBottom: "40px" }}>
        {title}
      </div>
      <div className="col-lg-12">
        <div className="col-lg-3" />
        <div className="" style={{}}>
          {segments &&
            segments.length > 0 &&
            segments[0].segmentGrowth.map(segment => (
              <div
                key={segment.fiscalYear}
                style={{
                  paddingLeft: "11px",
                  fontFamily: "Metropolis",
                  fontSize: "15px",
                  fontWeight: 500
                }}
                className="col-lg-3"
              >
                FY{segment.fiscalYear - 2000}
              </div>
            ))}
        </div>
        {/* <div className="" style={{}}>
                    {
                        
                        Object.keys(years).map((kx)=><div key={kx} style={{paddingLeft:0,fontFamily: 'Metropolis',fontSize: '15px',fontWeight:500}} className="col-lg-3">FY {kx-2000}</div>) //{marginRight:'20px'}
                    }
                 
                </div> */}
      </div>

      {segments.map((seg, pIndex) => (
        <div className="net-sales-info col-lg-12" key={pIndex}>
          <VmLabelInput value={seg.label} className="segment-label" />
          {seg.segmentGrowth.map((obj, index) => (
            <div className="col-lg-3" key={index}>
              <VmInput
                pattern="^(\-?[0-9]*)\.?([0-9]{1,2})?$"
                max={100}
                placeholder="Enter value"
                value={obj.segmentGrowthValue}
                onBlur={() => {
                  setTimeout(() => {
                    // let finalIndex = _.findIndex(segments,(o,i)=>{
                    //     return o.id === obj.id
                    // });
                    actions.updateSegmentAPI(seg.segmentGrowth, accountPlanId);
                  }, 0);
                }}
                onChange={e => {
                  actions.updateSegmentValue(pIndex, index, e.target.value);
                }}
              />
            </div>
          ))}
        </div>
      ))}

      {/* <div className="add-another">
                <Icon type="plus" style={{ color: '#007cbb', fontSize: "10px", fontWeight: 'bold' }} />
                <button className="add-btn">ADD ANOTHER</button>
            </div> */}

      <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12" style={{}}>
        {!segmentGrowthValidation(segments, "segmentGrowthValue") && (
          <div className="pull-right reqrd-txt">
            <Icon type="warning" style={{ color: "#ff153f" }} />
            <span className="required-txt">Text fields incomplete!</span>
          </div>
        )}
      </div>
    </section>
  );
};

import React, { Component } from 'react';
import { Icon, Popover, Collapse } from 'antd'; //Input
import { taggedUser } from '../taggedUser/taggedUser';
import VmInput from '../../../../common/VmInput/VmInput';
import BarChrt from '../../../../common/Charts/BarChart/BarChrt';
import PieChrt from '../../../../common/Charts/PieChart/PieChrt';
import customerProfileData from '../../../../../constants/json/customerProfile';
import './key-financials.scss';
import { SalesInput } from './SalesInput';
import {BusinessPortfolio} from './businessPortfolio';
import PropTypes from 'prop-types';
import _ from 'underscore';
import {cloneDeep} from 'lodash';
import { SegmentGrowth } from './segmentGrowth';
import VerticleBar from '../../../../common/Charts/VerticleBar/VerticleBar';

const Panel = Collapse.Panel;

class KeyFinancials extends Component {


    componentDidMount(){
        this.props.actions.fetchKeyFinencials(this.props.accountPlanId);
        this.props.actions.fetchBusinessPorfolio(this.props.accountPlanId);
        //this.props.actions.fetchSegmentGrowth(this.props.accountPlanId);
    }

    filterData(FILTER){
        if(this.props.overview.keyFinencials.length > 0){
            return _.filter(this.props.overview.keyFinencials,(o)=>{
                return o.type === FILTER
            });
        }
        return [];
    }
    processData(arr){
        let x = cloneDeep(arr)
        return _.each(x,(obj)=>{
            obj.value = parseInt(obj.portfolioValue);
            obj.name = obj.portfolioLabel;
        })
    }

    render = () => {
        return (
            // defaultActiveKey={['3']}
            <Collapse className="collapse-margin collapse-key-finance" >
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Key Financials</span>
                    <span className="red-star">*</span>
                    {/* <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span> */}
                    {/* <Popover placement="leftTop" content={taggedUser()} title="Currently Tagged:">
                        <span className="info-icon">
                            <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                        </span>
                    </Popover> */}
                </div>} key="3">
                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 net-sales-cont key-financials">
                        <div className="col-xs-7 col-sm-7 col-md-7 col-lg-7">
                            <SalesInput 
                                title="Net Sales (USD)"
                                actions={this.props.actions}
                                data={this.filterData('NET_SALES')}
                            />
                        </div>
                        <div className="col-xs-5 col-sm-5 col-md-5 col-lg-5 bar-area">
                            <BarChrt data={this.filterData('NET_SALES')}
                                xAxisLabel="FINANCIAL YEAR"
                                yAxisLabel="USD"
                                dataKey="fiscalYear"
                                dataValue="financialValue"
                                barBackgound="#8377d9"
                            />
                        </div>
                    </div>

                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 net-sales-cont op-income-cont">
                        <div className="col-xs-7 col-sm-7 col-md-7 col-lg-7">
                        <SalesInput 
                                title="Operating Income (USD)"
                                actions={this.props.actions}
                                data={this.filterData('OPERATING_INCOME')}
                        />
                        </div>
                        <div className="col-xs-5 col-sm-5 col-md-5 col-lg-5 bar-area">
                            <BarChrt data={this.filterData('OPERATING_INCOME')}
                                xAxisLabel="FINANCIAL YEAR"
                                yAxisLabel="USD"
                                dataKey="fiscalYear"
                                dataValue="financialValue"
                                barBackgound="#66c1ff"
                            />
                        </div>
                    </div>

                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 net-sales-cont op-income-cont business-portfolio-info">
                        <div className="col-xs-7 col-sm-7 col-md-7 col-lg-7">
                            <BusinessPortfolio 
                                actions={this.props.actions}
                                portfolio={this.props.overview}
                                accountPlanId={this.props.accountPlanId}
                                fisicalYear={
                                    this.props.landingReducer.plans === undefined ? [] : this.props.landingReducer.plans
                                }
                            />
                        </div>
                        <div className="col-xs-5 col-sm-5 col-md-5 col-lg-5 bar-area">
                            <PieChrt data={this.processData(this.props.overview.businessPortfolio)}
                                COLORS={customerProfileData.buPortfolioColors}
                            />
                        </div>
                    </div>

                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 net-sales-cont op-income-cont business-portfolio-info segment-cont">
                        <div className="col-xs-7 col-sm-7 col-md-7 col-lg-7">
                            <SegmentGrowth 
                                title={"Segment Growth % (Y/Y)"} 
                                segments={this.props.overview.businessPortfolio}
                                actions={this.props.actions}
                                accountPlanId={this.props.accountPlanId}
                            />
                        </div>
                        <div className="col-xs-5 col-sm-5 col-md-5 col-lg-5 bar-area">
                            <VerticleBar 
                                data={this.props.overview.businessPortfolio}
                            />
                        </div>
                    </div>

                </Panel>
            </Collapse>
        );
    }
}

KeyFinancials.propTypes = {
    overview: PropTypes.object,
    actions: PropTypes.object,
    accountPlanId: PropTypes.string.isRequired
};


export default KeyFinancials;
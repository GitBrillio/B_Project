import React, { Component } from "react";
import { Layout } from "antd";
import "./CustomerStrategy.scss";
const { Content } = Layout;
import AddCustomerStrategy from "./AddCustomerStrategy/AddCustomerStrategy";
import PropTypes from 'prop-types';
import CustomerStrategyBlock from './CustomerStrategyBlock';
import DeletePopup from "../../../../common/DeletePopup/DeletePopup";

class CustomerStrategy extends Component {
  state = {
    addnewModal: false,
    deleting: false,
  };
  
  componentDidMount(){
    this.props.actions.fetchCustomerStrategy(this.props.accountPlanId)
  }
  addNewCustomerStrategy() {
    this.props.actions.setCS({
        "customerStrategyId": null,
        "solutionId": "",
        "solutionName": "",
        "otherText": "",
        "maturityLevelId": "",
        "maturityLevelLabel": "",
        "customerStrategy": "",
        "vmwarePriorities": ""
    });
    this.setState({
        addnewModal: true
    });
  }
  editCS(cs){
    this.props.actions.setCS(cs);
    this.setState({ addnewModal: true });
  }
  
  addCustomerStrategy() {
    this.setState({
      addnewModal: false
    });
  }
  handleCustomerStrategyCancel(){
    this.setState({
      addnewModal: false,
      
    });
  }
  saveCS(type){
    this.props.actions.saveCustomerStrategy(
      this.props.customerStrategyReducer.csStructure,
      this.props.accountPlanId,
      type === 'Save' ? 'create' : 'update'
    );
    this.setState({ addnewModal: false });
  }
  deleteCS(cs){
    this.setState({ deleting: true, delObj: cs });
  }
  deleteOk(){
    this.props.actions.deleteCS(this.props.accountPlanId, this.state.delObj);
    this.setState({ deleting: false });
  }
  deleteCancel(){
    this.setState({ deleting: false });
  }

  render() {
    const {customerStrategy} = this.props.customerStrategyReducer;
    return (
    <section className="customerStrategy">
          <Layout>
            <Content style={{ padding: 24, margin: 0 }} >
              <div className="menu-selected">Customer Profile</div>
              <div className="submenu-tag-info">
                <span className="submenu-selected">Customer Strategy</span>
              </div>
              
              {customerStrategy.length === 0 ? (
                <div className="new-customer">
                    <button
                        className="dashed-btn"
                        type="dashed"
                        onClick={() => this.addNewCustomerStrategy()}
                    >
                        Create New Customer Strategy
                    </button>
                </div>
              ) : (
                <div>
                    <button
                    className="create-customer"
                    onClick={() => this.addNewCustomerStrategy()}
                    >
                        Create New Customer Strategy
                    </button>

                    <div>
                    {
                        customerStrategy.map((cs,idx)=>(
                        <CustomerStrategyBlock
                            editCS={this.editCS.bind(this)} 
                            key={idx} 
                            customerStrategy={cs} 
                            deleteCS={this.deleteCS.bind(this)}
                            actions = {this.props.actions}
                        />
                        ))
                    }
                    
                    </div>
              </div>
              )}
            </Content>

            <AddCustomerStrategy
                visible={this.state.addnewModal} 
                heading="Create New Customer Strategy"
                ok={() => this.addCustomerStrategy()}
                handleCancel={() => this.handleCustomerStrategyCancel()}
                actions = {this.props.actions}
                csStructure={this.props.customerStrategyReducer.csStructure}
                accountPlanId={this.props.accountPlanId}
                customerStrategyReducer={this.props.customerStrategyReducer}
                saveCS={this.saveCS.bind(this)}
            />
          </Layout>
          {
              this.state.deleting &&
              <DeletePopup
                  heading="Delete Customer Strategy"
                  visible={this.state.deleting}
                  ok={() => this.deleteOk()}
                  cancel={() => this.deleteCancel()}
                  okText="Yes delete it"
                  cancelText="No, cancel it"
                  contents="Are you sure you want to delete this customer strategy?"
              />
            }
    </section>
    );
  }
}
CustomerStrategy.propTypes = {
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    customerStrategyReducer: PropTypes.object
}
export default CustomerStrategy;

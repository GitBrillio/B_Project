import React, { Component } from 'react';
import { Modal, Button, Row, Col, Select, Icon } from 'antd';
const Option = Select.Option;
import PropTypes from 'prop-types';
import Input from "muicss/lib/react/input";
import './AddCustomerStrategy.scss';
import _ from "underscore"

class AddCustomerStrategy extends Component {
    state={
        otherTextVisibility:false,
        infoVisibility:true,
        infoBlockVisibility: true
        
    }
    componentDidMount() {
        this.props.actions.fetchKeySolutions(this.props.accountPlanId);
        this.props.actions.fetchMaturityLevel(this.props.accountPlanId);
    }
    getKeySolutionsData(e) {
        let res =  _.filter(this.props.customerStrategyReducer.keySolutions, (opt)=>{
            return opt.solutionId == e
        })
        return res[0];
    }
    maturityLevel(e) {
        let res =  _.filter(this.props.customerStrategyReducer.maturityLevel, (opt)=>{
            return opt.id == e
        })
        return res[0];
    }
    render() {

        return (
            <div>
                <Modal
                    className="addCustomerStrategy"
                    visible={this.props.visible}
                    title="New Customer Strategy"
                    centered
                    onCancel={this.props.handleCancel}
                    footer={[
                        <Button
                            key="submit"
                            className="submit-btn"
                            type="primary"
                            onClick={() => {
                                this.props.saveCS(!this.props.csStructure.customerStrategyId ? "Create" : "Save");
                            }}
                        >{!this.props.csStructure.customerStrategyId ? "Create" : "Save"}
                        </Button>
                    ]}

                >
                    <section className="addCustomerStrategy-section">
                        <Row gutter={24} className="dropdowns">
                            <Col span={8}>
                                <label className="label-style">Select VMware key solutions</label>
                                <Select
                                    className="select-main"
                                    placeholder="Select VMware key solutions"
                                    value={this.props.csStructure.solutionName? this.props.csStructure.solutionName : ""}
                                    disabled = {this.props.csStructure.customerStrategyId ? true : false}
                                    onChange={(e) => {
                                        let keySolutions =  this.getKeySolutionsData(e)
                                        keySolutions.solutionId === 5 ? 
                                            this.setState({otherTextVisibility:true,infoBlockVisibility:false})
                                        : 
                                            this.setState({otherTextVisibility:false,infoBlockVisibility:true})
                                        this.props.actions.changeModalValues('solutionName', keySolutions.solutionName)
                                        this.props.actions.changeModalValues('solutionId', keySolutions.solutionId)
                                        this.props.actions.changeModalValues('solutionInfo', keySolutions.solutionInfo)
                                        }
                                    }
                                >
                                    {this.props.customerStrategyReducer.keySolutions.map((opt) => {
                                        return (
                                            <Option key={opt.solutionId} >
                                                {opt.solutionName}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Col>
                            <Col span={8}></Col>
                            <Col span={8}>
                                <label className="label-style">Select Maturity Level</label>
                                <Select
                                    className="select-main"
                                    placeholder="Select Maturity Level"
                                    value={this.props.csStructure.maturityLevelLabel}
                                    onChange={(e) => {
                                            let maturityLevel = this.maturityLevel(e);
                                            this.props.actions.changeModalValues('maturityLevelId', maturityLevel.id)
                                            this.props.actions.changeModalValues('maturityLevelLabel', maturityLevel.label)
                                        }
                                    }
                                >
                                    {this.props.customerStrategyReducer.maturityLevel.map((opt) => {
                                        return (
                                            <Option key={opt.id}>
                                                {opt.label}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Col>
                        </Row>
                        {
                            (this.state.otherTextVisibility || this.props.csStructure.solutionName === "Other" ) && 
                                <Row gutter={24}>
                                    <Col span={8}>
                                        <Input
                                            placeholder={"Enter Key Solution"}
                                            value={this.props.csStructure.otherText}
                                            onChange={(e) => this.props.actions.changeModalValues('otherText', e.target.value)}
                                        />
                                    </Col>
                                </Row>
                        }
                        
                        <div className="container">
                            <Row gutter={24} className="current-strategy">
                                <Col span={24}>
                                    <Input
                                        label={"Customer‘s current strategy"}
                                        floatingLabel={true}
                                        value={this.props.csStructure.customerStrategy}
                                        onChange={(e) => this.props.actions.changeModalValues('customerStrategy', e.target.value)}
                                    />
                                </Col>
                            </Row>
                            {
                                this.state.infoBlockVisibility &&
                                    <Row gutter={24} className="info-block">
                                        <div>
                                            <span className="info-txt position" onClick={()=>this.setState({infoVisibility:true})}>Info</span>
                                            <Icon className="info-icn position" 
                                                type="close-circle" 
                                                style={{ color: '#0375b7' }} 
                                                onClick={()=>this.setState({infoVisibility:false})}
                                            />
                                        </div>
                                        
                                        {
                                            this.state.infoVisibility &&
                                            <Col span={24}>
                                                <div>{this.props.csStructure.solutionInfo}</div>
                                                {/* <div>Have they virtualized compute and established operations?</div>
                                                <div>How far regarding SW-defined networking and storage? </div>
                                                <div>How far on automation?</div>
                                                <div>Fully bought into SDDC vision?</div>
                                                <div>Investing into cloud native app development?</div> */}
                                            </Col>
                                        }
                                    </Row>
                            }
                            
                        </div>
                        <Row gutter={24} className="vmware-priorities">
                            <Col span={24}>
                                <Input
                                    label={"VMware Priorities"}
                                    floatingLabel={true}
                                    value={this.props.csStructure.vmwarePriorities}
                                    onChange={(e) => this.props.actions.changeModalValues('vmwarePriorities', e.target.value)}
                                />
                            </Col>
                        </Row>
                    </section>
                </Modal>
            </div>
        );
    }
}
AddCustomerStrategy.propTypes = {
    visible: PropTypes.bool.isRequired,
    handleCancel: PropTypes.func,
    actions: PropTypes.object,
    index: PropTypes.number,
    heading: PropTypes.string,
    customerStrategyReducer: PropTypes.object,
    csStructure: PropTypes.object,
    accountPlanId: PropTypes.string,
    saveCS: PropTypes.func
}
export default AddCustomerStrategy;
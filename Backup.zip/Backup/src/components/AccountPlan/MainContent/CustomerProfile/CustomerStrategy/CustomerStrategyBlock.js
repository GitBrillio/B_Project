import React from 'react';
import {  Row,Col} from "antd";
import trash from '../../../../../images/trash.svg';
import PropTypes from 'prop-types';

const CustomerStrategyBlock = ({customerStrategy,editCS,deleteCS}) => {
    return (
       <div className="customer-details-cont">
            <section className="details-sec">
                <Row className="div-style">
                    <Col span={22} className="padding0">
                        <p className="para-style"><span>{customerStrategy.solutionName === "Other" ? customerStrategy.otherText : customerStrategy.solutionName}</span></p>         
                    </Col>
                    <Col span={1} className="padding0" style={{cursor:'pointer'}} onClick={()=>editCS(customerStrategy)}>
                        <p className="edit-style"><span >EDIT</span></p>         
                    </Col>
                    <Col span={1} className="padding0">
                    <p className="edit-style"style={{cursor:'pointer'}} onClick={()=>deleteCS(customerStrategy)}><span className="delete-icon"> <img src={trash} title="Delete mission critical system" alt="Delete System" /></span></p>         
                    </Col>
                </Row>
                <Row className ="details-body">
                    <Col span={16} className="padding0">
                        <p className="heading-style">Customer Current strategy</p>
                        <p className="regular-font">{customerStrategy.customerStrategy}</p>
                    </Col>
                    <Col span={8} className="align-right padding0">
                        <p className="heading-style">Maturity Level</p>
                        <p className="regular-font">{customerStrategy.maturityLevelLabel}</p>
                    </Col>
                    
                </Row>
                <Row className ="details-body">
                    <Col span={24} className="padding0">
                        <p className="heading-style">VMware Priorities</p>
                        <p className="regular-font">{customerStrategy.vmwarePriorities}</p>
                    </Col>
                </Row>
            </section>
                </div>
    );
};
CustomerStrategyBlock.propTypes = {
    editCS: PropTypes.any,
    deleteCS: PropTypes.any,
    customerStrategy: PropTypes.object,
    actions: PropTypes.object
}
export default CustomerStrategyBlock;
import React, { Component } from 'react';
import Input from 'muicss/lib/react/input';

class BusinessGoal extends Component{

    render = () =>{
        return (
            <div>
                   <Input 
                        type="text"
                        label={"Enter Goal"}
                        floatingLabel={true}
                    />
            </div>
        )
    }

}

BusinessGoal.propTypes = {
}

export default BusinessGoal;
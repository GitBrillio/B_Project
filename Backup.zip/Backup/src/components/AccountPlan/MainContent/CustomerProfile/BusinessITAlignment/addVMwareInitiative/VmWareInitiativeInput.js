import React, { Component } from 'react';
import Input from 'muicss/lib/react/input';
// import './AddNewBusinessInitiative.scss';
import { Row, Col, Radio, Calendar} from 'antd';
const RadioGroup = Radio.Group;

class VmWareInitiativeInput extends Component{
    

    render = () =>{
        return (
            <div>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={24}>
                    <Input 
                        value = {this.props.biName}
                        label={"Business Initiative"}
                        floatingLabel={true}
                        disabled={true}
                    />
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={24}>
                    <Input 
                        value = {this.props.vmName}
                        label={"Enter VMware Initative*"}
                        floatingLabel={true}
                        onChange={(e)=>this.props.vmWareInputVal(e)}
                    />
                </Col>
            </Row>

        </div> 
        )
    }

}

VmWareInitiativeInput.propTypes = {
}

export default VmWareInitiativeInput;
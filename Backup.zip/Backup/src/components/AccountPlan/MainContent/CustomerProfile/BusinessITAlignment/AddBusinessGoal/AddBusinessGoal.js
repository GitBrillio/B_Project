import React, { Component } from 'react';
import { Modal, Button } from 'antd';
import './AddBusinessGoal.scss';
import Input from 'muicss/lib/react/input';
import _ from 'underscore';
import DeletePopup from '../../../../../common/DeletePopup/DeletePopup';

class AddBusinessGoal extends Component {
    constructor(props) {
        super(props);
        this.itLen = 0, this.vmLen = 0, this.biLen = 0;
        this.state = {
            confirmDelete: false
        }
    }
    ConfHandleCancel = () => {
        this.setState({ confirmDelete: false });
    }
    componentDidMount() {
        if (this.props.goalId != "") {
            let fileterGoal = _.filter(this.props.businessGoalReducer.businessGoals, (goal, key) => {
                return goal.businessGoalId == this.props.goalId;
            });
            if (fileterGoal[0].length != 0) {
                this.biLen = fileterGoal[0].businessInitiatives.length;
                if (this.biLen > 0) {
                    for (let i = 0; i < this.biLen; i++) {
                        this.itLen = this.itLen + fileterGoal[0].businessInitiatives[i].itInitiatives.length;
                        this.vmLen = this.vmLen + fileterGoal[0].businessInitiatives[i].wmwareInitiatives.length;
                    }
                }
            }
        }
    }
    validateForm() {
        if (this.props.businessGoalInput != "") {
            this.props.handleSave();
        }
    }
    count(businessInitiatives) {
        let it = 0;
        let vm = 0;
        _.each(businessInitiatives, (o) => {
            it += o.itInitiatives.length;
            vm += o.wmwareInitiatives.length
        });
        return `${it} IT Initiative(s) and ${vm} VMware Initiative(s)`
    }


    render = () => {
        let deleteBtn;
        if (this.props.goalId != "") {
            deleteBtn = <Button key="submit" type="danger" onClick={() => this.setState({ confirmDelete: true })}>Delete</Button>
        }
        return (
            <div>
                {this.props.visible && <Modal
                    className="creat-new-goal"
                    title={this.props.heading}
                    visible={this.props.visible}
                    centered
                    onCancel={this.props.handleCancel}
                    footer={[
                        deleteBtn
                        ,
                        <Button key="submit" disabled={this.props.businessGoalInput === ""} type="primary" onClick={() => this.validateForm()}>
                            Save
                    </Button>
                    ]}
                >
                    <Input
                        value={this.props.businessGoalInput}
                        label={"Enter Goal*"}
                        floatingLabel={true}
                        onChange={(e) => this.props.businessGoalInputVal(e)}
                    />


                </Modal>
                }
                {this.state.confirmDelete &&

                    <DeletePopup
                        heading="Delete Business Goal"
                        visible={this.state.confirmDelete}
                        ok={() => this.props.handleDelete(this.state)}
                        cancel={() => this.ConfHandleCancel()}
                        okText="Yes delete it"
                        cancelText="No, cancel it"
                        contents="Are you sure you want to delete the Goal ?"
                        subContents={
                            <div>
                                {this.props.businessGoalReducer.businessGoals[this.props.goalIndex].businessInitiatives.length > 0 &&
                                    <div>
                                        <span className="will-also">Will also delete</span><br />
                                        <p className="blue-text">
                                            {this.props.businessGoalReducer.businessGoals[this.props.goalIndex].businessInitiatives.length} Business initiative(s),
                                    {this.count(this.props.businessGoalReducer.businessGoals[this.props.goalIndex].businessInitiatives)}
                                        </p>
                                    </div>
                                }
                            </div>
                        }
                    />

                }
            </div>
        )
    }

}

AddBusinessGoal.propTypes = {
}

export default AddBusinessGoal;
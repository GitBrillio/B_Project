import React, { Component } from "react";
import Input from "muicss/lib/react/input";
// import './AddNewBusinessInitiative.scss';
import { Row, Col, Radio, Calendar } from "antd";
import InputITAlignment from "../../../../../common/InputITAlignment/InputITAlignment";
const RadioGroup = Radio.Group;

class ItInitiativeInput extends Component {
  render = () => {
    return (
      <div>
        <Row padding-bottom>
          <Col span={14}>
            <p className="par">DETAILS</p>
          </Col>
          <Col span={10}>
            <p className="par">SCHEDULE</p>
          </Col>
        </Row>
        <Row gutter={32} className="business-initiative-block-main">
          <Col className="gutter-row padding" span={14}>
            <Input
              value={this.props.businessGoalInput}
              disabled={true}
              label={"Business Initiative"}
              floatingLabel={true}
              autoComplete="off"
            />
          </Col>
          <Col className="gutter-row padding" span={10}>
            <Input
              label={"Time Horizon"}
              floatingLabel={true}
              value={this.props.targetValue.timeHorizon}
              onChange={e => this.props.handleChangeVal(e)}
              name={"time"}
              autoComplete="off"
            />
            {/* <Calendar /> */}
          </Col>
        </Row>
        <Row gutter={32} className="business-initiative-block-main">
          <Col className="gutter-row padding" span={14}>
            <Input
              label={"Enter IT Intitiative*"}
              value={this.props.targetValue.goal}
              onChange={e => this.props.handleChangeVal(e)}
              name={"itName"}
              floatingLabel={true}
              autoComplete="off"
            />
          </Col>
          {/* <Col className="gutter-row padding" span={10}>
            <p className="par">PEOPLE</p>
          </Col> */}
        </Row>
        <Row gutter={32} className="business-initiative-block-main">
          <Col className="gutter-row padding" span={14}>
            <Input
              label={"Description"}
              value={this.props.targetValue.description}
              onChange={e => this.props.handleChangeVal(e)}
              name={"description"}
              floatingLabel={true}
              autoComplete="off"
            />
          </Col>
          <Col className="gutter-row padding" span={10}>
            <p className="par">PEOPLE</p>
          </Col>
        </Row>
        <Row gutter={32} className="business-initiative-block-main">
          <Col className="gutter-row padding" span={14}>
            <Input
              label={"Enter Objective and Metrics"}
              floatingLabel={true}
              value={this.props.targetValue.objectiveAndMetrics}
              onChange={e => this.props.handleChangeVal(e)}
              name={"objective"}
              autoComplete="off"
            />
          </Col>
          <Col className="gutter-row padding" span={10}>
            <Input
              label={"Initiative Leader"}
              floatingLabel={true}
              autoComplete="off"
              value={this.props.targetValue.initiativeLeader}
              onChange={e => this.props.handleChangeVal(e)}
              name={"initiativeLeader"}
            />
          </Col>
        </Row>
        <Row gutter={32} className="business-initiative-block-main">
          <Col className="gutter-row padding" span={14}>
            {/* <Input
                            label={"Enter Budget"}
                            floatingLabel={true}
                            value={this.props.targetValue.budget}
                            onChange={(e) => this.props.handleChangeVal(e)}
                            name={"budget"}
                            autoComplete="off"
                        /> */}
            <InputITAlignment
              label={"Enter Budget"}
              floatingLabel={true}
              value={this.props.targetValue.budget}
              onChange={e => this.props.handleChangeVal(e)}
              name={"budget"}
              autoComplete="off"
              type="number"
              pattern="^([0-9]*)\.?([0-9]{1,2})?$"
              max={10000000000000}
            />
          </Col>
          <Col className="gutter-row padding" span={10}>
            <Input
              label={"Executive Sponsor"}
              floatingLabel={true}
              value={this.props.targetValue.executiveSponsor}
              onChange={e => this.props.handleChangeVal(e)}
              name={"executiveSponser"}
              autoComplete="off"
            />
          </Col>
        </Row>
        <Row gutter={32} className="business-initiative-block-main">
          <Col className="gutter-row padding" span={14}>
            <p>Clear link to business?</p>
            <RadioGroup
              onChange={e => this.props.handleChangeVal(e)}
              name={"linkStatus"}
              value={this.props.targetValue.linkStatus}
            >
              <Radio value={1}>Yes</Radio>
              <Radio value={2}>No</Radio>
            </RadioGroup>
          </Col>
        </Row>
      </div>
    );
  };
}

ItInitiativeInput.propTypes = {};

export default ItInitiativeInput;

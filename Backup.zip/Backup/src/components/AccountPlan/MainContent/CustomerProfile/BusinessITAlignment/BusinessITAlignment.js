import React, { Component } from "react";
import { Layout } from "antd";
import "./BusinessITAlignment.scss";
const { Content } = Layout;
import { Button, Collapse, Row, Col } from "antd";
import AddBusinessGoal from "./AddBusinessGoal/AddBusinessGoal";
import AddNewBusinessInitiative from "./AddNewBusinessInitiative/AddNewBusinessInitiative";
import AddNewITInitiative from "./AddITInitiatives/AddNewITInitiative";
import AddNewVMwareInitiative from "./addVMwareInitiative/AddNewVMwareInitiative";
const Panel = Collapse.Panel;
import PropTypes from "prop-types";

class BusinessITAlignment extends Component {
  state = {
    addnewModal: false,
    type: "",
    AddNewBusinessInitiative: false,
    AddNewITInitiative: false,
    AddNewVMwareInitiative: false,
    businessGoalInput: "",
    goalId: "",
    itId: null,
    itGoal: "",
    vmName: "",
    vmId: null,
    businessInitiativesId: null,
    vmWareInput: ""
  };
  goalCancel() {
    this.setState({
      addnewModal: false,
      type: "",
      index: null,
      AddNewBusinessInitiative: false,
      AddNewITInitiative: false,
      AddNewVMwareInitiative: false,
      businessGoalInput: "",
      goalId: "",
      itGoal: "",
      itId: null,
      vmName: "",
      vmId: null,
      businessInitiativesId: null,
      biName: "",
      vmWareInput: ""
    });
  }
  saveGoal(data, type) {
    if (type === "edit") {
      this.editGoal(data);
    } else {
      this.saveData(data);
    }
  }

  saveData(data) {
    let body = {
      goal: data,
      accountPlanId: this.props.accountPlanId
    };

    this.setState({
      addnewModal: false,
      type: "",
      businessGoalInput: "",
      goalId: ""
    });
    this.props.actions.saveBusinessGoal(body, "POST", "PUSH");
  }
  editGoal(data) {
    let body = {
      goal: data,
      accountPlanId: this.props.accountPlanId,
      businessGoalId: this.state.goalId,
      index: this.state.goalIndex
    };
    this.setState({
      addnewModal: false,
      type: "",
      businessGoalInput: "",
      goalId: ""
    });
    this.props.actions.saveBusinessGoal(body, "POST", "CHANGE_BI_GOAL_NAME");
  }
  deleteGoal() {
    let body = {
      businessGoalId: this.state.goalId,
      accountPlanId: this.props.accountPlanId,
      index: this.state.goalIndex
    };
    this.setState({
      addnewModal: false,
      type: "",
      businessGoalInput: "",
      goalId: ""
    });
    this.props.actions.saveBusinessGoal(body, "DELETE", "DELETE_BUSINESS_GOAL");
  }
  saveBi(data, isNew) {
    this.setState({
      AddNewBusinessInitiative: false,
      goalId: "",
      businessGoalInput: "",
      businessInitiativesId: null
    });
    data.goalIndex = this.state.goalIndex;
    data.biIndex = this.state.biIndex;
    if (isNew) {
      console.log(data);
      this.props.actions.saveBusinessInitiative(data, "POST", "PUSH");
    } else {
      console.log(data);
      this.props.actions.saveBusinessInitiative(data, "POST");
    }
  }

  deleteBi(data) {
    data.biIndex = this.state.biIndex;
    data.goalIndex = this.state.goalIndex;
    this.setState({
      AddNewBusinessInitiative: false,
      goalId: "",
      businessGoalInput: "",
      businessInitiativesId: null
    });
    this.props.actions.saveBusinessInitiative(data, "DELETE", "POP");
  }

  saveIt(data, createOrEdit) {
    data.goalIndex = this.state.goalIndex;
    data.biIndex = this.state.biIndex;
    data.itIndex = this.state.itIndex;
    this.setState({
      AddNewITInitiative: false,
      itGoal: "",
      itId: null,
      businessGoalInput: "",
      businessInitiativesId: null
    });
    if (createOrEdit === "create") {
      this.props.actions.saveItInitiative(data, "POST", "PUSH_IT_INITIATIVE");
    } else {
      this.props.actions.saveItInitiative(
        data,
        "POST",
        "UPDATE_IT_INITIATIVE_NAME"
      );
    }
  }

  deleteIt(data) {
    data.biIndex = this.state.biIndex;
    data.goalIndex = this.state.goalIndex;
    data.itIndex = this.state.itIndex;
    this.setState({
      AddNewITInitiative: false,
      itGoal: "",
      itId: null,
      businessGoalInput: "",
      businessInitiativesId: null
    });
    this.props.actions.saveItInitiative(data, "DELETE", "POP_IT_INITIATIVE");
  }

  saveVm() {
    let body = {
      vmwareInitiativeId: this.state.vmId,
      goal: this.state.vmName,
      businessInitiativeId: this.state.businessInitiativesId,
      accountPlanId: this.props.accountPlanId,
      biIndex: this.state.biIndex,
      goalIndex: this.state.goalIndex,
      vmIndex: this.state.vmIndex
    };
    if (this.state.vmId === null) {
      // save it
      this.props.actions.saveVmInitiative(
        body,
        "POST",
        "PUSH_VMWARE_INITIATIVE"
      );
    } else {
      this.props.actions.saveVmInitiative(
        body,
        "POST",
        "UPDATE_VMWARE_INITIATIVE"
      );
    }
    this.setState({
      AddNewVMwareInitiative: false,
      vmId: null,
      businessInitiativesId: null,
      vmName: ""
    });
  }

  deleteVm() {
    let body = {
      vmwareInitiativeId: this.state.vmId,
      goal: this.state.vmName,
      businessInitiativeId: this.state.businessInitiativesId,
      accountPlanId: this.props.accountPlanId,
      biIndex: this.state.biIndex,
      goalIndex: this.state.goalIndex,
      vmIndex: this.state.vmIndex
    };
    this.setState({
      AddNewVMwareInitiative: false,
      vmId: null,
      businessInitiativesId: null
    });
    this.props.actions.saveVmInitiative(
      body,
      "DELETE",
      "POP_VMWARE_INITIATIVE"
    );
  }
  componentDidMount() {
    this.props.actions.getBusinessGoals(this.props.accountPlanId);
  }

  render = () => {
    return (
      <section className="businessITAlignment">
        <Layout>
          <Content style={{ padding: 24, margin: 0 }}>
            <div className="menu-selected">Customer Profile</div>
            <div className="submenu-tag-info">
              <span className="submenu-selected">Business & IT Alignment</span>
            </div>
            {/* Checking for Goals */}
            {this.props.businessGoalReducer.businessGoals.length === 0 ? (
              <div className="new-goal">
                <button
                  className="dashed-btn"
                  type="dashed"
                  onClick={() => this.setState({ addnewModal: true })}
                >
                  Create New Goal
                </button>
              </div>
            ) : (
              <div>
                <button
                  className="create-goal"
                  onClick={() => this.setState({ addnewModal: true })}
                >
                  Create New Goal
                </button>
                
                  {this.props.businessGoalReducer.businessGoals.map(
                    (goal, index) => (
                    <Collapse key={index} style={{marginTop:15}}>
                      <Panel
                        header={
                          <div className="collapse-main">
                            <span className="collapse-header">
                              {" "}
                              <b> Business Goal: </b> {goal.businessGoal}{" "}
                            </span>
                          </div>
                        }
                        key={index}
                      >
                        <div key={index}>
                          {/* Checking for Business Initiatives */}
                          {goal.businessInitiatives.length != 0 ? (
                            <section>
                              <table className="business-table">
                                <thead>
                                  <tr>
                                    <th>Business Initiative</th>
                                    <th>IT Initiatives</th>
                                    <th>VMware Initiatives</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {goal.businessInitiatives.map(
                                    (businessInitiatives, key) => (
                                      <tr key={key}>
                                        <td>
                                          <span>
                                            <a
                                              onClick={() =>
                                                this.setState({
                                                  AddNewBusinessInitiative: true,
                                                  goalId: goal.businessGoalId,
                                                  businessGoalInput:
                                                    goal.businessGoal,
                                                  businessInitiativesId:
                                                    businessInitiatives.businessInitiativeId,
                                                  biIndex: key,
                                                  goalIndex: index
                                                })
                                              }
                                            >
                                              {
                                                businessInitiatives.businessInitiativeName
                                              }
                                            </a>
                                          </span>
                                        </td>
                                        <td>
                                          {/* Checking for IT initiatives */}
                                          {businessInitiatives.itInitiatives
                                            .length === 0 ? (
                                            <button
                                              className="dashed-btn"
                                              type="dashed"
                                              onClick={() =>
                                                this.setState({
                                                  AddNewITInitiative: true,
                                                  businessInitiativesId:
                                                    businessInitiatives.businessInitiativeId,
                                                    businessGoalInput:
                                                    businessInitiatives.businessInitiativeName,
                                                  goalIndex: index,
                                                  biIndex: key
                                                })
                                              }
                                            >
                                              + Add IT Initiatives{" "}
                                            </button>
                                          ) : (
                                            <div>
                                              {businessInitiatives.itInitiatives.map(
                                                (itInitiatives, itKey) => (
                                                  <div key={itKey}>
                                                    {" "}
                                                    <a
                                                      onClick={() =>
                                                        this.setState({
                                                          AddNewITInitiative: true,
                                                          businessInitiativesId:
                                                            businessInitiatives.businessInitiativeId,
                                                          businessGoalInput:
                                                            businessInitiatives.businessInitiativeGoal,
                                                          itId:
                                                            itInitiatives.itInitiativeId,
                                                          itGoal:
                                                            itInitiatives.itGoal,
                                                          goalIndex: index,
                                                          biIndex: key,
                                                          itIndex: itKey
                                                        })
                                                      }
                                                    >
                                                      {" "}
                                                      {
                                                        itInitiatives.itGoal
                                                      }{" "}
                                                    </a>
                                                  </div>
                                                )
                                              )}
                                              <div>
                                                {" "}
                                                <a
                                                  onClick={() =>
                                                    
                                                    { this.setState({
                                                      AddNewITInitiative: true,
                                                      businessInitiativesId:
                                                        businessInitiatives.businessInitiativeId,
                                                      businessGoalInput:
                                                        businessInitiatives.businessInitiativeName,
                                                      goalIndex: index,
                                                      biIndex: key
                                                    })}
                                                  }
                                                >
                                                  {" "}
                                                  +Add New{" "}
                                                </a>
                                              </div>
                                            </div>
                                          )}
                                        </td>
                                        <td>
                                          {/* Checking for VMware initiatives */}
                                          {businessInitiatives.wmwareInitiatives
                                            .length === 0 ? (
                                            <button
                                              className="dashed-btn"
                                              type="dashed"
                                              onClick={() =>
                                                this.setState({
                                                  AddNewVMwareInitiative: true,
                                                  businessInitiativesId:
                                                    businessInitiatives.businessInitiativeId,
                                                  biName:
                                                    businessInitiatives.businessInitiativeName,
                                                  goalIndex: index,
                                                  biIndex: key
                                                  //vmIndex: vmIndex
                                                })
                                              }
                                            >
                                              + Add VMware Initiatives{" "}
                                            </button>
                                          ) : (
                                            <div>
                                              {businessInitiatives.wmwareInitiatives.map(
                                                (
                                                  vmwareInitiatives,
                                                  vmIndex
                                                ) => (
                                                  <div>
                                                    {" "}
                                                    <a
                                                      onClick={() =>
                                                        this.setState({
                                                          AddNewVMwareInitiative: true,
                                                          businessInitiativesId:
                                                            businessInitiatives.businessInitiativeId,
                                                          biName:
                                                            businessInitiatives.businessInitiativeName,
                                                          vmId:
                                                            vmwareInitiatives.vmwareInitiativeId,
                                                          vmName:
                                                            vmwareInitiatives.vmwareGoal,
                                                          goalIndex: index,
                                                          biIndex: key,
                                                          vmIndex: vmIndex
                                                        })
                                                      }
                                                    >
                                                      {" "}
                                                      {
                                                        vmwareInitiatives.vmwareGoal
                                                      }{" "}
                                                    </a>
                                                  </div>
                                                )
                                              )}
                                              <div>
                                                {" "}
                                                <a
                                                  onClick={() =>
                                                    this.setState({
                                                      AddNewVMwareInitiative: true,
                                                      businessInitiativesId:
                                                        businessInitiatives.businessInitiativeId,
                                                      biName:
                                                        businessInitiatives.businessInitiativeName,
                                                      goalIndex: index,
                                                      biIndex: key
                                                    })
                                                  }
                                                >
                                                  {" "}
                                                  +Add New
                                                </a>{" "}
                                              </div>
                                            </div>
                                          )}
                                        </td>
                                      </tr>
                                    )
                                  )}
                                </tbody>
                              </table>
                              <div className="goal-footer">
                                <div>
                                  {" "}
                                  <a
                                    onClick={() =>
                                      this.setState({
                                        AddNewBusinessInitiative: true,
                                        goalId: this.props.businessGoalReducer
                                          .businessGoals[index].businessGoalId,
                                        businessGoalInput: this.props
                                          .businessGoalReducer.businessGoals[
                                          index
                                        ].businessGoal,
                                        goalIndex: index
                                      })
                                    }
                                  >
                                    {" "}
                                    + Add New Business Initiative
                                  </a>{" "}
                                </div>
                                <div>
                                  {" "}
                                  <a
                                    onClick={() =>
                                      this.setState({
                                        addnewModal: true,
                                        type: "edit",
                                        goalIndex: index,
                                        goalId: this.props.businessGoalReducer
                                          .businessGoals[index].businessGoalId,
                                        businessGoalInput: this.props
                                          .businessGoalReducer.businessGoals[
                                          index
                                        ].businessGoal
                                      })
                                    }
                                  >
                                    {" "}
                                    Edit Goal{" "}
                                  </a>{" "}
                                </div>
                              </div>
                            </section>
                          ) : (
                            <div>
                              <div className="new-bi-initiative">
                                <button
                                  className="dashed-btn"
                                  type="dashed"
                                  onClick={() =>
                                    this.setState({
                                      AddNewBusinessInitiative: true,
                                      goalId: this.props.businessGoalReducer
                                        .businessGoals[index].businessGoalId,
                                      goalIndex: index,
                                      businessGoalInput: this.props
                                        .businessGoalReducer.businessGoals[
                                        index
                                      ].businessGoal
                                    })
                                  }
                                >
                                  + Create New Business Initative
                                </button>
                              </div>
                              <div className="goal-footer">
                                <div>
                                  {" "}
                                  <a
                                    onClick={() =>
                                      this.setState({
                                        addnewModal: true,
                                        type: "edit",
                                        goalIndex: index,
                                        goalId: this.props.businessGoalReducer
                                          .businessGoals[index].businessGoalId,
                                        businessGoalInput: this.props
                                          .businessGoalReducer.businessGoals[
                                          index
                                        ].businessGoal
                                      })
                                    }
                                  >
                                    {" "}
                                    Edit Goal{" "}
                                  </a>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </Panel>
                      </Collapse>
                    )
                  )}
                
              </div>
            )}
          </Content>
          {this.state.addnewModal && (
            <AddBusinessGoal
              visible={this.state.addnewModal}
              heading="Create New Goal"
              handleCancel={() => this.goalCancel()}
              handleSave={() =>
                this.saveGoal(this.state.businessGoalInput, this.state.type)
              }
              handleDelete={() => this.deleteGoal()}
              businessGoalInputVal={e =>
                this.setState({ businessGoalInput: e.target.value })
              }
              businessGoalInput={this.state.businessGoalInput}
              accountPlanId={this.props.accountPlanId}
              goalId={this.state.goalId}
              actions={this.props.actions}
              goalIndex={this.state.goalIndex}
              businessGoalReducer={this.props.businessGoalReducer}
            />
          )}
          {this.state.AddNewBusinessInitiative && (
            <AddNewBusinessInitiative
              visible={this.state.AddNewBusinessInitiative}
              heading="Create Business Initiative"
              handleCancel={() => this.goalCancel()}
              handleDelete={data => this.deleteBi(data)}
              handleSave={(data, type) => this.saveBi(data, type)}
              businessGoalInput={this.state.businessGoalInput}
              accountPlanId={this.props.accountPlanId}
              goalId={this.state.goalId}
              businessInitiativesId={this.state.businessInitiativesId}
              actions={this.props.actions}
              goalIndex={this.state.goalIndex}
              biIndex={this.state.biIndex}
              businessGoalReducer={this.props.businessGoalReducer}
            />
          )}
          {this.state.AddNewITInitiative && (
            <AddNewITInitiative
              visible={this.state.AddNewITInitiative}
              heading="Create New IT Initiative"
              handleCancel={() => this.goalCancel()}
              handleDelete={data => this.deleteIt(data)}
              handleSave={(data, createOrEdit) =>
                this.saveIt(data, createOrEdit)
              }
              accountPlanId={this.props.accountPlanId}
              biName={this.state.biName}
              businessInitiativesId={this.state.businessInitiativesId}
              itId={this.state.itId}
              itGoal={this.state.itGoal}
              actions={this.props.actions}
              businessGoalInput={this.state.businessGoalInput}
              businessGoalReducer={this.props.businessGoalReducer}
            />
          )}
          {this.state.AddNewVMwareInitiative && (
            <AddNewVMwareInitiative
              visible={this.state.AddNewVMwareInitiative}
              heading="Create VMware Initiative"
              handleSave={() => this.saveVm()}
              handleDelete={() => this.deleteVm()}
              handleCancel={() => this.goalCancel()}
              accountPlanId={this.props.accountPlanId}
              biName={this.state.biName}
              businessInitiativesId={this.state.businessInitiativesId}
              vmId={this.state.vmId}
              vmWareInputVal={e => this.setState({ vmName: e.target.value })}
              vmName={this.state.vmName}
              actions={this.props.actions}
            />
          )}
        </Layout>
      </section>
    );
  };
}

BusinessITAlignment.propTypes = {
  actions: PropTypes.object,
  businessGoalReducer: PropTypes.object,
  accountPlanId: PropTypes.string
};

BusinessITAlignment.defaultProps = {
  actions: {},
  businessGoalReducer: {},
  accountPlanId: ""
};
export default BusinessITAlignment;

import React, { Component } from 'react';
import { Icon, Popover, Collapse } from 'antd'; //Input
import VmSelect from '../../../../common/VmSelect/VmSelect';
import { taggedUser } from '../taggedUser/taggedUser';
import VmFloatingInput from '../../../../common/VmFloatingInput/VmFloatingInput';
import PropTypes from 'prop-types';
import _ from 'underscore';
import { isDirty } from '../../../../../Services/Validate';

const Panel = Collapse.Panel;


class KeyDetails extends Component {


    componentDidMount(){
        this.props.actions.fetchLookupData(
            ['Industry','Employees'],
            this.props.accountPlanId,
            this.props.actions.fetchKeyDetails
        );
        
        //key details
    }

    getDefault(arr,id){
        //if(arr.length > 0 && id.toString().length > 0){
            let formatedObj = _.find(arr,(obj)=>{
                return obj.lookUpId === id
            });
    
            if(typeof formatedObj !== 'undefined'){
                return formatedObj.value
            }
        //}
    }

    
    updateKeyDetails(){
        setTimeout(()=>{
            this.props.actions.updateKeyDetails(this.props.overview.keyDetails);
        },0)
    }


    render = () => {
        return (
            <Collapse defaultActiveKey={['1']}>
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Key Details</span>
                    <span className="red-star">*</span>
                    {/* <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span> */}
                    {/* <Popover placement="leftTop" content={taggedUser()} title="Currently Tagged:">
                        <span className="info-icon">
                            <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                        </span>
                    </Popover> */}
                </div>} key="1">
                    <section>
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4" style={{paddingTop:'21px'}}>
                                <VmSelect
                                    label="INDUSTRY"
                                    placeholder={this.getDefault(this.props.overview.Industry,this.props.overview.keyDetails.industryId)}
                                    id="lookUpId"
                                    value="value"
                                    name="industryId"
                                    options={this.props.overview.Industry}
                                    onChange={e => {
                                        this.props.actions.changeOverviewValue('keyDetails','industryId',e);
                                        this.updateKeyDetails();
                                    }}
                                />
                            </div>
                            <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4" style={{paddingTop:'21px'}}> 
                                
                                <VmSelect
                                    label={"Employees"}
                                    id="lookUpId"
                                    value="value"
                                    name="employeeRangeId"
                                    placeholder={this.getDefault(this.props.overview.Employees,this.props.overview.keyDetails.employeeRangeId)}
                                    options={this.props.overview.Employees}
                                    onChange={e => {
                                        this.props.actions.changeOverviewValue('keyDetails','employeeRangeId',e);
                                        this.updateKeyDetails();
                                    }}
                                />
                            </div>
                            <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                                <VmFloatingInput
                                    type="number"
                                    placeholder="Net Sales (USD)"
                                    pattern="^([0-9]*)\.?([0-9]{1,2})?$"
                                    //maxLength="16"
                                    max={10000000000000}
                                    value={this.props.overview.keyDetails.netSales}
                                    onBlur={this.updateKeyDetails.bind(this)}
                                    onChange={ (e) => {
                                        this.props.actions.changeOverviewValue('keyDetails','netSales',e);
                                    }}
                                />
                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4" style={{ marginTop: '19px' }}>
                                <VmFloatingInput
                                    type="number"
                                    placeholder="Overseas Sales %"
                                    pattern="^([0-9]*)\.?([0-9]{1,2})?$"
                                    max={100}
                                    value={this.props.overview.keyDetails.overseasSales}
                                    onBlur={this.updateKeyDetails.bind(this)}
                                    onChange={ (e) => {
                                        this.props.actions.changeOverviewValue('keyDetails','overseasSales',e);                
                                    }}
                                />
                            </div>
                            <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4" style={{ marginTop: '19px' }}>
                                <VmFloatingInput
                                    type="number"
                                    placeholder="Operating Income (USD)"
                                    pattern="^([0-9]*)\.?([0-9]{1,2})?$"
                                    max={10000000000000}
                                    value={this.props.overview.keyDetails.operationalIncome}
                                    onBlur={this.updateKeyDetails.bind(this)}
                                    onChange={ (e) => {
                                        this.props.actions.changeOverviewValue('keyDetails','operationalIncome',e);
                                    }}
                                />
                            </div>
                            <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4" style={{ marginTop: '19px' }}>
                                {  !isDirty(this.props.overview.keyDetails) &&
                                    <div className="pull-right reqrd-txt">
                                        <Icon type="warning" style={{ color: '#ff153f' }} />
                                        <span className="required-txt">Text fields incomplete!</span>
                                    </div>
                                }
                            </div>
                        </div>
                        
                        
                    </section>
                </Panel>
            </Collapse>

        )
    }
}

KeyDetails.propTypes = {
    overview: PropTypes.object,
    actions: PropTypes.object,
    accountPlanId: PropTypes.string.isRequired
};


export default KeyDetails
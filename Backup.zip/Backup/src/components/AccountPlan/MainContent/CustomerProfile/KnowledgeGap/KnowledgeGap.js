import React, { Component } from "react";
import { Icon, Popover, Collapse, Layout } from "antd"; //Input
import "./knowledge-gap.scss";

import VmTextarea from "../../../../common/VmTextarea/VmTextarea";

const { Content } = Layout;
const Panel = Collapse.Panel;

export default class KnowledgeGap extends Component {
  componentDidMount() {
    this.props.actions.fetchKnowledgeGap(this.props.accountPlanId);
  }

  render = () => {
    return (
      <section className="knowledgeGap">
        <Layout>
          <Content style={{ padding: 24, margin: 0 }}>
            <h3 className="Customer-Profile">Customer Profile</h3>
            <h1 className="Knowledge-Gap">Knowledge Gaps</h1>
            <div>
              <button className="create-newfocus" onClick={()=>this.props.gotoActionPlan()}>
                Go Forward Action Plan
              </button>
            </div>
            <div className="knowledge-VmText">
              <VmTextarea
                title="List key topics, initiatives or people that we as VMware do not know enough about and that we need to investigate further."
                value={
                  this.props.knowledgeGapReducer.knowledgeGapData &&
                  this.props.knowledgeGapReducer.knowledgeGapData.gap
                }
                placeholder="Type here..."
                onChange={e => {
                  this.props.actions.changeknowledgeGap(
                    e.target.value,
                    this.props.accountPlanId
                  );
                }}
                onBlur={() =>
                  this.props.actions.createKnowledgeGap(
                    this.props.knowledgeGapReducer.knowledgeGapData
                  )
                }
                maxLength={5000}
              />
            </div>
          </Content>
        </Layout>
      </section>
    );
  };
}

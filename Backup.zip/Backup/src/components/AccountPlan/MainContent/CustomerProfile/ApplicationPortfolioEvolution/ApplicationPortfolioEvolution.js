import React, { Component } from "react";
import VmInput from "../../../../common/VmInput/VmInput";
import VmSelect from "../../../../common/VmSelect/VmSelect";
const { Content } = Layout;
import { debounce } from "lodash";
import { Layout, Icon, Collapse, Row, Col } from "antd";
const Panel = Collapse.Panel;

import "./ApplicationPortfolioEvolution.scss";

export default class ApplicationPortfolioEvolution extends Component {
  componentDidMount() {
    this.getData();
  }

  getData = () => {
    //this.props.actions.fetchApplicationPortfolio(this.props.accountPlanId);
    this.props.actions.fetchVMWRelationship(this.props.accountPlanId);
  };

  handleCustomerChange = debounce(
    (index, innerIndex, value) => this.props.actions.updateCustomerResponse(index, innerIndex, value),
    10
  );

  handleBusinessOwnerNameChange = debounce(
    (index, innerIndex, value) => this.props.actions.updateBusinessOwnerName(index, innerIndex, value),
    10
  );

  handleBusinessOwnerRoleChange = debounce(
    (index, innerIndex, value) => this.props.actions.updateBusinessOwnerRole(index, innerIndex, value),
    10
  );

  handleImplicationChange = debounce(
    (index, innerIndex, value) => this.props.actions.updateImplication(index, innerIndex, value),
    10
  );

  getDefaultVal(portfolioOwner){
    debugger
    return this.props.portfolio.apiVmw[portfolioOwner.vmwRelationship] === undefined
              ? ""
              : this.props.portfolio.apiVmw[parseInt(portfolioOwner.vmwRelationship)]
  }

  render() {
    return (
      <section className="applicationPortfolio">
        <Layout>
          <Content style={{ padding: 24, margin: 0 }}>
            <div className="menu-selected">Customer Profile</div>

            <div className="submenu-tag-info">
              <span className="submenu-selected">Application Portfolio Evolution</span>
            </div>
            {this.props.portfolio.data.portfolioQuestions.length &&
              this.props.portfolio.data.portfolioQuestions.map((data, index) => {
                return (
                  <div style={{ paddingTop: 15 }}>
                    <Collapse defaultActiveKey={["1"]}>
                      <Panel
                        header={
                          <div className="collapse-main by-prod-grp">
                            <span className="collapse-header">{data.question}</span>
                          </div>
                        }
                        key={index + 1}
                      >
                        <section>
                          <Row className="goal-area">
                            <Col span={23}>
                              <div className="portfolio-heading">CUSTOMER RESPONSE</div>
                              {data.portfolioResponses.map((response, i) => (
                                <div className="response">
                                  <VmInput
                                    placeholder="Type feedback here …"
                                    maxLength={500}
                                    value={response.customerResponse}
                                    floatingLabel={true}
                                    onChange={e => this.handleCustomerChange(index, i, e.target.value)}
                                    onBlur={() =>
                                      this.props.actions.submitCustomerResponse(
                                        index,
                                        i,
                                        response.aprId,
                                        response.customerResponse,
                                        response.apqId,
                                        this.props.accountPlanId
                                      )
                                    }
                                  />
                                  <div>
                                    <Icon
                                      className="minus-circle-custom"
                                      type="minus-circle-o"
                                      onClick={() =>
                                        this.props.actions.deleteCustomerResponse(
                                          index,
                                          i,
                                          response.aprId,
                                          response.customerResponse,
                                          response.apqId,
                                          this.props.accountPlanId
                                        )
                                      }
                                    />
                                  </div>
                                </div>
                              ))}
                            </Col>
                            <div
                              className="col-lg-12 add-more plr0"
                              onClick={() => this.props.actions.createCustomerResponse(index, this.props.accountPlanId)}
                            >
                              + Add Another Row
                            </div>
                          </Row>

                          <Row className="goal-area">
                            <div className="portfolio-heading">NAME OF BUSINESS APPLICATION OWNER </div>
                            {data.portfolioOwners.map((portfolioOwner, i) => (
                              <Row gutter={32} className="business-owner">
                                <Col span={8}>
                                  <div>
                                    <VmInput
                                      placeholder="Enter name …"
                                      maxLength={500}
                                      value={portfolioOwner.ownerName}
                                      floatingLabel={true}
                                      onChange={e => this.handleBusinessOwnerNameChange(index, i, e.target.value)}
                                      onBlur={() =>
                                        this.props.actions.submitOwner(
                                          index,
                                          i,
                                          portfolioOwner.aboId,
                                          portfolioOwner.ownerName,
                                          portfolioOwner.jobRole,
                                          portfolioOwner.apqId,
                                          portfolioOwner.vmwRelationship,
                                          this.props.accountPlanId
                                        )
                                      }
                                    />
                                  </div>
                                </Col>
                                <Col span={8}>
                                  <div>
                                    <VmInput
                                      placeholder="Enter Job Role …"
                                      maxLength={500}
                                      value={portfolioOwner.jobRole}
                                      floatingLabel={true}
                                      onChange={e => this.handleBusinessOwnerRoleChange(index, i, e.target.value)}
                                      onBlur={() =>
                                        this.props.actions.submitOwner(
                                          index,
                                          i,
                                          portfolioOwner.aboId,
                                          portfolioOwner.ownerName,
                                          portfolioOwner.jobRole,
                                          portfolioOwner.apqId,
                                          portfolioOwner.vmwRelationship,
                                          this.props.accountPlanId
                                        )
                                      }
                                    />
                                  </div>
                                </Col>{" "}
                                <Col span={6}>
                                  <div>
                                    <VmSelect
                                      label={"Status of VMW relationship"}
                                      value="optionLabel"
                                      placeholder={
                                        this.getDefaultVal(portfolioOwner)
                                      }
                                      id="optionId"
                                      options={this.props.portfolio.vmw}
                                      onChange={vmwRelationship => {
                                        this.props.actions.submitOwner(
                                          index,
                                          i,
                                          portfolioOwner.aboId,
                                          portfolioOwner.ownerName,
                                          portfolioOwner.jobRole,
                                          portfolioOwner.apqId,
                                          vmwRelationship,
                                          this.props.accountPlanId
                                        );
                                      }}
                                    />
                                  </div>
                                </Col>
                                <div>
                                  <Icon
                                    className="minus-circle-custom-vmw"
                                    type="minus-circle-o"
                                    onClick={() =>
                                      this.props.actions.deleteBusinessOwner(
                                        index,
                                        i,
                                        portfolioOwner.aboId,
                                        portfolioOwner.ownerName,
                                        portfolioOwner.jobRole,
                                        portfolioOwner.apqId,
                                        this.props.accountPlanId
                                      )
                                    }
                                  />
                                </div>
                              </Row>
                            ))}

                            <div
                              className="col-lg-12 add-more plr0"
                              onClick={() => this.props.actions.createBusinessOwner(index, this.props.accountPlanId)}
                            >
                              + Add Another Row
                            </div>
                          </Row>
                          <Row className="goal-area">
                            <Col span={23}>
                              <div className="portfolio-heading">IMPLICATIONS FOR VMW</div>
                              {data.implications.map((implication, i) => (
                                <div className="response">
                                  <VmInput
                                    placeholder="Type here …"
                                    maxLength={500}
                                    value={implication.implication}
                                    floatingLabel={true}
                                    onBlur={() =>
                                      this.props.actions.submitImplication(
                                        index,
                                        i,
                                        implication.implicationId,
                                        implication.implication,
                                        implication.apqId,
                                        this.props.accountPlanId
                                      )
                                    }
                                    onChange={e => this.handleImplicationChange(index, i, e.target.value)}
                                  />
                                  <div>
                                    <Icon
                                      className="minus-circle-custom"
                                      type="minus-circle-o"
                                      onClick={() =>
                                        this.props.actions.deleteImplication(
                                          index,
                                          i,
                                          implication.implicationId,
                                          implication.implication,
                                          implication.apqId,
                                          this.props.accountPlanId
                                        )
                                      }
                                    />
                                  </div>
                                </div>
                              ))}
                            </Col>
                            <div
                              className="col-lg-12 add-more plr0"
                              onClick={() => this.props.actions.createImplications(index, this.props.accountPlanId)}
                            >
                              + Add Another Row
                            </div>
                          </Row>
                        </section>
                      </Panel>
                    </Collapse>
                  </div>
                );
              })}
          </Content>
        </Layout>
      </section>
    );
  }
}

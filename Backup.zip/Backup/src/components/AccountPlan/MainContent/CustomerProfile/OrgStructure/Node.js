import React, { Component } from 'react';
import { Icon } from 'antd';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { ActionCreators } from "../../../../../actions/index";
import NodeModal from './NodeModal';
import DeletePopup from '../../../../common/DeletePopup/DeletePopup';
class Node extends Component {
    state = {
        visible: false,
        add: false,
        delete: false
    }

    deleteNode(){
        //console.log(this.props.node)
        this.setState({
            delete: true
        })
    }
    
    render() {
        return (
            <div className="initechNode">
                <div className="name-node" style={{ cursor: 'pointer' }} onClick={() => {
                    this.props.actions.setOrgData(this.props.node);
                    setTimeout(() => {
                        this.setState({
                            visible: true,
                            add: false,
                            parentId: this.props.node.id
                        })
                    }, 0)
                }}>
                    {this.props.node.name}
                </div>
                <div className="position-node">{this.props.node.position}</div>
                <div className="status-node">{this.props.node.status}</div>
                <Icon onClick={() => {
                    this.setState({
                        visible: true,
                        add: true,
                        parentId: this.props.node.id
                    });
                    this.props.actions.resetOrgStructure();
                }

                } type="plus-circle" />
                {
                    this.state.visible &&
                    <NodeModal
                        visible={this.state.visible}
                        ok={() => { }}
                        //node={this.state.add ? this.props.overviewReducer.orgStructure : this.props.node}
                        node={this.props.overviewReducer.orgStructure}
                        isAdding={this.state.add}
                        cancel={() => { this.setState({ visible: false }) }}
                        actions={this.props.actions}
                        index={this.props.node.index}
                        accountPlanId={this.props.overviewReducer.orgParams.accountPlanId}
                        title={this.props.overviewReducer.orgParams.title}
                        status={this.props.overviewReducer.orgStatus}
                        parentId={this.state.parentId}
                        deleteConfirm={this.deleteNode.bind(this)}
                    />
                }
                {this.state.delete && (
                    <DeletePopup
                    heading="Delete User"
                    visible={true}
                    ok={() => {
                        
                        this.setState({
                            delete: false,
                            visible: false
                        })
                        this.props.actions.deletePeopleOrg(
                            this.props.overviewReducer.orgParams.accountPlanId,
                            this.props.node,
                            this.props.overviewReducer.orgParams.title
                        );

                    }}
                    cancel={() => {
                        this.setState({
                            delete: false
                        })
                    }}
                    okText="Yes delete it"
                    cancelText="No, cancel it"
                    contents="Are you sure you want to delete this user?"
                />

                )}
            </div>
        );
    }
}

const mapStateToProps = function (state) {
    return {
        overviewReducer: state.overview
    }
}

const mapDispatchToProps = function (dispatch) {
    return {
        actions: bindActionCreators(ActionCreators, dispatch)
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(Node);



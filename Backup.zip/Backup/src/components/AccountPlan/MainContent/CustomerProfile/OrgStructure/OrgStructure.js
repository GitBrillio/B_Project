import React, { Component } from "react";
import PropTypes from "prop-types";
import { Layout, Icon, Collapse } from "antd";
import "./org.scss";
// import OrgChart from 'react-orgchart';
// import 'react-orgchart/index.css';
import Node from "./Node";
import NodeModal from "./NodeModal";

const { Content } = Layout;
const Panel = Collapse.Panel;

class OrgStructure extends Component {
  state = {
    visible: false
  };
  //this.props.actions.addPeopleToIndex(this.props.accountPlanId)
  componentDidMount() {
    this.loadData();
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.title !== this.props.title) {
      this.props.actions.fetchOrg(this.props.accountPlanId, nextProps.title);
    }
  }
  loadData() {
    this.props.actions.fetchOrg(this.props.accountPlanId, this.props.title);
  }
  render() {
    return (
      <div className="org-structure">
        <Layout>
          <Content style={{ background: "#F3F9FB", padding: 24, margin: 0, minHeight: 280 }}>
            <div className="menu-selected">Customer Profile</div>
            <div className="submenu-tag-info">
              <span className="submenu-selected">
                {this.props.title === "BUSINESS" ? "Business Organization" : "IT Organisation"}
              </span>
            </div>
            <Collapse defaultActiveKey={["1"]}>
              <Panel
                header={
                  <div className="collapse-main">
                    <span className="collapse-header">Organisation Structure</span>
                    <span className="red-star">*</span>
                  </div>
                }
                key="1"
              >
                {this.props.overviewReducer.org.name !== null ? (
                  <div className="org-area" id="chart-container">
                    <OrgChart tree={this.props.overviewReducer.org} NodeComponent={Node} />
                  </div>
                ) : (
                  <div className="empty-area">
                    <button
                      className="dot-button"
                      type="dashed"
                      onClick={() => {
                        this.setState({ visible: true });
                        this.props.actions.setParamsForOrg({
                          accountPlanId: this.props.accountPlanId,
                          title: this.props.title
                        });
                      }}
                    >
                      Add People
                    </button>
                  </div>
                )}
              </Panel>
            </Collapse>
          </Content>
        </Layout>
        {this.state.visible && (
          <NodeModal
            visible={this.state.visible}
            ok={() => {}}
            brandNew={true}
            node={this.props.overviewReducer.orgStructure}
            status={this.props.overviewReducer.orgStatus}
            isAdding={true}
            cancel={() => {
              this.setState({ visible: false });
            }}
            actions={this.props.actions}
            index={-1}
            title={this.props.title}
            accountPlanId={this.props.accountPlanId}
          />
        )}
      </div>
    );
  }
}

OrgStructure.propTypes = {};

export default OrgStructure;

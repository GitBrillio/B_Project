import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button } from 'antd';
import './node-modal.scss';
import Input from 'muicss/lib/react/input';
import VmSelect from '../../../../common/VmSelect/VmSelect';
import {cloneDeep} from 'lodash';
import DeletePopup from '../../../../common/DeletePopup/DeletePopup';

const pt = {

}

class NodeModal extends Component {

    saveOrUpdate = (node,index) => {
        if(this.props.brandNew){
            this.props.actions.addPeopleToIndex(
                this.props.accountPlanId, 
                node,
                this.props.cancel,
                this.props.title
            );
        } else {
            
            
            let nd = cloneDeep(node);
            nd.parentId = this.props.parentId;
            this.props.actions.addPeople(
                nd,
                index,
                this.props.accountPlanId,
                this.props.title,
                this.props.isAdding ? 'create' : 'update'
            );
            this.props.cancel();
        }
    }

    componentDidMount(){
        this.props.actions.fetchStatus(
            this.props.accountPlanId,
            this.props.title
        )
    }

    closeModal(){
        this.setState({
            delete: false
        })
    }

    getDelete = () => {
        if(this.props.isAdding){
            return [
                <Button key="submit" type="primary" onClick={()=>this.saveOrUpdate(this.props.node,this.props.index)}>
                    {this.props.isAdding ? 'Save' : 'Update'}
                </Button>
            ]
        } else {
            return [
                <Button key="submit" type="primary" onClick={()=>this.saveOrUpdate(this.props.node,this.props.index)}>
                    {this.props.isAdding ? 'Save' : 'Update'}
                </Button>, 
                <Button key="submit" style={{float:'left'}} type="danger" onClick={()=>this.props.deleteConfirm()}>
                    Delete
                </Button>
            ]
        }
        
    }

    render = () => {
        const { visible, cancel,actions,node,isAdding,status } = this.props
        return (<div className="delete-popup-group">
            <Modal
                className="node-modal"
                title={isAdding ? 'Add new' : 'Update'}
                visible={visible}
                onCancel={cancel}
                centered
                footer={this.getDelete()}
            >
                <Input
                    label={"Name*"}
                    floatingLabel={true}
                    value={node.name}
                    onChange={(e)=>{
                        actions.changeNodeData('name',e.target.value)
                    }}
                />
                <Input
                    label={"Title"}
                    floatingLabel={true}
                    value={node.position}
                    onChange={(e)=>actions.changeNodeData('position',e.target.value)}
                />
                
                <VmSelect
                    label={"Status"}
                    placeholder={node.status}
                    id="label"
                    value="label"
                    options={status}
                    onChange={e => {
                        actions.changeNodeData('status',e)
                    }}
                />
            
            </Modal>
        </div>)
    }
}

NodeModal.propTypes = pt;

export default NodeModal;
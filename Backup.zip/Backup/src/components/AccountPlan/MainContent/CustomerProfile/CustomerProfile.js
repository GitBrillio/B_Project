import React, { Component } from 'react';
import PropTypes from "prop-types";
import './CustomerProfile.scss';
import '../MainContent.scss';
import { Layout, Icon, Collapse } from 'antd'; //Input
import KeyDetails from './keyDetails/keyDetails';
import VisionAndStrategy from './visionAndStrategy/VisionAndStrategy';
import KeyFinancials from './keyFinancials/KeyFinancials';
import BusinessInitiatives from './businessInitiatives/BusinessInitiatives';
import BusinessInitiativeGoals from './businessInitiativeGoals/BusinessInitiativeGoals';
const { Content } = Layout;


class CustomerProfile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visible: false
        }
    }

    

    hide = () => {
        this.setState({
            visible: false,
        });
    }

    componentDidMount(){
        // this.props.actions.getAccountDetails({
        //     accountId: this.props.match.params.accountPlanId
        // })
    }

    handleVisibleChange = (visible) => {
        this.setState({ visible });
    }
    render() {
        const content = <div className="popover-cont">
            <div>
                <sapn>John Smith</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Megan Cole</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Ruby Dasmond</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
        </div>
        return (
            <div className="customer-profile">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <div className="menu-selected">Customer Profile</div>
                        <div className="submenu-tag-info">
                            <span className="submenu-selected">Overview</span>
                            {/* <span className="tag-team-membr-cont">
                                <span className="tag-team-membr">Tag a Team Member</span>
                                <Icon type="caret-down" theme="outlined" style={{ color: '#0375b7' }} />
                            </span> */}
                        </div>
                        <KeyDetails 
                            overview={this.props.overviewReducer} 
                            actions={this.props.actions}
                            accountPlanId={this.props.accountPlanId}
                        />
                        <VisionAndStrategy 
                            overview={this.props.overviewReducer} 
                            actions={this.props.actions}
                            accountPlanId={this.props.accountPlanId}
                        />
                        <KeyFinancials 
                            overview={this.props.overviewReducer} 
                            actions={this.props.actions}
                            accountPlanId={this.props.accountPlanId}
                            landingReducer={this.props.landingReducer}
                        />
                        <BusinessInitiatives 
                            issues={this.props.overviewReducer.issues} 
                            actions={this.props.actions} 
                            accountPlanId={this.props.accountPlanId}
                        />
                        <BusinessInitiativeGoals 
                            goals={this.props.overviewReducer.goals} 
                            actions={this.props.actions} 
                            accountPlanId={this.props.accountPlanId}
                        />
                    </Content>
                </Layout>
            </div>
        );
    }
};

CustomerProfile.propTypes = {
    overviewReducer: PropTypes.object,
    actions: PropTypes.object,
    accountPlanId: PropTypes.string.isRequired
};

export default CustomerProfile;
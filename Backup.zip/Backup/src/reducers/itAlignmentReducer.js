import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/itAlignment.json'
import _ from 'underscore';

export const itAlignment = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.SET_IT_ALIGNMENT: {
            newState = cloneDeep(state);
            newState.itAlignment = action.payload;
            return newState;
        }
        default:{
            return state
        }
    }
}
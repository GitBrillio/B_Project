import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/customerStrategy.json'
import _ from 'underscore';

export const customerStrategyReducer = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.FETCH_CUSTOMER_STRATEGY:{
            newState = cloneDeep(state);
            newState.customerStrategy = action.payload;
            return newState;
        }
        case types.FETCH_KEY_SOLUTIONS:{
            newState = cloneDeep(state);
            newState.keySolutions = action.payload;
            return newState;
        }
        case types.FETCH_MATURITY_LEVEL:{
            newState = cloneDeep(state);
            newState.maturityLevel = action.payload;
            return newState;
        }
        case types.CHANGE_MODAL_VALUES:{
            newState = cloneDeep(state);
            newState.csStructure[action.payload.key] = action.payload.value;
            return newState;
        }
        case types.RESET_CS: {
            newState = cloneDeep(state);
            newState.csStructure = action.payload;
            return newState;
        }
        
        default:{
            return state;
        }
    }
}
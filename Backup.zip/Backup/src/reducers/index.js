import { combineReducers } from "redux";
import { user } from "./userReducer";
import { overview } from "./overviewReducer";
import { footprint } from "./footprintReducer";
import { keyMetrics } from "./keyMetricsReducer";
import { strategy } from "./strategyReducer";
import { businessGoal } from "./businessGoalReducer";
import { landing } from "./landingReducer";
import { portfolio } from "./portfolioReducer";
import { customerSuccess } from "./customerSuccessReducer";
import { forwardActionReducer } from "./forwardActionReducer";
import { keydecisionReducer } from "./keydecisionReducer";
import { knowledgeGapReducer } from "./knowledgeGapReducer";
import {partner} from './partnerReducer';
import { customerStrategyReducer } from "./customerStrategyReducer";

const rootReducer = combineReducers({
  user,
  overview,
  footprint,
  keyMetrics,
  strategy,
  businessGoal,
  landing,
  portfolio,
  customerSuccess,
  forwardActionReducer,
  keydecisionReducer,
  knowledgeGapReducer,
  partner,
  customerStrategyReducer
});

export default rootReducer;

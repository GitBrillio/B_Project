import * as types from "../constants/actionTypes";
import initialState from "../constants/initialState/portfolio.json";
import { cloneDeep } from "lodash";

//selectors
const formatVMWData = data => {
  const formattedVMWData = [];
  Object.keys(data).map(key => {
    formattedVMWData.push({
      optionId: key,
      optionLabel: data[key]
    });
  });
  return formattedVMWData;
};
//-------------------------------------------------------------------------------------------

export const portfolio = (state = initialState, action = {}) => {
  let newState = {};
  switch (action.type) {
    case types.GET_APPLICATION_PORTFOLIO_EVOLUTION: {
      newState = cloneDeep(state);
      newState.data = action.payload;
      return newState;
    }
    case types.GET_VMW_RELATIONSHIP: {
      newState = cloneDeep(state);
      newState.apiVmw = action.payload;
      newState.vmw = formatVMWData(action.payload);
      return newState;
    }
    case types.CREATE_CUSTOMER_RESPONSE: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioResponses.push({
        customerResponse: "",
        apqId: newState.data.portfolioQuestions[action.payload.index].apqId,
        accountPlanId: action.payload.accountPlanId
      });
      return newState;
    }
    case types.CREATE_BUSINESS_OWNER: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioOwners.push({
        ownerName: "",
        jobRole: "",
        apqId: newState.data.portfolioQuestions[action.payload.index].apqId,
        accountPlanId: action.payload.accountPlanId
      });
      return newState;
    }
    case types.CREATE_IMPLICATIONS: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].implications.push({
        implication: "",
        apqId: newState.data.portfolioQuestions[action.payload.index].apqId,
        accountPlanId: action.payload.accountPlanId
      });
      return newState;
    }
    case types.UPDATE_CUSTOMER_RESPONSE: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioResponses[
        action.payload.innerIndex
      ].customerResponse = action.payload.value;
      return newState;
    }
    case types.SET_APR_ID: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioResponses[action.payload.innerIndex].aprId =
        action.payload.aprId;
      return newState;
    }
    case types.SET_ABO_ID: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioOwners[action.payload.innerIndex].aboId =
        action.payload.aboId;
      return newState;
    }
    case types.SET_IMPLICATION_ID: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].implications[action.payload.innerIndex].implicationId =
        action.payload.implicationId;
      return newState;
    }
    case types.UPDATE_BUSINESS_OWNER_NAME: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioOwners[action.payload.innerIndex].ownerName =
        action.payload.value;
      return newState;
    }
    case types.UPDATE_BUSINESS_OWNER_ROLE: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioOwners[action.payload.innerIndex].jobRole =
        action.payload.value;
      return newState;
    }
    case types.UPDATE_IMPLICATIONS: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].implications[action.payload.innerIndex].implication =
        action.payload.value;
      return newState;
    }
    case types.DELETE_BUSINESS_OWNER: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioOwners.splice(action.payload.innerIndex, 1);
      return newState;
    }
    case types.DELETE_CUSTOMER_RESPONSE: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].portfolioResponses.splice(action.payload.innerIndex, 1);
      return newState;
    }
    case types.DELETE_IMPLICATION: {
      newState = cloneDeep(state);
      newState.data.portfolioQuestions[action.payload.index].implications.splice(action.payload.innerIndex, 1);
      return newState;
    }
    default: {
      return state;
    }
  }
};

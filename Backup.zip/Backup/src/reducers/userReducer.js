import {
  GET_USER,
  SET_PRESEARCH_PATH,
  SET_USERNAME
} from "../constants/actionTypes";
import { cloneDeep } from "lodash";

export const user = (state = {}, action = {}) => {
  let newState = {};
  if (action.type === GET_USER) {
    newState = cloneDeep(state);
    newState.user = action.payload;
    return newState;
  } else if (action.type === SET_PRESEARCH_PATH) {
    newState = cloneDeep(state);
    newState.path = action.payload;
    return newState;
  } else if (action.type === SET_USERNAME) {
    newState = cloneDeep(state);
    newState.username = action.payload;
    return newState;
  } else if (action.type === "SET_ACCESS") {
    newState = cloneDeep(state);
    newState.access = action.payload;
    return newState;
  } else if (action.type === "LOOPER_METRICS_DATA") {
    newState = cloneDeep(state);
    newState.looperMetrics = action.payload;
    return newState;
  } else if (action.type === "COMPASS_METRICS_DATA") {
    newState = cloneDeep(state);
    newState.compassMetrics = action.payload;
    return newState;
  } else {
    return state;
  }
};

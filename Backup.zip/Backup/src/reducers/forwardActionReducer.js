import { cloneDeep } from "lodash";
import * as types from "../constants/actionTypes";
import initialState from "../constants/initialState/forwardAction.json";
import _ from "underscore";

export const forwardActionReducer = (state = initialState, action = {}) => {
  let newState = {};
  switch (action.type) {
    case types.FETCH_ACTION_PLAN: {
      newState = cloneDeep(state);
      newState.actionPlans = action.payload.data.actionPlans;
      return newState;
    }
    case types.FETCH_ACTION_STATUS: {
      newState = cloneDeep(state);
      newState.data = action.payload.data;
      return newState;
    }

    case types.CREATE_OPPORTUNITY: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].actionPlanId = action.payload.value;
      return newState;
    }

    case types.CREATE_UPDATE_ACTION_PLAN_OPPORTUNITY: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions[action.payload.innerIndex].opportunityActionId =
        action.payload.value;
      return newState;
    }

    case types.ADD_OPPORTUNITY_ACTIONS: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions = [action.payload.value];
      return newState;
    }
    case types.ADD_ANOTHER_ACTIONS: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions.push(action.payload.value);
      return newState;
    }
    case types.ADD_FOCUS_FIELD: {
      newState = cloneDeep(state);
      newState.actionPlans.push(action.payload.value);
      return newState;
    }
    case types.DELETE_ACTION_PLAN: {
      newState = cloneDeep(state);
      newState.actionPlans.splice(action.payload.index, 1);
      return newState;
    }
    case types.DELETE_OPPORTUNITY_ACTION_PLAN: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions.splice(action.payload.innerIndex, 1);
      return newState;
    }
    case types.CHANGE_ACTIONS_PLAN: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions[action.payload.innerIndex].actionPlan =
        action.payload.value;
      return newState;
    }
    case types.CHANGE_ACTIONS_OWNER: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions[action.payload.innerIndex].actionOwner =
        action.payload.value;
      return newState;
    }

    case types.CHECK_ACTION_PLAN: {
      newState = cloneDeep(state);
      if (!newState.actionPlans[action.payload.index].hasOwnProperty("actionPlanId")) {
        newState.actionPlans.splice(action.payload.index, 1);
      }
      return newState;
    }

    case types.CHANGE_DATE: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions[action.payload.innerIndex].dueDate =
        action.payload.value;
      return newState;
    }

    case types.CHANGE_KEY_STATUS: {
      newState = cloneDeep(state);
      newState.actionPlans[action.payload.index].opportunityActions[
        action.payload.innerIndex
      ].actionStatus.actionStatusId = action.payload.value;
      return newState;
    }

    case types.CHANGE_OPPORTUNITY: {
      newState = cloneDeep(state);

      newState.actionPlans[action.payload.index].opportunityName = action.payload.value;

      return newState;
    }
    default: {
      return state;
    }
  }
};

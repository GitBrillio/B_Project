import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/footprint.json'
import _ from 'underscore';
const searchContracts = (searchInput,hanaOpportunityList) => {
    hanaOpportunityList = hanaOpportunityList.filter(e => {
        let oppNo = e.opportunityNumber.toString();
        let oppName = e.opportunityName ;
        return oppNo.includes(searchInput) || oppName.includes(searchInput)
        
    });
    return hanaOpportunityList;
}
export const footprint = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.FETCH_DATA: {
            newState = cloneDeep(state);
            newState[action.payload.key] = action.payload.data;
            return newState;
        }
        case types.PUSH_SYSTEM:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems.push(action.payload.data)
            } else {
                newState.itSystems.push(action.payload.data)
            }
            return newState;
        }
        case types.PUSH_PROVIDER:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.index].providerInfo.push(action.payload.data)
            } else {
                newState.itSystems[action.payload.index].providerInfo.push(action.payload.data)
            }
            return newState;
        }
        case types.DELETE_PROVIDER:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.systemIndex].providerInfo.splice(action.payload.providerIndex,1)
            } else {
                newState.itSystems[action.payload.systemIndex].providerInfo.splice(action.payload.providerIndex,1)
            }
            return newState;
        }
        case types.DELETE_SYSTEM:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems.splice(action.payload.index,1)
            } else {
                newState.itSystems.splice(action.payload.index,1)
            }
            return newState;
        }

        case types.CHANGE_SYSTEM_FIELD:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.index].landscape.landscapeName = action.payload.value
            } else {
                newState.itSystems[action.payload.index].landscape.landscapeName = action.payload.value
            }
            return newState;
        }

        case types.CHANGE_PROVIDER_FIELD:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.systemIndex].providerInfo[action.payload.providerIndex][action.payload.key] = action.payload.value
            } else {
                newState.itSystems[action.payload.systemIndex].providerInfo[action.payload.providerIndex][action.payload.key] = action.payload.value
            }
            return newState;
        }

        case types.UPDATE_SYSTEM:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.index] = action.payload.data
            } else {
                newState.itSystems[action.payload.index] = action.payload.data
            }
            return newState;
        }
        
        
        case types.GET_FOOT_PRINT:{
            newState = cloneDeep(state);
            newState.footPrintAndWhiteSpace = action.payload;
            return newState;
        }
        case types.GET_CUSTOM_CONTRACTS:{
            newState = cloneDeep(state);
            newState.vmwareContracts.customContacts = action.payload;
            return newState;
        }
        case types.FETCH_PRODUCTS: {
            newState = cloneDeep(state);
            newState.vmwareContracts.products = action.payload;
            return newState;
        }
        case types.FETCH_STATUS: {
            newState = cloneDeep(state);
            newState.vmwareContracts.status = action.payload;
            return newState;
        }
        case types.UPDATE_CUSTOM_CONTRACT: {
            newState = cloneDeep(state);
            newState.vmwareContracts.customContacts = action.payload;
            return newState;
        }
        case types.PUSH_CUSTOM_CONTRACT: {
            newState = cloneDeep(state);
            newState.vmwareContracts.customContacts.push(action.payload);
            return newState;
        }
        
        case types.RESET_EDIT_AMBITION:{
            newState = cloneDeep(state);
            newState.vmwareContracts.customContacts[action.payload.index] = action.payload.contract;
            return newState;
        }
        case types.CHANGE_CUSTOM_CONTRACT_MODAL_FIELDS:{
            newState = cloneDeep(state);
            switch(action.payload.title){
                case "contractPeriod":
                        newState.vmwareContracts.inputs.contractFrom = action.payload.value[0];
                        newState.vmwareContracts.inputs.contractTo = action.payload.value[1];
                        break;
                case "status":
                        newState.vmwareContracts.inputs.stage = action.payload.value;
                        break;
                case "ela":
                        if(action.payload.value === "Yes"){
                            newState.vmwareContracts.inputs.elaFlag = 1;
                        }
                        else{
                            newState.vmwareContracts.inputs.elaFlag = 0;
                        }
                        
                        break;
                case "opportunityName":
                        newState.vmwareContracts.inputs.opportunityName = action.payload.value;
                        break;
                case "dealValue":
                        newState.vmwareContracts.inputs.dealValue = action.payload.value;
                        break;
                case "scopeOfRenewalOpportunity":
                        newState.vmwareContracts.inputs.opportunityScope = action.payload.value;
                        break;
                case "products":
                        newState.vmwareContracts.inputs.products = action.payload.value;
                        break;
            }
            
            return newState;
        }
        case types.FETCH_HANA_CONTRACTS : {
            newState = cloneDeep(state);
            newState.vmwareContracts.vmstarContracts = action.payload;
            newState.copyOfHana = action.payload.hanaOpportunityList;
            return newState;
        }
        case types.SEARCH_CONTRACTS: {
            newState = cloneDeep(state);
            newState.vmwareContracts.searchInput = action.payload.input;
            newState.vmwareContracts.vmstarContracts.hanaOpportunityList = searchContracts(action.payload.input,newState.copyOfHana);
            return newState;
        }
        case types.SCOPE_VAL_UPDATE:{
            newState = cloneDeep(state);
            newState.vmwareContracts.vmstarContracts.hanaOpportunityList[action.payload.index].opportunityScope = action.payload.scopeVal;
            return newState;
        }
        case types.UPDATE_VMSTAR_CONTRACT: {
            newState = cloneDeep(state);
            newState.vmwareContracts.vmstarContracts = action.payload;
            return newState;
        }
        case types.SET_PREVIOUS_BOOKING:{
            newState = cloneDeep(state);
            newState.previousBooking = action.payload;
            return newState;
        }
        case types.GET_KEY_COMPETITOR:{
            newState = cloneDeep(state);
            newState.keyCompetitor = action.payload;
            return newState;
        }
        case types.GET_KEY_COMPETITOR_NAME:{
            newState = cloneDeep(state);
            newState.keyCompetitorName = action.payload;
            return newState;
        }
        case types.GET_KEY_COMPETITOR_RR:{
            newState = cloneDeep(state);
            newState.keyCompetitorRR = action.payload;
            return newState;
        }
        case types.GET_KEY_COMPETITOR_ELA:{
            newState = cloneDeep(state);
            newState.keyCompetitorELA = action.payload;
            return newState;
        }
        case types.COMPETITOR_SAVE_DATA:{
            newState = cloneDeep(state);
            newState.keyCompetitor.push(action.payload)
            return newState;
        }
        case types.COMPETITOR_DELETE_DATA:{
            newState = cloneDeep(state);
            newState.keyCompetitor.splice(action.payload,1)
            return newState;
        }
        case types.COMPETITOR_UPDATE_DATA:{
            newState = cloneDeep(state);
            let theIndex = _.findIndex(newState.keyCompetitor,(o)=>{
                return o.kcaId === action.payload.kcaId
            });
            newState.keyCompetitor[theIndex] = action.payload;
            return newState;
        }
        case types.GET_KCA_FOR_EDIT:{
            newState = cloneDeep(state);
            newState.kcaPostData = action.payload
            return newState;
        }
        case types.POST_DATA_KCA_RESET:{
            newState = cloneDeep(state);
            newState.kcaPostData = {
                "kcaId": null,
                "competitorId": null,
                "severityId": null,
                "customerRelationship": "",
                "elaId": null,
                "expiryDate": "",
                "dataCenterSolution": [],
                "hybridCloudSolution": [],
                "securitySolution": [],
                "digitalWorkspaceSolution": [],
                "strengthOrWeakness": "",
                "opportunityOrThreat": "",
                "accountPlanId": ""
            };
            return newState;
        }
        case types.POST_DATA_KCA:{
            newState = cloneDeep(state);
            if(newState.kcaPostData.accountPlanId== "") {
            newState.kcaPostData.accountPlanId = action.payload.accountPlanId;
            }
            switch (action.payload.source) {
                case "cName": {
                  newState.kcaPostData.competitorId = action.payload.value
                  break;
                }
                case "RR": {
                  newState.kcaPostData.severityId = action.payload.value
                  break;
                }
                case "ccRel": {
                  newState.kcaPostData.customerRelationship = action.payload.value
                  break;
                }
                case "ELA": {
                  newState.kcaPostData.elaId = action.payload.value
                  break;
                }
                case "exDate": {
                  newState.kcaPostData.expiryDate = action.payload.value
                  break;
                }
                case "dataCS": {
                  newState.kcaPostData.dataCenterSolution = action.payload.value
                  break;
                }
                case "HybridCS": {
                  newState.kcaPostData.hybridCloudSolution = action.payload.value
                  break;
                }
                case "securityS": {
                  newState.kcaPostData.securitySolution = action.payload.value
                  break;
                }
                case "digWS": {
                    newState.kcaPostData.digitalWorkspaceSolution = action.payload.value
                    break;
                  }
                case "keyStrength": {
                    newState.kcaPostData.strengthOrWeakness = action.payload.value
                    break;
                  }
                case "VMWOP": {
                    newState.kcaPostData.opportunityOrThreat = action.payload.value
                    break;
                  }
                default: {
                  break;
                }
              }              
            return newState;
        }
        default:{
            return state;
        }
    }
}
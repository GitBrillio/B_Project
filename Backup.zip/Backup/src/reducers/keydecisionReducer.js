import { cloneDeep } from "lodash";
import * as types from "../constants/actionTypes";
import initialState from "../constants/initialState/keydecision.json";
import _ from "underscore";

export const keydecisionReducer = (state = initialState, action = {}) => {
  let newState = {};
  switch (action.type) {
    case types.FETCH_KEY_DECISION: {
      newState = cloneDeep(state);
      newState.keydecision = action.payload.data;
      return newState;
    }
    case types.FETCH_KEY_ROLE: {
      newState = cloneDeep(state);
      newState.roledropdown = action.payload.data;
      return newState;
    }

    case types.FETCH_KEY_TYPE: {
      newState = cloneDeep(state);
      newState.typedropdown = action.payload.data;
      return newState;
    }

    case types.FETCH_KEY_EVP: {
      newState = cloneDeep(state);
      newState.evpdropdown = action.payload.data;
      return newState;
    }

    case types.FETCH_VMWARE_SOLUTION: {
      newState = cloneDeep(state);
      newState.vmwareSolutions = action.payload.data;
      return newState;
    }

    case types.CREATE_KDM: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody = action.payload.value;
      return newState;
    }

    case types.CREATE_KDM_QUATER: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].groupByQuarters[action.payload.kdmQuarter][
        action.payload.innerIndex
      ].qeId = action.payload.value;
      return newState;
    }

    case types.ADD_KEY_DECISION: {
      newState = cloneDeep(state);
      newState.keydecision.push(action.payload.value);
      return newState;
    }
    case types.ADD_KDM_QUATER: {
      newState = cloneDeep(state);
      if (!newState.keydecision[action.payload.index].groupByQuarters.hasOwnProperty(action.payload.kdmQuarter)) {
        newState.keydecision[action.payload.index].groupByQuarters[action.payload.kdmQuarter] = [];
      }
      newState.keydecision[action.payload.index].groupByQuarters[action.payload.kdmQuarter].push(action.payload.value);

      return newState;
    }

    case types.ADD_GROUP_QUARTERS: {
      newState = cloneDeep(state);

      newState.keydecision[action.payload.index].groupByQuarters = action.payload.value;
      return newState;
    }

    case types.DELETE_KDM: {
      newState = cloneDeep(state);
      newState.keydecision.splice(action.payload.index, 1);
      return newState;
    }

    case types.DELETE_KDM_QUATER: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].groupByQuarters[action.payload.kdmQuarter].splice(
        action.payload.innerIndex,
        1
      );

      return newState;
    }

    case types.CHANGE_KDM_NAME: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.kdmName = action.payload.value;
      return newState;
    }

    case types.CHANGE_KDM_ROLE: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.kdmRoleId = action.payload.value;
      return newState;
    }
    case types.CHANGE_KDM_TYPE: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.kdmTypeId = action.payload.value;
      return newState;
    }
    case types.CHANGE_KDM_EVP: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.evpId = action.payload.value;
      return newState;
    }

    case types.CHANGE_VMWARE_SOLUTION: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.vmwareSolution = action.payload.value;
      return newState;
    }

    case types.CHANGE_CUSTOMER_INITIATIVE: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.customerStrategicInitiative =
        action.payload.value;
      return newState;
    }

    case types.CHANGE_TARGET_OUTCOME: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.targetOutcome = action.payload.value;
      return newState;
    }

    case types.CHANGE_KDM_DATE: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].capKeyDecisionMakerBody.kdmDate = action.payload.value;
      return newState;
    }

    case types.CHANGE_QUATER_VALUE: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].groupByQuarters[action.payload.kdmQuarter][
        action.payload.innerIndex
      ].qeName = action.payload.value;
      return newState;
    }

    case types.CHANGE_QUATER_DATE: {
      newState = cloneDeep(state);
      newState.keydecision[action.payload.index].groupByQuarters[action.payload.kdmQuarter][
        action.payload.innerIndex
      ].qeDate = action.payload.value;
      return newState;
    }

    case types.CHECK_KEY_DECISION: {
      newState = cloneDeep(state);
      if (newState.keydecision[action.payload.index].capKeyDecisionMakerBody.kdmId === null) {
        newState.keydecision.splice(action.payload.index, 1);
      }
      return newState;
    }

    default: {
      return state;
    }
  }
};

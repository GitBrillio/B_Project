import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import _ from 'underscore';

const initialState = {
    accounts: [],
    selectedAccountIndex: -1,
    selectedAccount: null,
    plans: []
}

export const landing = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.FETCH_ACCOUNTS: {
            newState = cloneDeep(state);
            newState.accounts = action.payload;
            return newState;
        }
        case types.SELECT_ACCOUNT:{
            newState = cloneDeep(state);
            newState.selectedAccount = action.payload.account;
            newState.plans = action.payload.plans;
            newState.selectedAccountIndex = action.payload.index;
            return newState;
        }
        default:{
            return state;
        }
    }
}
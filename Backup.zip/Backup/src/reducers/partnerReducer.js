import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/partners.json'
import _ from 'underscore';

export const partner = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.FETCH_PARTNER_TYPES: {
            newState = cloneDeep(state);
            newState.partnerTypes = action.payload;
            return newState;
        }
        case types.FETCH_PARTNER:{
            newState = cloneDeep(state);
            newState.partners = action.payload;
            return newState;
        }

        case types.CHANGE_PARTNER_KEY:{
            newState = cloneDeep(state);
            newState.partnerStructure[action.payload.key] = action.payload.value;
            return newState;
        }
        case types.FETCH_SAE:{
            newState = cloneDeep(state);
            newState[action.payload.type] = action.payload.data;
            return newState;
        }
        case types.CHANGE_PARTNER_PEOPLE:{
            newState = cloneDeep(state);
            newState.partnerStructure.keyPeoples[action.payload.index][action.payload.key] = action.payload.value;
            return newState;
        }
        case types.ADD_NEW_PARTNER_KEY_PEOPLE:{
            newState = cloneDeep(state);
            newState.partnerStructure.keyPeoples.push(action.payload);
            return newState;
        }

        case types.DELETE_PARTNER_KEY_PEOPLE: {
            newState = cloneDeep(state);
            newState.partnerStructure.keyPeoples.splice(action.payload,1);
            return newState;
        }

        case types.CHANGE_PARTNER_NEXT_STEP:{
            newState = cloneDeep(state);
            newState.partnerStructure.nextStep[action.payload.index] = action.payload.value;
            return newState;
        }
        case types.ADD_NEW_PARTNER_NEXT_STEP:{
            newState = cloneDeep(state);
            newState.partnerStructure.nextStep.push(action.payload);
            return newState;
        }

        case types.DELETE_PARTNER_NEXT_STEP: {
            newState = cloneDeep(state);
            newState.partnerStructure.nextStep.splice(action.payload,1);
            return newState;
        }

        case types.PUSH_PARTNER: {
            newState = cloneDeep(state);
            newState.partners.push(action.payload);
            return newState;
        }

        case types.RESET_PARTNER: {
            newState = cloneDeep(state);
            newState.partnerStructure = action.payload;
            return newState;
        }
        
        
        default:{
            return state
        }
    }
}
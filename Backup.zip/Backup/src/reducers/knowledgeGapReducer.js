import { cloneDeep } from "lodash";
import * as types from "../constants/actionTypes";
import initialState from "../constants/initialState/knowledgeGap.json";
import _ from "underscore";

export const knowledgeGapReducer = (state = initialState, action = {}) => {
  let newState = {};
  switch (action.type) {
    case types.FETCH_KNOWLEDGE_GAP: {
      newState = cloneDeep(state);
      if (action.payload && action.payload.data) {
        newState.knowledgeGapData = action.payload.data;
      } else {
        newState.knowledgeGapData = action.payload;
      }

      return newState;
    }
    case types.CHANGE_KNOWLEDGE_GAP: {
      newState = cloneDeep(state);
      if (Object.keys(newState.knowledgeGapData).length === 0) {
        let data = {
          knowledgeGapId: null,
          gap: null,
          accountPlanId: action.payload.accountPlanId
        };
        newState.knowledgeGapData = data;
      }
      newState.knowledgeGapData.gap = action.payload.value;

      return newState;
    }

    case types.CREATE_KNOWLEDGE_GAP: {
      newState = cloneDeep(state);
      newState.knowledgeGapData.knowledgeGapId = action.payload.value;
      return newState;
    }

    default: {
      return state;
    }
  }
};

import { cloneDeep } from "lodash";
import * as types from "../constants/actionTypes";
import initialState from "../constants/initialState/customerSuccess.json";

export const customerSuccess = (state = initialState, action = {}) => {
  let newState = {};
  switch (action.type) {
    case types.FETCH_CUSTOMER_SATISFACTION: {
      newState = cloneDeep(state);
      newState.data = action.payload.csqTypes;
      return newState;
    }
    case types.SET_CSA_ID_UPDATE_RATIONALE: {
      newState = cloneDeep(state);
    
      Object.values(newState).forEach(element => {
        element.forEach(e => {
          e.questions.forEach(question => {
            if (action.payload.data.csqId === question.csqId) {
              if (!question.csaId) {
                question.csaId = action.payload.data.csaId;
              }
              question.rationale = action.payload.data.rationale;
              question.csqOptions.forEach(button => {
                if (
                  button.csqOptionId === action.payload.data.csqOptionId &&
                  action.payload.data.csaId === question.csaId
                ) {
                  button.selected = true;
                } else {
                  button.selected = false;
                }
              });
            }
          });
        });
      });

      return newState;
    }
    case types.CHANGE_RATIONALE: {
      newState = cloneDeep(state);
      newState.data[action.payload.outerIndex].questions[action.payload.innerIndex].rationale = action.payload.value;
      return newState;
    }

    case types.CHANGE_RESPONSE: {
      newState = cloneDeep(state);
      Object.values(newState).forEach(elements => {
        elements.forEach(element => {
          if (action.payload.csqTypeId === element.csqTypeId) {
            element.questions[action.payload.innerIndex].rationale = action.payload.value;
          }
        });
      });
      return newState;
    }

    case 'UPDATE_CS_BUTTON':{
      newState = cloneDeep(state);
      const {innerIndex,outerIndex,csqOptionId} = action.payload;
      // newState.data[outerIndex].questions[innerIndex].csqOptions.forEach(op => {
      //   op.selected = false;
      // });

      newState.data[outerIndex].questions[innerIndex].selectedOptionId = csqOptionId
      
      return newState;
    }

    default: {
      return state;
    }
  }
};

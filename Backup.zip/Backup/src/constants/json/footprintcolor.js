const data = {
    byProdGrpbarBackgrnd: {
        data: [
            ["SDDC SOLUTIONS", "#8ee35f"],
            ["STORAGE & AVAILABILITY", "#ffb7a8"],
            ["VREALIZE MANAGEMENT", "#25ffc4"],
            ["WORKSPACE ONE", "#ff8073"],
            ["DESKTOP", "#ffea63"],
            ["SERVICES", "#66c1ff"],
            ["VCPP", "#ffb5e8"],
            ["MOBILE", "#8ee39f"],
            ["COMPUTE", "#7bd743"],
            ["Other Products", "#8377d9"]
        ]
    },
    byProdClassbarBackgrnd: {
        data: [
            ["LICENSE & SUBSCRIPTION", "#8377d9"],
            ["SUPT & MAINT", "#25ffc4"],
            ["PSO", "#66c1ff"],
        ]
    },
    ELAtransPurchaseBackgrnd: {
        data: [
            ["1308289", "#8377d9"],
            ["736486", "#ff8073"]
           
        ]
    },
    futurePipelineBackgrnd: {
        data: [
            ["COMPUTE", "#7bd743"]
      
        ]
    }
}

export default data;
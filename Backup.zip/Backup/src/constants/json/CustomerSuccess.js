export const CustomerSuccessData = [
  {
    type: "Overall Satisfaction and Experience",
    data: [
      {
        question: "How satisfied is the customer with VMware?",
        buttonKey: "Highly Satisfied",
        rationale: "jkasfdknkanknksanfksanfkank"
      },
      {
        question: "How would the customer characterize their relationship with VMware?",
        relationship: "Just a vendor",
        rationale: "jkasfdknkanknksanfksanfkank"
      }
    ]
  },

  {
    type: "Overall Strategic Alignment",
    data: [
      {
        question: "How satisfied is the customer with VMware",
        buttonKey: "Highly Satisfied",
        rationale: "jkasfdknkanknksanfksanfkank"
      },
      {
        question: "How would the customer characterize their relationship with VMware?",
        relationship: "Just a vendor",
        rationale: "jkasfdknkanknksanfksanfkank"
      }
    ]
  },
  {
    type: "Overall Success and Adoption",
    data: [
      {
        question: "How satisfied is the customer with VMware",
        buttonKey: "Highly Satisfied",
        rationale: "jkasfdknkanknksanfksanfkank"
      },
      {
        question: "How would the customer characterize their relationship with VMware?",
        relationship: "Just a vendor",
        rationale: "jkasfdknkanknksanfksanfkank"
      }
    ]
  },
  {
    type: "Write in Response",
    data: [
      {
        question: "Any recent or upcoming events that have/will impact the customer experience?",
        rationale: "testing"
      },
      {
        question: "Any recent or upcoming events that have/will impact the customer experience?",
        rationale: "testing again"
      },
      {
        question: "Any recent or upcoming events that have/will impact the customer experience?",
        rationale: "yet again"
      }
    ]
  }
];

//const result = CustomerSuccessData.map(e => console.log(e));
//result;

// "OSE": [],
// "OSAL": [],
// "OSAD": [],
// "Response": [],

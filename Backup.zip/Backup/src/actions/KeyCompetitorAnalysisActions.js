import * as types from "../constants/actionTypes";
import axios from "axios";
import Config from "../config/Config";
import { message } from "antd";
import _ from "underscore";
import { cloneDeep } from "lodash";

let conf = new Config();

export const getKeyCompetitor = accountPlanId => dispatch => {
    let params = {
      method: conf.keyCompetitor.method,
      url: conf.keyCompetitor.url + "/" + accountPlanId + "/footprint/kca/competitor"
    };
    const msg = message.loading("Please wait for a moment we are loading key competitor", 0);
    axios(params).then(response => {
      if (response.status === 200) {
        dispatch({
          type: types.GET_KEY_COMPETITOR,
          payload: response.data.data.keyCompetitor
        });
      } else {
        message.error("Error in fetching key competitor data.");
      }
      msg();
    });
  };
  export const getCometitorsName = accountPlanId => dispatch => {
    let params = {
      method: conf.keyCompetitor.method,
      url: conf.keyCompetitor.url + "/" + accountPlanId + "/footprint/kca/names"
    };
    axios(params).then(response => {
      if (response.status === 200) {
        dispatch({
          type: types.GET_KEY_COMPETITOR_NAME,
          payload: response.data.data
        });
      } else {
        message.error("Error in fetching key competitor data.");
      }
    });
  };
  export const getRelativeRating = accountPlanId => dispatch => {
    let params = {
      method: conf.keyCompetitor.method,
      url: conf.keyCompetitor.url + "/" + accountPlanId + "/footprint/kca/rr"
    };
    axios(params).then(response => {
      if (response.status === 200) {
        dispatch({
          type: types.GET_KEY_COMPETITOR_RR,
          payload: response.data.data
        });
      } else {
        message.error("Error in fetching key competitor data.");
      }
    });
  };
  export const getELA = accountPlanId => dispatch => {
    let params = {
      method: conf.keyCompetitor.method,
      url: conf.keyCompetitor.url + "/" + accountPlanId + "/footprint/kca/ela"
    };
    axios(params).then(response => {
      if (response.status === 200) {
        dispatch({
          type: types.GET_KEY_COMPETITOR_ELA,
          payload: response.data.data
        });
      } else {
        message.error("Error in fetching key competitor data.");
      }
    });
  };
  export const kcaPostData = (val, src, accId) => dispatch => {
    dispatch({
        type: types.POST_DATA_KCA,
        payload: {value: val, source: src, accountPlanId : accId}
      });
  };

  export const resetkcaPostData = () => dispatch => {
    dispatch({
        type: types.POST_DATA_KCA_RESET
      });
  };
  
  export const getCompetitorForEdit = (curData) => dispatch => {    
    dispatch({
        type: types.GET_KCA_FOR_EDIT,
        payload: curData
      });
  };

  export const saveKCA = (accountPlanId, requestBody) => dispatch => {
    let params = {
      method: "POST",
      url: conf.keyCompetitor.url + "/" + accountPlanId + "/footprint/kca/create",
      data: requestBody
    };
    axios(params).then(response => {
      if (response.status === 200) {
        dispatch({
          type: types.COMPETITOR_SAVE_DATA,
          payload: response.data.data.keyCompetitor[0]
        });
      } else {
        message.error("Error while saving key competitor analyses");
      }
      message.success("key competitor analyses saved successfully");
    });
  };

  export const updateKCA = (accountPlanId, requestBody) => dispatch => {
    let params = {
      method: "POST",
      url: conf.keyCompetitor.url + "/" + accountPlanId + "/footprint/kca/update",
      data: requestBody
    };
    axios(params).then(response => {
      if (response.status === 200) {
        dispatch({
          type: types.COMPETITOR_UPDATE_DATA,
          payload: response.data.data.keyCompetitor[0]
        });        
      } else {
        message.error("Error while updating key competitor analyses");
      }
      message.success("key competitor analyses updated successfully");
    });
  };
  
  export const deleteKCA = (accountPlanId, requestBody, index) => dispatch => {
    let params = {
      method: "DELETE",
      url: conf.keyCompetitor.url + "/" + accountPlanId + "/footprint/kca/delete",
      data: requestBody
    };
    axios(params).then(response => {
      if (response.status === 200) {
        dispatch({
          type: types.COMPETITOR_DELETE_DATA,
          payload: index
        });
      } else {
        message.error("Error while deleting key competitor analyses");
      }
      message.success("key competitor analyses deleted successfully");
    });
  };
import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import _ from 'underscore';
import {message} from 'antd';
let conf = new Config();


/****************************** GOALS **********************************/

export const getKeyMetrics = (account) => (dispatch) => {
    let params = {
        method: conf.getKeyMetrics.method,
        url: conf.getKeyMetrics.url + "/" + `keymetrics?accountName=${account.accountPlanName.substr(0,account.accountPlanName.length-6)}&customerId=${account.customerId}`
        //url: conf.getKeyMetrics.url
    }
    const msg = message.loading("Fetching the key details...",0)
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.GET_KEY_METRICS,
                payload: response.data.data
            });
        }
        else if(response.status === 204){
            message.info('Information is not available');
        }
        msg()
    });
}



export const updatePointField = (key,value) => dispatch => {
    dispatch({
        type: types.UPDATE_DATA_POINTS,
        payload:{
            key,value
        }
    })
}

export const updateDataPoints = (points,accountPlanId) => dispatch => {
    let params = {
        method: 'POST',
        url: conf.getKeyMetrics.url + "/" + accountPlanId + "/keymetrics",
        data: points
    }
    const msg = msg.loading("Saveing key opportunities...",)
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.GET_KEY_METRICS,
                payload: response.data.data
            });
            message.success("Key metrics updated successfully!")
        }
        else if (response.status === 204) {
            message.info("No Account Profile found in VMstar")
        }
        else{
            message.error('Error occures while performing the opertation');
        }
        msg();
    });
}
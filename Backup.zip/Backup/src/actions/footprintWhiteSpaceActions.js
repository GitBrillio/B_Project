import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import _ from 'underscore';
import {message} from 'antd';
let conf = new Config();

export const getFootPrint = (accountPlanId) => (dispatch) => {
    let params = {
        method: conf.getFootPrint.method,
        url: conf.getFootPrint.url + "/" + accountPlanId + "/footprint"
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.GET_FOOT_PRINT,
                payload: response.data.data
            });
        }
        else{
            message.error('Error in fetching footprint data.');
        }
    });
}

export const unsetFootPrint = (data) => (dispatch) => {
    dispatch({
        type: types.GET_FOOT_PRINT,
        payload: data
    });
}

export const updateFootprint = (footprint,accountPlanId) => (dispatch) => {
    let params = {
        method: 'POST',
        url: conf.getFootPrint.url + "/" + accountPlanId + "/footprint/status",
        data: footprint
    }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("Footprint updated successfully!")   
        }
        else{
            message.error('Error in fetching footprint data.');
        }
    });
}


export const getPreviousBookings = (accountPlanId,customerId) => (dispatch) => {
    let params = {
        method: conf.getFootPrint.method,
        url: conf.getFootPrint.url + "/" + accountPlanId + "/hana/bookings/pd?custid="+ customerId
        //url: "https://salesweaver-dev.apps.wdc-np.itcna.vmware.com/api/cap/473d4d17-55c0-408e-9344-9adcb09fd570/hana/bookings/pd?custid=CUST-0000367375"
    }
    axios(params).then(response => {

        let pdd =response.data.data.productDivisionData;
        let years = {};
        let SDDC = 0;
        let EUC = 0;
        let SERVICES = 0;
        let CPS = 0
        _.each(pdd,(pd)=>{
            years[pd.year] = pd.yearlyBookings
            _.each(pd.productDivisions,(p)=>{
                switch(p.division){
                    case 'SDDC': SDDC += parseInt(p.divisionBookings);
                            break
                    case 'EUC': EUC += parseInt(p.divisionBookings);
                            break
                    case 'SERVICES': SDDC += parseInt(p.divisionBookings);
                            break
                    case 'CPS': SDDC += parseInt(p.divisionBookings);
                            break
                }
            })
        });
        dispatch({
            type: types.SET_PREVIOUS_BOOKING,
            payload: {
                rowData: pdd,
                year: years,
                service: {
                    SDDC,SERVICES,EUC,CPS
                }
            }
        })
        
    });
}

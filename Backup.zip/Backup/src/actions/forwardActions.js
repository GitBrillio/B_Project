import * as types from "../constants/actionTypes";
import axios from "axios";
import moment from "moment";
import Config from "../config/Config";
import { message } from "antd";
import _ from "underscore";

//changes added
let conf = new Config();

export const fetchActionPlan = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchActionPlan.method,
    url: `${conf.fetchActionPlan.url}/${accountPlanId}/sa/ap`
  };
  const loader = message.loading("Please wait while we fetch action plans...", 0);
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_ACTION_PLAN,
        payload: response.data
      });
    }
    loader();
  });
};

export const fetchActionStatus = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchActionStatus.method,
    url: `${conf.fetchActionStatus.url}/${accountPlanId}/sa/as`
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_ACTION_STATUS,
        payload: response.data
      });
    }
  });
};

export const createOpportunity = (data, index) => dispatch => {
  let params = {
    method: conf.createOpportunity.method,
    url: `${conf.createOpportunity.url}/${data.accountPlanId}/sa/ap`,
    data: data
  };
  const loader = message.loading("Creating action plan...", 0);

  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.CREATE_OPPORTUNITY,
        payload: { value: response.data.data.actionPlanId, index: index }
      });
      message.success(`Opportunity Updated Successfully`);
    }
    loader();
  });
};

export const changeOpportuniy = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_OPPORTUNITY,
    payload: { value, index }
  });
};

export const addfocusfield = () => dispatch => {
  dispatch({
    type: types.ADD_FOCUS_FIELD,
    payload: { value: { opportunityName: "" } }
  });
};

export const addOpportunityActions = index => dispatch => {
  let value = {
    opportunityActionId: null,
    actionPlan: null,
    actionOwner: null,
    emailAddress: null,
    dueDate: moment().format("YYYY-MM-DD"),
    actionStatus: {
      actionStatusId: null
    }
  };
  dispatch({
    type: types.ADD_OPPORTUNITY_ACTIONS,
    payload: { index, value }
  });
};

export const addAnotherActions = index => dispatch => {
  let value = {
    opportunityActionId: null,
    actionPlan: null,
    actionOwner: null,
    emailAddress: null,
    dueDate: moment().format("YYYY-MM-DD"),
    actionStatus: {
      actionStatusId: null
    }
  };
  dispatch({
    type: types.ADD_ANOTHER_ACTIONS,
    payload: { index, value }
  });
};

export const deleteActionsPlan = (accountPlanId, actionPlanId, index) => dispatch => {
  let params = {
    method: conf.deleteActionPlan.method,
    url: `${conf.deleteActionPlan.url}/${accountPlanId}/sa/ap/${actionPlanId}`
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.DELETE_ACTION_PLAN,
        payload: { index }
      });
      message.success(`Action Plan deleted successfuly`);
    }
  });
};

export const deleteOpportunity = (index, innerIndex, accountPlanId, opportunityActionId) => dispatch => {
  let params = {
    method: conf.deleteOpportunityActionPlan.method,
    url: `${conf.deleteOpportunityActionPlan.url}/${accountPlanId}/sa/opportunityAction/${opportunityActionId}`
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.DELETE_OPPORTUNITY_ACTION_PLAN,
        payload: { index, innerIndex }
      });
      message.success(`Opportunity Action Plan deleted successfuly`);
    }
  });
};

export const changeActionPlan = (value, index, innerIndex) => dispatch => {
  dispatch({
    type: types.CHANGE_ACTIONS_PLAN,
    payload: { index, value, innerIndex }
  });
};

export const changeActionOwner = (value, index, innerIndex) => dispatch => {
  dispatch({
    type: types.CHANGE_ACTIONS_OWNER,
    payload: { index, value, innerIndex }
  });
};

export const changeDate = (value, index, innerIndex) => dispatch => {
  dispatch({
    type: types.CHANGE_DATE,
    payload: { index, value, innerIndex }
  });
};

export const changeStatusKey = (index, innerIndex, value) => dispatch => {
  dispatch({
    type: types.CHANGE_KEY_STATUS,
    payload: { index, innerIndex, value }
  });
};

export const checkActionPlan = index => dispatch => {
  dispatch({
    type: types.CHECK_ACTION_PLAN,
    payload: { index }
  });
};

export const createUpdateOpportunityActions = (data, index, innerIndex) => dispatch => {
  const dueDate =
    moment(data.dueDate).format("YYYY-MM-DD") === "Invalid date" ? null : moment(data.dueDate).format("YYYY-MM-DD");
  const formattedData = { ...data, dueDate };
  // console.log(data.dueDate);
  // console.log(formattedData);
  // console.log(data);
  // const accountPlanId = data.accountPlanID;
  // console.log(accountPlanId);
  let params = {
    method: conf.createOpportunity.method,
    url: `${conf.createOpportunity.url}/${data.accountPlanId}/sa/ap`,
    data: formattedData
  };

  axios(params).then(response => {
    console.log(response.data.data);
    if (response.status === 200) {
      dispatch({
        type: types.CREATE_UPDATE_ACTION_PLAN_OPPORTUNITY,
        payload: { value: response.data.data.opportunityActionId, index, innerIndex }
      });
      message.success(`Opportunity Action Updated Successfully`);
    }
  });
};

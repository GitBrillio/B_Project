import * as types from "../constants/actionTypes";
import axios from "axios";
import Config from "../config/Config";
import { message } from "antd";
import _ from "underscore";

let conf = new Config();


export const fetchAccounts = (params) => (dispatch) => {
    const hide = message.loading("Fasten your seatbelt, we are about to land...",0);
    //conf.capUrl + `/accounts?salespersonId=${params.salespersonId}&role=${params.role}&geo=${params.geo}&page=${params.page}&size=${params.size}&query=${params.query}`
    axios({
        method: 'POST',
        url:  `${conf.capUrl}/accounts`,
        data:{
                "salespersonId":params.salespersonId,
                "geo":params.geo,
                "role":params.role,
                "page":params.page,
                "size":params.size,
                "query":params.query
        }
    })
        .then((resp)=>{
            dispatch({
                type: types.FETCH_ACCOUNTS,
                payload: resp.data.data.accounts
            });
            if(resp.data.data.accounts.length === 0){
                message.info("Sorry, you are not tagged to any account");
            } else {
                getAccountDetails(resp.data.data.accounts[0],0)(dispatch);
            }
            
            hide();

    });
};

export const getAccountDetails = (account, index) => dispatch => {
  const hide = message.loading("Hold on, we are loding your account plans...", 0);
  axios
    .get(conf.capUrl + `/accountplan?accountId=${account.accountId}`)
    .then(resp => {
      hide();
      let plans = resp.data.data !== undefined ? [resp.data.data] : [];
      dispatch({
        type: types.SELECT_ACCOUNT,
        payload: {
          index: index,
          account: account,
          plans: plans
        }
      });
    })
    .catch(() => hide());
};

export const getAccountByAccountId = accountId => dispatch => {
  axios.get(`${conf.capUrl}/accountplan?accountId=${accountId}`).then(resp => {
    getAccountDetails(resp.data.data)(dispatch);
  });
};

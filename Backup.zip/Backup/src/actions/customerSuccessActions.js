import * as types from "../constants/actionTypes";
import axios from "axios";
import Config from "../config/Config";
import _ from "underscore";
import { message } from "antd";
import {cloneDeep} from 'lodash';
let conf = new Config();

export const getCustomerSuccess = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchCustomerSuccess.method,
    url: `${conf.fetchCustomerSuccess.url}/${accountPlanId}/footprint/cs`
  };
  const msg = message.loading("Fetching customer success data", 0);
  axios(params).then(response => {
    //console.log(response.data.data);
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_CUSTOMER_SATISFACTION,
        payload: response.data.data
      });
    } else if (response.status === 204) {
      message.info("Information is not available");
    }
    msg();
  });
};


export const updateButton = (outerIndex,innerIndex,index,csqOptionId) => (dispatch) =>{
  dispatch({
    type: 'UPDATE_CS_BUTTON',
    payload:{
      outerIndex,innerIndex,index,csqOptionId
    }
  });
  
}


export const updateCSXData = (css,accountPlanId,index,innerIndex) => (dispatch) => {


  let data = cloneDeep(css);

  let questions = data.questions[innerIndex];
  let csqOptions;
  
  if(index !== null ){
    csqOptions = questions.csqOptions[index];
    questions.csqOptions = [csqOptions]
  } else {
    csqOptions = questions.csqOptions;
    questions.csqOptions = csqOptions
  }

  

  let obj = {
    csqTypeId: data.csqTypeId,
    csqTypeLabel: data.csqTypeLabel,
    hasGraph: data.hasGraph,
    questions: [questions]
  }

 

  let params = {
    method: conf.updateCustomerSuccess.method,
    url: `${conf.updateCustomerSuccess.url}/${accountPlanId}/footprint/cs`,
    data: {csqTypes:[obj]}
  };
  const msg = message.loading("Updating customer success...", 0);
  axios(params).then(response => {
    if (response.status === 200) {
      msg();
      getCustomerSuccess(accountPlanId)(dispatch);
    } else {
      message.info("Error occured while updating");
    }
  }).catch(()=>{
    msg()
  })
}

export const submitCustomerSuccess = (
  csqTypeId,
  csqTypeLabel,
  questions,
  csqOptions,
  accountPlanId,
  isButton = false
) => dispatch => {
  let data;
  //   if (csqOptions.length > 0) {
  csqOptions = [{ ...csqOptions }];
  csqOptions[0].selected = isButton ? true : false;
  // }
  const { csqId, question, csaId, selectedOptionId, rationale } = questions;
  let formattedQuestions = [
    {
      csqId,
      question,
      csqOptions,
      csaId,
      selectedOptionId,
      rationale,
      accountPlanId
    }
  ];
  //   if (csaId === null) {
  //     data = {
  //       csqTypes: [
  //         {
  //           csqTypeId,
  //           csqTypeLabel,
  //           questions: formattedQuestions // this is an array
  //         }
  //       ]
  //     };
  //   } else {
  data = {
    csqTypes: [
      {
        csqTypeId,
        csqTypeLabel,
        questions: formattedQuestions // this is an array
      }
    ]
  };
  //}
  let params = {
    method: conf.updateCustomerSuccess.method,
    url: `${conf.updateCustomerSuccess.url}/${accountPlanId}/footprint/cs`,
    data
  };
  const msg = message.loading("Customer success data updated", 0);
  axios(params).then(response => {
    console.log(response);
    const payload = { csaId, csqId, data: response.data.data };
    if (response.status === 200) {
      msg();
      dispatch({
        type: types.SET_CSA_ID_UPDATE_RATIONALE,
        payload
      });
    } else {
      message.info("Error occured while updating");
    }
  });
};

export const changeRationale = (outerIndex, innerIndex, value) => dispatch => {
  const payload = { outerIndex, innerIndex, value };
  dispatch({
    type: types.CHANGE_RATIONALE,
    payload
  });
};

export const changeResponse = (
  csqTypeId,
  outerIndex,
  innerIndex,
  value
) => dispatch => {
  const payload = { csqTypeId, outerIndex, innerIndex, value };
  dispatch({
    type: types.CHANGE_RESPONSE,
    payload
  });
};

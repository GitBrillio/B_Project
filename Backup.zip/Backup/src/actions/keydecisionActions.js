import * as types from "../constants/actionTypes";
import axios from "axios";
import moment from "moment";
import Config from "../config/Config";
import { message } from "antd";
import _ from "underscore";

//changes added
let conf = new Config();

export const fetchKeyDecision = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchKeyDecision.method,
    url: `${conf.fetchKeyDecision.url}/${accountPlanId}/keyDecision`
  };
  const loader = message.loading("Please wait while we fetch action plans...", 0);
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_KEY_DECISION,
        payload: response.data
      });
    }
    loader();
  });
};

export const fetchRoleDropdown = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchRoleDropdown.method,
    url: `${conf.fetchRoleDropdown.url}/${accountPlanId}/keyDecision/role`
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_KEY_ROLE,
        payload: response.data
      });
    }
  });
};

export const fetchTypeDropdown = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchTypeDropdown.method,
    url: `${conf.fetchTypeDropdown.url}/${accountPlanId}/keyDecision/type`
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_KEY_TYPE,
        payload: response.data
      });
    }
  });
};

export const fetchEvpDropdown = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchEvpDropdown.method,
    url: `${conf.fetchEvpDropdown.url}/${accountPlanId}/keyDecision/evp`
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_KEY_EVP,
        payload: response.data
      });
    }
  });
};

export const fetchVmwareSolutions = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchVmwareSolutions.method,
    url: `${conf.fetchVmwareSolutions.url}/${accountPlanId}/keyDecision/vms`
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_VMWARE_SOLUTION,
        payload: response.data
      });
    }
  });
};

export const createKDM = (data, index) => dispatch => {
  let params = {
    method: conf.createKDM.method,
    url: `${conf.createKDM.url}/${data.accountPlanId}/keyDecision`,
    data: data
  };
  const loader = message.loading("Creating Key Decision...", 0);
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.CREATE_KDM,
        payload: { value: response.data.data, index: index }
      });
      console.log(response.data.data);
      message.success(`Key Decision Updated Successfully`);
    }
    loader();
  });
  console.log(data);
};

export const createUpdateKdmQuaters = (data, index, innerIndex) => dispatch => {
  let params = {
    method: conf.createKDMQuater.method,
    url: `${conf.createKDMQuater.url}/${data.accountPlanId}/keyDecisionQuarter`,
    data: data
  };
  const loader = message.loading("Creating Quaters Decision...", 0);
  const kdmQuarter = data.kdmQuarter;
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.CREATE_KDM_QUATER,
        payload: { value: response.data.data.qeId, index: index, innerIndex, kdmQuarter }
      });

      message.success(`Key Decision Quater updated Successfully`);
    }
    loader();
  });
  console.log(data);
};

export const deleteKdm = (data, index) => dispatch => {
  let params = {
    method: conf.deleteKDM.method,
    url: `${conf.deleteKDM.url}/${data.accountPlanId}/keyDecision`,
    data: data
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.DELETE_KDM,
        payload: { value: response.data.data.kdmId, index: index }
      });
      message.success(`Key Decision Deleted Successfully`);
    }
    loader();
  });
};

export const deleteKdmQuater = (data, index, innerIndex) => dispatch => {
  let params = {
    method: conf.deleteKDMQuater.method,
    url: `${conf.deleteKDMQuater.url}/${data.accountPlanId}/keyDecisionQuarter`,
    data: data
  };
  const kdmQuarter = data.kdmQuarter;
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.DELETE_KDM_QUATER,
        payload: { index, innerIndex, kdmQuarter }
      });
      message.success(`Key Decision Quater Deleted Successfully`);
    }
    loader();
  });
};

export const createKeyDecision = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_OPPORTUNITY,
    payload: { value, index }
  });
};

export const checkKeyDecision = index => dispatch => {
  dispatch({
    type: types.CHECK_KEY_DECISION,
    payload: { index }
  });
};
export const addKeyDecisionfeild = () => dispatch => {
  let data = {
    capKeyDecisionMakerBody: {
      kdmId: null,
      kdmName: "",
      kdmRoleId: null,
      kdmRoleValue: null,
      kdmTypeId: null,
      kdmTypeValue: null,
      evpId: null,
      evpValue: null,
      customerStrategicInitiative: null,
      vmwareSolution: [],
      targetOutcome: null,
      kdmDate: moment().format("YYYY-MM-DD"),
      accountPlanId: null
    },
    groupByQuarters: {}
  };
  dispatch({
    type: types.ADD_KEY_DECISION,
    payload: { value: data }
  });
};

export const addQuatersFeilds = index => dispatch => {
  let data = {
    "1": [
      {
        qeId: null,
        qeName: null,
        emailAddress: null,
        qeDate: null,
        kdmQuarter: 1
      }
    ],
    "2": [
      {
        qeId: null,
        qeName: null,
        emailAddress: null,
        qeDate: null,
        kdmQuarter: 2
      }
    ],
    "3": [
      {
        qeId: null,
        qeName: null,
        emailAddress: null,
        qeDate: null,
        kdmQuarter: 3
      }
    ],
    "4": [
      {
        qeId: null,
        qeName: null,
        emailAddress: null,
        qeDate: null,
        kdmQuarter: 4
      }
    ]
  };
  dispatch({
    type: types.ADD_GROUP_QUARTERS,
    payload: { value: data, index: index }
  });
};

export const addkdmQuater = (index, kdmQuarter) => dispatch => {
  let value = {
    qeId: null,
    qeName: null,
    emailAddress: null,
    qeDate: moment().format("YYYY-MM-DD"),
    kdmQuarter: kdmQuarter
  };
  dispatch({
    type: types.ADD_KDM_QUATER,
    payload: { index, kdmQuarter, value }
  });
};

export const changeKdmName = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_KDM_NAME,
    payload: { index, value }
  });
};

export const changekdmDate = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_KDM_DATE,
    payload: { index, value }
  });
};

export const changekdmRole = (index, value) => dispatch => {
  dispatch({
    type: types.CHANGE_KDM_ROLE,
    payload: { index, value }
  });
};

export const changekdmType = (index, value) => dispatch => {
  dispatch({
    type: types.CHANGE_KDM_TYPE,
    payload: { index, value }
  });
};

export const changekdmEvp = (index, value) => dispatch => {
  dispatch({
    type: types.CHANGE_KDM_EVP,
    payload: { index, value }
  });
};

export const changeCustomerInitiative = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_CUSTOMER_INITIATIVE,
    payload: { index, value }
  });
};

export const changeTargetOutcome = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_TARGET_OUTCOME,
    payload: { index, value }
  });
};

export const changeVmwareSolutions = (index, value) => dispatch => {
  dispatch({
    type: types.CHANGE_VMWARE_SOLUTION,
    payload: { index, value }
  });
};

export const changeQuaterValue = (value, kdmQuarter, index, innerIndex) => dispatch => {
  console.log(innerIndex, index, value, kdmQuarter);
  dispatch({
    type: types.CHANGE_QUATER_VALUE,
    payload: { index, innerIndex, value, kdmQuarter }
  });
};

export const changeQeDate = (value, kdmQuarter, index, innerIndex) => dispatch => {
  dispatch({
    type: types.CHANGE_QUATER_DATE,
    payload: { index, innerIndex, value, kdmQuarter }
  });
};

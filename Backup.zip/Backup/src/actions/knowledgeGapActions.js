import * as types from "../constants/actionTypes";
import axios from "axios";
import moment from "moment";
import Config from "../config/Config";
import { message } from "antd";
import _ from "underscore";

//changes added
let conf = new Config();

export const fetchKnowledgeGap = accountPlanId => dispatch => {
  let params = {
    method: conf.fetchKnowledgeGap.method,
    url: `${conf.fetchKnowledgeGap.url}/${accountPlanId}/cp/gaps`
  };
  const loader = message.loading("Please wait while we Knowledge Gaps...", 0);
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.FETCH_KNOWLEDGE_GAP,
        payload: response.data
      });
      console.log(response.data);
    }
    loader();
  });
};

export const createKnowledgeGap = data => dispatch => {
  let params = {
    method: conf.createKnowledgeGap.method,
    url: `${conf.createKnowledgeGap.url}/${data.accountPlanId}/cp/gaps`,
    data: data
  };
  const loader = message.loading("Creating Knowledge Gap...", 0);

  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.CREATE_KNOWLEDGE_GAP,
        payload: { value: response.data.data.knowledgeGapId }
      });
      console.log(response.data);
      message.success(`Knowledge Gap Updated Successfully`);
    }
    loader();
  });
};

export const changeknowledgeGap = (value, accountPlanId) => dispatch => {
  dispatch({
    type: types.CHANGE_KNOWLEDGE_GAP,
    payload: { value, accountPlanId }
  });
};

import * as types from "../constants/actionTypes";
import axios from "axios";
import Config from "../config/Config";
import { message } from "antd";
import _ from "underscore";
let conf = new Config();

export const fetchApplicationPortfolio = (accountPlanId) => dispatch => {
  const msg = message.loading("Please wait for a moment we are loading portfio", 0);
  axios({
    method: conf.fetchApplicationPortfolio.method,
    url: `${conf.fetchApplicationPortfolio.url}/${accountPlanId}/evolution`
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.GET_APPLICATION_PORTFOLIO_EVOLUTION,
        payload: resp.data.data
      });
    } else {
      message.error("Error in fetching footprint data.");
    }
    msg();
  });
};

export const fetchVMWRelationship = (accountPlanId,cb) => dispatch => {
  axios({
    method: conf.fetchVMWRelationship.method,
    url: `${conf.fetchVMWRelationship.url}/${accountPlanId}/evolution/vr`
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.GET_VMW_RELATIONSHIP,
        payload: resp.data.data
      });
      fetchApplicationPortfolio(accountPlanId)(dispatch);
    } else {
      message.error("Error in fetching VMW relationship.");
    }
  });
};

export const submitCustomerResponse = (
  index,
  innerIndex,
  aprId = null,
  customerResponse,
  apqId,
  accountPlanId,
  type = "updated"
) => dispatch => {
  let data,
    flag = false;
  if (aprId === null) {
    data = {
      customerResponse,
      apqId,
      accountPlanId
    };
    flag = true;
  } else {
    data = {
      aprId,
      customerResponse,
      apqId,
      accountPlanId
    };
  }
  axios.post(`${conf.updateApplicationPortfolio.url}/${accountPlanId}/evolution/apr`, data).then(resp => {
    if (resp.status === 200) {
      const payload = { index, innerIndex, aprId: resp.data.data.aprId };
      message.success(`Customer Response ${type} successfully!`);
      if (flag) {
        dispatch({
          type: types.SET_APR_ID,
          payload
        });
      }
    } else {
      message.error(`Error occurred while updating`);
    }
  });
};

export const submitImplication = (
  index,
  innerIndex,
  implicationId = null,
  implication,
  apqId,
  accountPlanId,
  type = "updated"
) => dispatch => {
  let data,
    flag = false;
  if (implicationId === null) {
    data = {
      implication,
      apqId,
      accountPlanId
    };
    flag = true;
  } else {
    data = {
      implicationId,
      implication,
      apqId,
      accountPlanId
    };
  }

  axios.post(`${conf.updateApplicationPortfolio.url}/${accountPlanId}/evolution/implication`, data).then(resp => {
    if (resp.status === 200) {
      const payload = { index, innerIndex, implicationId: resp.data.data.implicationId };
      message.success(`Implication ${type} successfully!`);
      if (flag) {
        dispatch({
          type: types.SET_IMPLICATION_ID,
          payload
        });
      }
    } else {
      message.error(`Error occurred while updating`);
    }
  });
};

export const submitOwner = (
  index,
  innerIndex,
  aboId = null,
  ownerName,
  jobRole,
  apqId,
  vmwRelationship,
  accountPlanId,
  type = "updated"
) => dispatch => {
  let data,
    flag = false;
  if (aboId === null) {
    data = {
      ownerName,
      jobRole,
      apqId,
      vmwRelationship,
      accountPlanId
    };
    flag = true;
  } else {
    data = {
      aboId,
      ownerName,
      jobRole,
      apqId,
      vmwRelationship,
      accountPlanId
    };
  }
  axios.post(`${conf.updateApplicationPortfolio.url}/${accountPlanId}/evolution/abo`, data).then(resp => {
    if (resp.status === 200) {
      const payload = { index, innerIndex, aboId: resp.data.data.aboId };
      message.success(`Owner details ${type} successfully!`);
      if (flag) {
        dispatch({
          type: types.SET_ABO_ID,
          payload
        });
      }
    } else {
      message.error(`Error occurred while updating`);
    }
  });
};

export const createCustomerResponse = (index, accountPlanId) => dispatch => {
  const payload = { index, accountPlanId };
  dispatch({
    type: types.CREATE_CUSTOMER_RESPONSE,
    payload
  });
};

export const updateCustomerResponse = (index, innerIndex, value) => dispatch => {
  const payload = { index, innerIndex, value };
  dispatch({
    type: types.UPDATE_CUSTOMER_RESPONSE,
    payload
  });
};

export const setAprId = (index, innerIndex, value) => dispatch => {
  console.log("index is", index);
  const payload = { index, innerIndex, value };
  dispatch({
    type: types.SET_APR_ID,
    payload
  });
};

export const setImplicationId = (index, innerIndex, value) => dispatch => {
  const payload = { index, innerIndex, value };
  dispatch({
    type: types.SET_IMPLICATION_ID,
    payload
  });
};

export const createBusinessOwner = (index, accountPlanId) => dispatch => {
  const payload = { index, accountPlanId };
  dispatch({
    type: types.CREATE_BUSINESS_OWNER,
    payload
  });
};

export const updateBusinessOwnerName = (index, innerIndex, value) => dispatch => {
  const payload = { index, innerIndex, value };
  dispatch({
    type: types.UPDATE_BUSINESS_OWNER_NAME,
    payload
  });
};

export const updateBusinessOwnerRole = (index, innerIndex, value) => dispatch => {
  const payload = { index, innerIndex, value };
  dispatch({
    type: types.UPDATE_BUSINESS_OWNER_ROLE,
    payload
  });
};

export const deleteBusinessOwner = (
  index,
  innerIndex,
  aboId = null,
  ownerName,
  jobRole,
  apqId,
  accountPlanId
) => dispatch => {
  let data;
  if (aboId === null) {
    dispatch({
      type: types.DELETE_BUSINESS_OWNER,
      payload: { index, innerIndex }
    });
  } else {
    data = {
      aboId,
      ownerName,
      jobRole,
      apqId,
      accountPlanId
    };

    let params = {
      method: conf.deleteApplicationPortfolio.method,
      url: `${conf.deleteApplicationPortfolio.url}/${accountPlanId}/evolution/abo`,
      data: data
    };

    axios(params)
      .then(resp => {
        if (resp.status === 200) {
          message.success(`Owner details deleted successfully!`);
          dispatch({
            type: types.DELETE_BUSINESS_OWNER,
            payload: { index, innerIndex }
          });
        } else {
          //Remove this when api works
          dispatch({
            type: types.DELETE_BUSINESS_OWNER,
            payload: { index, innerIndex }
          });
          //message.error(`Error occurred while deleting`);
        }
      })
      .catch(() => {
        dispatch({
          type: types.DELETE_BUSINESS_OWNER,
          payload: { index, innerIndex }
        });
      });
  }
};

export const deleteCustomerResponse = (
  index,
  innerIndex,
  aprId = null,
  customerResponse,
  apqId,
  accountPlanId
) => dispatch => {
  let data;
  if (aprId === null) {
    dispatch({
      type: types.DELETE_CUSTOMER_RESPONSE,
      payload: { index, innerIndex }
    });
  } else {
    data = {
      aprId,
      customerResponse,
      apqId,
      accountPlanId
    };

    let params = {
      method: conf.deleteApplicationPortfolio.method,
      url: `${conf.deleteApplicationPortfolio.url}/${accountPlanId}/evolution/apr`,
      data: data
    };

    axios(params)
      .then(resp => {
        if (resp.status === 200) {
          message.success(`Customer reponse deleted successfully!`);
          dispatch({
            type: types.DELETE_CUSTOMER_RESPONSE,
            payload: { index, innerIndex }
          });
        } else {
          //Remove this when api works
          dispatch({
            type: types.DELETE_CUSTOMER_RESPONSE,
            payload: { index, innerIndex }
          });
          message.error(`Error occurred while deleting`);
        }
      })
      .catch(() => {
        dispatch({
          type: types.DELETE_CUSTOMER_RESPONSE,
          payload: { index, innerIndex }
        });
      });
  }
};

export const deleteImplication = (
  index,
  innerIndex,
  implicationId = null,
  implication,
  apqId,
  accountPlanId
) => dispatch => {
  let data;
  if (implicationId === null) {
    dispatch({
      type: types.DELETE_IMPLICATION,
      payload: { index, innerIndex }
    });
  } else {
    data = {
      implicationId,
      implication,
      apqId,
      accountPlanId
    };

    let params = {
      method: conf.deleteApplicationPortfolio.method,
      url: `${conf.deleteApplicationPortfolio.url}/${accountPlanId}/evolution/implication`,
      data: data
    };

    axios(params)
      .then(resp => {
        if (resp.status === 200) {
          message.success(`Implication deleted successfully!`);
          dispatch({
            type: types.DELETE_IMPLICATION,
            payload: { index, innerIndex }
          });
        } else {
          //Remove this when api works
          dispatch({
            type: types.DELETE_IMPLICATION,
            payload: { index, innerIndex }
          });
          message.error(`Error occurred while deleting`);
        }
      })
      .catch(() => {
        dispatch({
          type: types.DELETE_IMPLICATION,
          payload: { index, innerIndex }
        });
      });
  }
};

export const createImplications = (index, accountPlanId) => dispatch => {
  const payload = { index, accountPlanId };
  dispatch({
    type: types.CREATE_IMPLICATIONS,
    payload
  });
};

export const updateImplication = (index, innerIndex, value) => dispatch => {
  const payload = { index, innerIndex, value };
  dispatch({
    type: types.UPDATE_IMPLICATIONS,
    payload
  });
};

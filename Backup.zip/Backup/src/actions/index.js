import * as userActions from "./userActions";
import * as overviewActions from "./overviewActions";
import * as itLandscapeActions from "./itLandscapeActions";
import * as keyMetricsActions from "./keyMetricsActions";
import * as footPrintAndWhiteSpaceActions from "./footprintWhiteSpaceActions";
import * as strategyActions from "./strategyActions";
import * as BusinessITAlignmentActions from "./BusinessITAlignmentActions";
import * as landingActions from "./landingActions";
import * as vmwareContractActions from "./vmwareContractActions";
import * as portfolioActions from "./portfolioActions";
import * as customerSuccessActions from "./customerSuccessActions";
import * as forwardActions from "./forwardActions";
import * as keydecisionActions from "./keydecisionActions";
import * as knowledgeGapActions from "./knowledgeGapActions";
import * as partnerActions from './partnerActions';

import * as KeyCompetitorAnalysisActions from "./KeyCompetitorAnalysisActions";
import * as customerStrategyActions from "./customerStrategyActions";
export const ActionCreators = Object.assign(
  {},
  userActions,
  overviewActions,
  itLandscapeActions,
  keyMetricsActions,
  footPrintAndWhiteSpaceActions,
  strategyActions,
  BusinessITAlignmentActions,
  landingActions,
  vmwareContractActions,
  portfolioActions,
  customerSuccessActions,
  forwardActions,
  keydecisionActions,
  knowledgeGapActions,
  partnerActions,
  KeyCompetitorAnalysisActions,
  customerStrategyActions
);

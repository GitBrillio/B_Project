import * as types from "../constants/actionTypes";
import axios from "axios";
import Config from "../config/Config";
import _ from "underscore";
import { message } from "antd";
let conf = new Config();
import { cloneDeep } from "lodash";
import { CheckedboxLabelData, findMaxRange } from "../Services/CheckboxData";

export const changeKeyTheme = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_KEY_THEME_FIELD,
    payload: { value, index }
  });
  // const re = /^[0-9\b]+$/;
  //   if (value === '' || re.test(value)) {
  //     dispatch({
  //         type: types.CHANGE_KEY_THEME_FIELD,
  //         payload: {value,index}
  //     })
  //   }
};
export const changeTargetValue = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_TARGET_VALUE_FIELD,
    payload: { value, index }
  });
};
export const changeGrowthStrategy = (value, index, growth_index) => dispatch => {
  dispatch({
    type: types.CHANGE_GROWTH_STRATEGY_FIELD,
    payload: { value, index, growth_index }
  });
};
export const changeGoalValue = (value, index) => dispatch => {
  dispatch({
    type: types.CHANGE_GOAL_VALUE,
    payload: { value, index }
  });
};

export const getThreeYearAmbition = accountPlanId => dispatch => {
  axios({
    url: conf.getThreeYearAmbition.url + "/" + accountPlanId + "/ambition",
    method: conf.getThreeYearAmbition.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.FETCH_THREE_YEAR_AMBITION,
        payload: resp.data.data.ambitionPlans
      });
    }
  });
};

export const getAmbitionsGoalPlan = accountPlanId => dispatch => {
  axios({
    url: conf.getAmbitionsGoalPlan.url + "/" + accountPlanId + "/ambition/goals",
    method: conf.getAmbitionsGoalPlan.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.FETCH_AMBITION_GOAL_PLAN,
        payload: resp.data.data
      });
    }
  });
};
export const submitGoalPlan = (goalPlan, accountPlanId, accountTeamGoalId, type = "updated") => dispatch => {
  let data,
    flag = false;
  if (accountTeamGoalId === null) {
    data = {
      accountTeamGoalId: null,
      teamGoal: goalPlan,
      accountPlanId: accountPlanId
    };
    flag = true;
  } else {
    data = {
      accountTeamGoalId: accountTeamGoalId,
      teamGoal: goalPlan,
      accountPlanId: accountPlanId
    };
  }
  axios.post(conf.getAmbitionsGoalPlan.url + "/" + accountPlanId + "/ambition/goals", data).then(resp => {
    if (resp.status === 200) {
      message.success(`Account Team Goal ${type} successfully!`);
      if (flag) {
        dispatch({
          type: types.SET_TEAM_GOAL_ID,
          payload: resp.data.data.accountTeamGoalId
        });
      }
    } else {
      message.error(`Error occures while updating`);
    }
  });
};

export const createAddmore = index => dispatch => {
  dispatch({
    type: types.ADD_MORE,
    payload: index
  });
};

export const addMoreGoal = () => dispatch => {
  dispatch({
    type: types.ADD_MORE_GOAL
  });
};
export const addGoalValue = () => dispatch => {
  dispatch({
    type: types.ADD_GOAL_VALUE
  });
};
export const addTeamGoalData = () => dispatch => {
  dispatch({
    type: types.ADD_TEAM_GOAL_DATA
    // payload : accountPlanId
  });
};

export const deleteElement = (index, growth_index) => dispatch => {
  dispatch({
    type: types.DELETE_ELEMENT,
    payload: { index, growth_index }
  });
};

export const deleteGoalElement = (index, goalPlan, accountPlanId, accountTeamGoalId) => dispatch => {
  dispatch({
    type: types.DELETE_GOAL_ELEMENT,
    payload: index
  });
  goalPlan.splice(index, 1);
  submitGoalPlan(goalPlan, accountPlanId, accountTeamGoalId, "deleted")(dispatch);
};

export const submitAmbitionsGoalPlan = (ambition, accountPlanId) => dispatch => {
  let data;
  if (ambition.ambitionPlan.ambitionPlanId) {
    data = {
      targetValue: ambition.ambitionPlan.targetValue,
      currencyId: ambition.ambitionPlan.currencyId,
      keyTheme: ambition.ambitionPlan.keyTheme,
      ambitionPlanId: ambition.ambitionPlan.ambitionPlanId,
      growthStrategy: ambition.ambitionPlan.growthStrategy,
      accountPlanId: accountPlanId,
      fiscalYear: ambition.fiscalYear
    };
  } else {
    data = {
      targetValue: ambition.ambitionPlan.targetValue,
      currencyId: null,
      keyTheme: ambition.ambitionPlan.keyTheme,
      ambitionPlanId: null,
      growthStrategy: ambition.ambitionPlan.growthStrategy,
      accountPlanId: accountPlanId,
      fiscalYear: ambition.fiscalYear
    };
  }

  axios.post(conf.getAmbitionsGoalPlan.url + "/" + accountPlanId + "/ambition", data).then(resp => {
    if (resp.status === 200) {
      message.success("Ambition Goal Data submitted successfully!");
    } else {
      message.error(`Error occures while Submit`);
    }
  });
};
// vmware contracts
export const resetAmbition = (ambition, index) => dispatch => {
  dispatch({
    type: types.RESET_AMBITION,
    payload: {
      index,
      ambition
    }
  });
};
// key opportunities
export const storeDropdownValues = (title, value) => dispatch => {
  dispatch({
    type: types.STORE_DROPDOWN_VAL,
    payload: { title, value }
  });
};
export const onChangeCheckbox = (e, i, val, title) => dispatch => {
  let checkedBox = cloneDeep(val);
  checkedBox[i].status = e.target.checked;
  var labelData = CheckedboxLabelData(checkedBox);
  dispatch({
    type: types.CHANGE_CHECKBOX,
    payload: { title, checkedBox, labelData }
  });
};
export const searchOpportunities = e => dispatch => {
  let input = e.target.value;
  dispatch({
    type: types.SEARCH_OPPORTUNITY,
    payload: { input }
  });
};
export const onChangeSelectEVP = val => dispatch => {
  dispatch({
    type: types.CHANGE_EVP,
    payload: { val }
  });
};

export const getQuarters = () => dispatch => {
  axios({
    url: conf.getQuarters.url,
    method: conf.getQuarters.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.FETCH_QUARTERS,
        payload: resp.data.data
      });
    }
  });
};

export const getStage = () => dispatch => {
  axios({
    url: conf.getStage.url + "/lookup?reference=Stage",
    method: conf.getStage.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.FETCH_STAGE,
        payload: resp.data.data
      });
    }
  });
};

export const getProducts = () => dispatch => {
  axios({
    url: conf.getProducts.url + "/lookup?reference=Product",
    method: conf.getProducts.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.FETCH_PRODUCTS,
        payload: resp.data.data
      });
    }
  });
};
export const getGraphOpportunities = accountId => dispatch => {
  const hide = message.loading("Loading your graph", 0);
  //accountId = "0018000000hoMSvAAM";
  axios({
    url: conf.getGraphOpportunities.url + accountId,
    method: conf.getGraphOpportunities.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.FETCH_GRAPH_OPPORTUNITIES,
        payload: resp.data.data.details
      });
    }
    hide();
  });
};
export const getOpportunitiesDetails = accountId => dispatch => {
  const hide = message.loading("Please wait while we fetch the opportunities", 0);
  //accountId = "0018000000hoMSvAAM";
  axios({
    url: conf.getOpportunitiesDetails.url + accountId,
    //url: conf.getOpportunitiesDetails.url ,
    method: conf.getOpportunitiesDetails.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.FETCH_OPPORTUNITIES_DETAILS,
        payload: resp.data.data
        //payload: resp.data
      });
      let range = findMaxRange(resp.data.data);
      dispatch({
        type: types.SET_MAX_RANGE,
        payload: range
        //payload: resp.data
      });
    }
    hide();
  });
};

//Roadmap
export const addMoreDesc = () => dispatch => {
  let value = {
    description: "",
    endDate:null,
    startDate:null,
    workstreamId: null
  };
  dispatch({
    type: types.ADD_MORE_DESC,
    payload: {value }
  });
};

export const roadmapInputChange = (value) => dispatch => {
  dispatch({
      type: types.ROADMAP_INPUT_CHANGE,
      payload: { 
        value:JSON.parse(value) 
      }
  });
}

export const roadmapDateChange = (dates,index) => (dispatch) => {
  dispatch({
    type: types.ROADMAP_DATE_CHANGE,
    payload: { dates,index }
  })
}

export const getRoadmap = (accountPlanId) => dispatch => {
  //const hide = message.loading("Loading your Roadmap", 0);
  axios({
    url: conf.getRoadmap.url + "/" + accountPlanId + "/roadmap",
    //url: conf.getRoadmap.url,
    method: conf.getRoadmap.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.GET_ROADMAP,
        payload: resp.data.data
      });
    }
    //hide();
  });
};

export const getBIdropdown = (accountPlanId) => dispatch => {
  axios({
    url: conf.getBIdropdownValues.url + "/" + accountPlanId + "/business/initiative",
    //url: conf.getBIdropdownValues.url,
    method: conf.getBIdropdownValues.method
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.GET_BI_DROPDOWN,
        payload: resp.data.data
      });
    }
  });
};

export const createUpdateRoadmap = (data, accountPlanId)  => (dispatch) => {
  axios.post(`${conf.capUrl}/${accountPlanId}/roadmap`, data).then(resp => {
    if (resp.status === 200) {
      message.success("Roadmap created or updated successfully!");
      dispatch({
        type: 'RESET_ROADMAP_WS',
        payload: {
          "businessInitiativeId": null,
          "businessInitiativeName": "",
          "workstreamList": [
              {
                  "workstreamId": null,
                  "description": "",
                  "startDate": null,
                  "endDate": null
              }
          ]
        }
      });
      getRoadmap(accountPlanId)(dispatch);
    } else {
      message.error(`Error occures while Submit`);
    }
  });
};


export const resetRoadmap = () => (dispatch) => {
  dispatch({
    type: types.RESET_ROADMAP_WS,
    payload: {
      "businessInitiativeId": null,
      "businessInitiativeName": "",
      "workstreamList": [
          {
              "workstreamId": null,
              "description": "",
              "startDate": null,
              "endDate": null
          }
      ]
    }
  });
}

export const resetWorkstreamDetails = (workstream, index) => dispatch => {
  dispatch({
    type: types.RESET_WORKSTREAM_DETAILS,
    payload: {
      index,
      workstream
    }
  });
};


export const removeInitiativeRoadmap = (businessInitiativeId,accountPlanId) => (dispatch) => {
  //make the api call
  const msg = message.loading("Please wait while we delete the workstream...",0)
  axios.delete(`${conf.capUrl}/${accountPlanId}/roadmap?businessInitiativeId=${businessInitiativeId}`).then(resp => {
    if (resp.status === 200) {
      message.success("Roadmap deleted successfully!");
      getRoadmap(accountPlanId)(dispatch);
    } else {
      message.error(`Error occures while Submit`);
    }
    msg();
  }).catch(()=>{
    msg()
  })

  
 
}


export const removeRoadmapWorksream = (index) => (dispatch) => {
  // make the api call
  // const msg = message.loading("Please wait while we delete the workstream...",0)
  // axios.delete(`${conf.capUrl}/${accountPlanId}/roadmap?businessInitiativeId=${ws.workstreamId}`).then(resp => {
  //   if (resp.status === 200) {
  //     message.success("Roadmap deleted successfully!");
  //     getRoadmap(accountPlanId)(dispatch);
  //   } else {
  //     message.error(`Error occures while Submit`);
  //   }
  //   msg();
  // }).catch(()=>{
  //   msg()
  // })

  dispatch({
    type: types.DELETE_ROADMAP,
    payload: index
  })
 
}

export const changeDescriptionRWS = (value,index) => (dispatch) => {
  dispatch({
    type:types.CHANGE_ROADMAP_WS_DESC,
    payload: {value,index}
  })
}

export const setRoadmapWS = (ws,index) => (dispatch) => {
  dispatch({
    type: types.SET_WORKSTREAM_DETAILS,
    payload: {ws,index}
  })
}
export const vpPostDataChange = (val, accID) => dispatch => {
  dispatch({
    type: types.VP_POST_DATA_CAHANGE,
    payload: val,
    accountId : accID
  });
};

export const getVpData = (accountId) => dispatch => {
  const hide = message.loading("Loading your eValue Promter data", 0);
  axios({
    url: conf.valuePrompter.url + "/" + accountId + "/sa/vp",
    method: "GET"
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({             
        type: types.SAVE_VP_IMAGE,
        payload: resp.data.data
      });
    }
    hide();
  });
};

export const ValuePrompterActions = (requestData , accountId) => dispatch => {
  const hide = message.loading("Hold on, We are updating eValue Promter data", 0);
  axios({
    url: conf.valuePrompter.url +"/" + accountId + "/sa/vp/create",
    method: conf.valuePrompter.method,
    data: requestData
  }).then(resp => {
    if (resp.status === 200) {
      dispatch({
        type: types.SAVE_VP_IMAGE,
        payload: resp.data.data
      });
      message.success("eValue Promter data updated");
    }
    hide();
  });
};

import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import { message } from 'antd';
import _ from 'underscore';
import {cloneDeep} from 'lodash';

let conf = new Config();

/****************************** CUSTOMER STRATEGY **********************************/

export const fetchCustomerStrategy = (accountPlanId) => (dispatch) => {
    let params = {
        method: 'GET',
        url: `${conf.capUrl}/${accountPlanId}/cp/strategy`
        //url: '/constants/json/customerStrategy.json'
    }
    const msg = message.loading("Loading up customer strategy, please wait...",0);
    axios(params).then(response => {
        msg();
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_CUSTOMER_STRATEGY,
                payload: response.data.data
            });
        }
    });
}

export const fetchKeySolutions = (accountPlanId) => (dispatch) => {
    let params = {
        method: 'GET',
        url: `${conf.capUrl}/${accountPlanId}/cp/strategy/solution`
        //url: '/constants/json/keySolutionDropdown.json'
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_KEY_SOLUTIONS,
                payload: response.data.data
            });
        }
    });
}
export const fetchMaturityLevel = (accountPlanId) => (dispatch) => {
    let params = {
        method: 'GET',
        url: `${conf.capUrl}/${accountPlanId}/cp/strategy/level`
        //url: '/constants/json/maturityLevelDropdown.json'
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_MATURITY_LEVEL,
                payload: response.data.data
            });
        }
    });
}
export const changeModalValues = (key, value) => (dispatch) => {
    dispatch({
        type: types.CHANGE_MODAL_VALUES,
        payload: {
            key, value
        }
    })
}
export const saveCustomerStrategy = (csDetails,accountPlanId,type) => (dispatch) => {

    let mainReducer = cloneDeep(csDetails);
    const msg = message.loading("Please wait while we save Customer Strategy",0);
    mainReducer.accountPlanId = accountPlanId;
    axios({
        method: 'POST',
        url: `${conf.capUrl}/${accountPlanId}/cp/strategy`,
        data: mainReducer
    }).then((resp)=>{
        msg();
        if (resp.status === 200) {
            message.success("Customer Strategy details have been saved successfully!");
            resetCS()(dispatch);
            fetchCustomerStrategy(accountPlanId)(dispatch);
        }
        else{
            if (resp.status === 208) {
                message.warning(resp.data.message);
            }
        }
        
    }).catch((err)=>{
        msg();
        message.error("Error ocured while performing the operation")
    })
}
export const resetCS = () => (dispatch) => {
    dispatch({
        type: types.RESET_CS,
        payload: {
            "customerStrategyId": null,
            "solutionId": "",
            "solutionName": "",
            "otherText": "",
            "maturityLevelId": "",
            "maturityLevelLabel": "",
            "customerStrategy": "",
            "vmwarePriorities": ""
        }
    })
}
export const setCS = (cs) => (dispatch) => {
    dispatch({
        type: types.RESET_CS,
        payload: cs
    })
}
export const deleteCS = (accountPlanId,cs) => (dispatch) => {
    const msg = message.loading("Please wait while we delete customer strategy",0);
    axios({
        method: 'DELETE',
        url: `${conf.capUrl}/${accountPlanId}/cp/strategy?customerStrategyId=${cs.customerStrategyId}`,
    }).then((resp)=>{
        msg();
        message.success("Customer strategy has been deleted successfully!");
        fetchCustomerStrategy(accountPlanId)(dispatch);
    }).catch((err)=>{
        msg();
        message.error("Error ocured while performing the operation")
    })
}

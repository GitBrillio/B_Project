import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import { message } from 'antd';
import _ from 'underscore';
import {cloneDeep} from 'lodash';

let conf = new Config();

/****************************** PARTNERS **********************************/

export const fetchPartnerTypes = (accountPlanId) => (dispatch) => {
    let params = {
        method: 'GET',
        url: `${conf.capUrl}/${accountPlanId}/footprint/partners/type`
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_PARTNER_TYPES,
                payload: response.data.data
            });

        }
    });
}

export const getRadios = (id,accountPlanId) => (dispatch) => {
        fetchTypes('role', id, accountPlanId)(dispatch);
        fetchTypes('attitude', id, accountPlanId)(dispatch);
        fetchTypes('engagement', id, accountPlanId)(dispatch);
}

export const fetchTypes = (type, partnerTypeId, accountPlanId) => (dispatch) => {
    let params = {
        method: 'GET',
        url: `${conf.capUrl}/${accountPlanId}/footprint/partners/${type}?partnerTypeId=${partnerTypeId}`
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_SAE,
                payload: {
                    type: type,
                    data: response.data.data
                }
            });
        }
    });
}

export const fetchPartners = (accountPlanId) => (dispatch) => {
    let params = {
        method: 'GET',
        url: `${conf.capUrl}/${accountPlanId}/footprint/partners`
    }
    const msg = message.loading("Loading up partners, please wait...",0);
    axios(params).then(response => {
        msg();
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_PARTNER,
                payload: response.data.data.footprintPartnerList
            });
        }
    });
}

export const changeKeyPartner = (key, value) => (dispatch) => {
    dispatch({
        type: types.CHANGE_PARTNER_KEY,
        payload: {
            key, value
        }
    })
}


export const changeKeyPeople = (key, index, value) => (dispatch) => {
    dispatch({
        type: types.CHANGE_PARTNER_PEOPLE,
        payload: {
            key, index, value
        }
    })
}

export const addNewKeyPeople = () => (dispatch) => {
    dispatch({
        type: types.ADD_NEW_PARTNER_KEY_PEOPLE,
        payload: {
            keyPeopleId: null,
            keyPeopleRole: "",
            keyPeopleName: ""
        }
    })
}

export const deletePartnerKeyPeople = (index) => dispatch => {
    dispatch({
        type: types.DELETE_PARTNER_KEY_PEOPLE,
        payload: index
    })
}


export const changePartnerNextStep = (index, value) => (dispatch) => {
    dispatch({
        type: types.CHANGE_PARTNER_NEXT_STEP,
        payload: {
            index, value
        }
    })
}

export const addPartnerNextStep = () => (dispatch) => {
    dispatch({
        type: types.ADD_NEW_PARTNER_NEXT_STEP,
        payload: ""
    })
}

export const deletePartnerNextStep = (index) => dispatch => {
    dispatch({
        type: types.DELETE_PARTNER_NEXT_STEP,
        payload: index
    })
}



export const savePartner = (partnerDetails,accountPlanId,type) => (dispatch) => {

    let pd = cloneDeep(partnerDetails);
    const msg = message.loading("Please wait while we save the partner",0);
    pd.accountPlanId = accountPlanId;
    axios({
        method: 'POST',
        url: `${conf.capUrl}/${accountPlanId}/footprint/partners/${type}`,
        data: pd
    }).then((resp)=>{
        msg();
        message.success("Partner details has been saved successfully!");
        resetPartner()(dispatch);
        fetchPartners(accountPlanId)(dispatch);
    }).catch((err)=>{
        message.error("Error ocured while performing the operation")
    })
}

export const deletePartner = (accountPlanId,partner) => (dispatch) => {
    const msg = message.loading("Please wait while we delete the partner",0);
    axios({
        method: 'DELETE',
        url: `${conf.capUrl}/${accountPlanId}/footprint/partners/delete`,
        data: partner
    }).then((resp)=>{
        msg();
        message.success("Partner details has been deleted successfully!");
        fetchPartners(accountPlanId)(dispatch);
    }).catch((err)=>{
        message.error("Error ocured while performing the operation")
    })
}

export const resetPartner = () => (dispatch) => {
    dispatch({
        type: types.RESET_PARTNER,
        payload: {
            "fpId": null,
            "partnerTypeId": "",
            "partnerId": 1,
            "partnerName": "",
            "annualRevenue": "",
            "opportunityAmount": "",
            "focusArea": "",
            "opportunityId": "",
            "roleId": "",
            "attitudeId": "",
            "engagementId": "",
            "nextStep": [
            ],
            "accountPlanId": null,
            "keyPeoples": [
            ]
        }
    })
}

export const setPartner = (partner) => (dispatch) => {
    dispatch({
        type: types.RESET_PARTNER,
        payload: partner
    })
}

export const searchPartners = (accountPlanId,searchVal) => (dispatch) => {
    let params = {
        method: 'GET',
        url: `${conf.capUrl}/${accountPlanId}/footprint/partners/search?pattern=${searchVal}`
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_PARTNER,
                payload: response.data.data.footprintPartnerList
            });
        }
    });
}
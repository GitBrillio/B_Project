import * as types from "../constants/actionTypes";
import axios from "axios";
import Config from "../config/Config";
import { message } from "antd";
import _ from "underscore";
import { cloneDeep } from "lodash";

let conf = new Config();

export const getBusinessGoals = accountPlanId => dispatch => {
  let params = {
    method: conf.getBusinessGoals.method,
    url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals"
  };
  const msg = message.loading("Please wait for a moment we are loading goals", 0);
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.GET_BUSINESS_GOALS,
        payload: response.data.data.businessGoals
      });
    } else {
      message.error("Error in fetching footprint data.");
    }
    msg();
  });
};

export const saveBusinessGoal = (requestBody, methodType, action = "") => dispatch => {
  let params = {
    method: methodType,
    url: conf.saveBusinessGoals.url + "/" + requestBody.accountPlanId + "/business/goals",
    data: requestBody
  };
  const msg = message.loading("Saving Business goal...", 0);
  axios(params).then(response => {
    if (response.status === 200) {
      if (action === "PUSH") {
        dispatch({
          type: types.PUSH_BI_GOAL,
          payload: {
            businessGoal: response.data.data.goal,
            businessGoalId: response.data.data.businessGoalId,
            businessInitiatives: []
          }
        });
        msg();
        message.success("Business goal added successfully!");
      } else if (action === "CHANGE_BI_GOAL_NAME") {
        dispatch({
          type: types.CHANGE_BI_GOAL_NAME,
          payload: {
            index: requestBody.index,
            data: requestBody.goal
          }
        });
        msg();
        message.success("Business goal updated successfully!");
      } else if (action === "DELETE_BUSINESS_GOAL") {
        dispatch({
          type: types.DELETE_BUSINESS_GOAL,
          payload: requestBody.index
        });
        msg();
        message.success("Business goal deleted successfully!");
      }
    } else {
      msg();
      message.error("Error occured while creating the business goal");
    }
  });
};

export const getBusinessInitiatives = (accountPlanId, biInitiativeId) => dispatch => {
  let params = {
    method: conf.getBusinessGoals.method,
    url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/bi?id=" + biInitiativeId
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.GET_BUSINESS_INITIATIVES,
        payload: response.data.data
      });
    } else {
      message.error("Error in fetching Business Initiatives.");
    }
  });
};

export const saveBusinessInitiative = (requestBody, methodType, type = "") => dispatch => {
  let params = {
    method: methodType,
    url: conf.saveBusinessGoals.url + "/" + requestBody.accountPlanId + "/business/goals/bi",
    data: requestBody
  };
  let m = "";
  if (type === "PUSH") {
    m = "Saving business initiative";
  } else if (type == "POP") {
    m = "Deleting business initiative";
  } else {
    m = "Updating business initiative";
  }
  const msg = message.loading(m);
  axios(params).then(response => {
    if (response.status === 200) {
      if (type === "PUSH") {
        dispatch({
          type: types.PUSH_BUSINESS_INITIATIVE,
          payload: {
            index: requestBody.goalIndex,
            data: {
              businessInitiativeGoal: response.data.data.goal,
              businessInitiativeId: response.data.data.businessInitiativeId,
              businessInitiativeName: response.data.data.initiativeName,
              itInitiatives: [],
              wmwareInitiatives: []
            }
          }
        });
        message.success("Business Initiative created successfully!");
      } else if (type === "POP") {
        dispatch({
          type: types.POP_BUSINESS_INITIATIVE,
          payload: {
            ...requestBody
          }
        });
        message.success("Business Initiative deleted successfully!");
      } else {
        dispatch({
          type: types.UPDATE_BUSINESS_INITIATIVE_NAME,
          payload: {
            goalIndex: requestBody.goalIndex,
            biIndex: requestBody.biIndex,
            businessGoalInput: response.data.data.initiativeName,
          }
        });
        message.success("Business Initiative updated successfully!");
      }
    } else {
      message.error("Error in fetching Business Initiative data.");
    }
    msg();
  });
};

export const getItInitiatives = (accountPlanId, itInitiativeId) => dispatch => {
  let params = {
    method: conf.getBusinessGoals.method,
    url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/it?id=" + itInitiativeId
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.GET_IT_INITIATIVES,
        payload: response.data.data
      });
    } else {
      message.error("Error in fetching IT Initiatives.");
    }
  });
};

export const saveItInitiative = (requestBody, methodType, type = "") => dispatch => {
  let params = {
    method: methodType,
    url: conf.saveBusinessGoals.url + "/" + requestBody.accountPlanId + "/business/goals/it",
    data: requestBody
  };
  axios(params).then(response => {
    if (response.status === 200) {
      if (type === "PUSH_IT_INITIATIVE") {
        message.success("IT Initiative Updated successfully!");
        dispatch({
          type: types.PUSH_IT_INITIATIVE,
          payload: {
            goalIndex: requestBody.goalIndex,
            biIndex: requestBody.biIndex,
            data: {
              itInitiativeId: response.data.data.itInitiativeId,
              itGoal: response.data.data.goal
            }
          }
        });
      } else if (type === "POP_IT_INITIATIVE") {
        dispatch({
          type: types.POP_IT_INITIATIVE,
          payload: {
            goalIndex: requestBody.goalIndex,
            biIndex: requestBody.biIndex,
            itIndex: requestBody.itIndex
          }
        });
        message.success("IT Initiative deleted successfully!");
      } else if (type === "UPDATE_IT_INITIATIVE_NAME") {
        dispatch({
          type: types.UPDATE_IT_INITIATIVE_NAME,
          payload: {
            goalIndex: requestBody.goalIndex,
            biIndex: requestBody.biIndex,
            itIndex: requestBody.itIndex,
            itGoal: response.data.data.goal
          }
        });
      }
    } else {
      message.error("Error in fetching IT Initiative data.");
    }
  });
};

export const getVMwareInitiatives = (accountPlanId, itInitiativeId) => dispatch => {
  let params = {
    method: conf.getBusinessGoals.method,
    url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/it?vm=" + itInitiativeId
  };
  axios(params).then(response => {
    if (response.status === 200) {
      dispatch({
        type: types.GET_VMWARE_INITIATIVES,
        payload: response.data.data
      });
    } else {
      message.error("Error in fetching VMware Initiatives.");
    }
  });
};

export const saveVmInitiative = (requestBody, methodType, type = "") => dispatch => {
  let params = {
    method: methodType,
    url: conf.saveBusinessGoals.url + "/" + requestBody.accountPlanId + "/business/goals/vm",
    data: requestBody
  };
  axios(params).then(response => {
    if (response.status === 200) {
      if (type === "PUSH_VMWARE_INITIATIVE") {
        dispatch({
          type: types.PUSH_VMWARE_INITIATIVE,
          payload: {
            goalIndex: requestBody.goalIndex,
            biIndex: requestBody.biIndex,
            //vmIndex: requestBody.vmIndex,
            data: {
              vmwareInitiativeId: response.data.data.vmwareInitiativeId,
              vmwareGoal: response.data.data.goal
            }
          }
        });
        message.success("VMWare initiative Updated successfully!");
      } else if (type === "POP_VMWARE_INITIATIVE") {
        dispatch({
          type: types.POP_VMWARE_INITIATIVE,
          payload: {
            goalIndex: requestBody.goalIndex,
            biIndex: requestBody.biIndex,
            vmIndex: requestBody.vmIndex
          }
        });
        message.success("VMWare initiative deleted successfully!");
      } else if (type === "UPDATE_VMWARE_INITIATIVE") {
        dispatch({
          type: types.UPDATE_VMWARE_INITIATIVE,
          payload: {
            goalIndex: requestBody.goalIndex,
            biIndex: requestBody.biIndex,
            vmIndex: requestBody.vmIndex,
            data: {
              vmwareInitiativeId: response.data.data.vmwareInitiativeId,
              vmwareGoal: response.data.data.goal
            }
          }
        });
        message.success("VMWare initiative updated successfully!");
      }
    } else {
      message.error("Error while updating.");
    }
  });
};

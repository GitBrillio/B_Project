import { groupBy } from "lodash";

export const graphLegendData = (data, colors) => {
  let graphArray = [];
  data.map((val, key) =>
    graphArray.push({
      label: val.name,
      color: colors[key]
    })
  );
  return graphArray;
};

export const graphData = data => {
  let graphArray = [];
  data.map(val =>
    graphArray.push({
      name: val.platformGroup,
      pv: val.totalPriceUsd
    })
  );
  return graphArray;
};

export const filterData = data => {
  if (data && data.length) {
    let arr = [];
    let graphArray = [];
    data.map(e => {
      if (e.length > 1) {
        e.map(nestedE => arr.push(...nestedE.productDetails));
      } else if (e.length === 1) {
        arr.push(...e[0].productDetails);
      }
    });
    let groupedObj = groupBy(arr, "platformGroup");

    for (let i in groupedObj) {
      groupedObj[i] = groupedObj[i].map(e => e.totalPriceUsd).reduce((a, b) => a + b);
      graphArray.push({
        name: i,
        value: groupedObj[i]
      });
    }
    return graphArray;
  }
};

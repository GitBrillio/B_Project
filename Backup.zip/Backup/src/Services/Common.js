export const KMB = (labelValue) => {

    // Nine Zeroes for Billions
    return  negetive(labelValue) + Math.abs(Number(labelValue)) >= 1.0e+9

    ? negetive(labelValue) + Math.abs(Number(labelValue)) / 1.0e+9 + "B"
    // Six Zeroes for Millions 
    : negetive(labelValue) + Math.abs(Number(labelValue)) >= 1.0e+6

    ? negetive(labelValue) + Math.abs(Number(labelValue)) / 1.0e+6 + "M"
    // Three Zeroes for Thousands
    : negetive(labelValue) + Math.abs(Number(labelValue)) >= 1.0e+3

    ? negetive(labelValue) + Math.abs(Number(labelValue)) / 1.0e+3 + "K"

    : negetive(labelValue) + Math.abs(Number(labelValue));

}

const negetive = (number)=>{
    return number < 0 ? "-": "";
}


export const urlResolver = (url,params=[]) => {
    let count = 1;
    params.forEach(p => {
        url = url.replace("{param"+count+"}",p);
        count = count + 1
    });
    return url;
}
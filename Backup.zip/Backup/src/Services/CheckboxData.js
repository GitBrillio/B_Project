import {filter,map} from 'lodash';

export const CheckboxDataArray = (checkboxArr) => {
    let statusArray = [];
    checkboxArr.map((val,key)=>(
        statusArray.push({
            index :key,
            label :val,
            status :false   
        })
    ))
    return statusArray;
}
export const CheckboxDataArrayContracts = (checkboxArr,existingProducts) => {
    let statusArray = [];
    checkboxArr.map((val,key)=>(
        statusArray.push({
            index :key,
            label :val,
            status :false   
        })
    ));
    if(existingProducts){
        for(let i =0; i< statusArray.length;i++){
            for(let j =0; j< existingProducts.length;j++){
                if(existingProducts[j]===statusArray[i].label){
                    statusArray[i].status = true
                }
            }
        }
    }
    
    return statusArray;
}
export const CheckboxDataObject = (checkboxObj) => {
    let statusArray = [];
    checkboxObj.map((val,key)=>(
        statusArray.push({
            index :key,
            label :val.value,
            status :false   
        })
    ))
    return statusArray;
}
export const ProductsArray = (productObj) => {
    let mapData = map(productObj,"value")
    return(mapData);
}
export const CheckedboxLabelData = (checkboxData) => {
    let filterData = filter(checkboxData,(obj)=>{
        return(obj.status)
    })
    let mapData = map(filterData,"label")
    return(mapData);
}
export const CheckedboxLabelDataString = (checkboxData) => {
    let filterData = filter(checkboxData,(obj)=>{
        return(obj.status)
    })
    let mapData = map(filterData,"label");
    return(mapData.toString());
}
export const CheckedboxLabelDataArray = (checkboxData) => {
    if(checkboxData){
        var array = checkboxData.split(',');
        return(array);
    }
}
export const findMaxRange = (data) => {
    var arr = [];
    Object.keys(data).forEach(element => {
                filter(data[element],(val)=>{
                    arr.push(val.opptyAmount)
                })
    });
    return (Math.max(...arr));
    // console.log (Math.max(...arr));
    // console.log (Math.min(...arr));
}

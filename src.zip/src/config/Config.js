class Config {
  getOauthUrl() {
    this.oauthUrl =
      "https://myvmware-stg.workspaceair.com/SAAS/auth/oauth2/authorize?response_type=code&client_id=" +
      this.oauth.client_id +
      "&redirect_uri=" +
      this.oauth.redirect_uri +
      "&state=" +
      this.oauth.secret +
      "&scope=" +
      this.oauth.scope;
  }

  constructor() {
    let hostName = window.location.hostname;
    let ENV;

    if (hostName === "localhost" || hostName === 'salesweaver-dev.apps.wdc-np.itcna.vmware.com') {
      ENV = "LOCAL";
    }else if (hostName === "salesweaver-qa.apps.wdc-np.itcna.vmware.com") {
      ENV = "QA";
    } else if (hostName === "salesweaver-stg.apps.itcna.vmware.com") {
      ENV = "UAT";
    } else if (hostName === "salesweaver.apps.itcna.vmware.com") {
      ENV = "PROD";
    }

    this.user = {
      userId: "compassDemoUser",
      userName: "John Doe",
      userAvtar: "userimg.jpeg"
    };
    this.no_of_healthComment = 5;
    this.cookieNames = {
      APP_STATE: "APP_STATE"
    };


    switch (ENV) {
      case "LOCAL": {
        this.oauth = {
          client_id: "salesweaver-dev",
          secret: "lEeH0ZOow06ecshrsy59RzoXIjha59eYRRqL1Mz0Xo0AIawa",
          redirect_uri:
            "https://salesweaver-dev.apps.wdc-np.itcna.vmware.com/landing/authenticate/",
          scope: "openid+user+email+profile"
        };
        //Dev URL
        this.gateway = "https://salesweaver-dev.apps.wdc-np.itcna.vmware.com/api";
        this.url = this.gateway + "/compass/v1";
        this.capUrl = this.gateway + "/cap"
        this.looperApiUrl = "https://looperapp-stg.apps.wdc1.itcna.vmware.com/api/looper";
        this.optUrl = "https://salesweaver-dev.apps.wdc-np.itcna.vmware.com/api/salesweaver/v1";


        this.getOauthUrl()

        this.ssoUrl = {
          method: "POST",
          url:
            "https://salesweaver-dev.apps.wdc-np.itcna.vmware.com/workspaceAirToken?"
        };

        break;
      }

      case "QA": {
        this.oauth = {
          client_id: "salesweaver-qa",
          secret: "995ZRgdHHtJxWVCztyHn2LwXc1KwXrFlI9IrgJ501DjVdqPU",
          redirect_uri:
            "https://salesweaver-qa.apps.wdc-np.itcna.vmware.com/landing/authenticate/",
          scope: "openid+user+email+profile"
        };

        
        this.looperApiUrl ="https://looperapp-qa.apps.wdc-np.itcna.vmware.com/api/looper";

        this.optUrl ="https://salesweaver-qa.apps.wdc-np.itcna.vmware.com/api/salesweaver/v1";

        this.compassUrl ="https://salesweaver-qa.apps.wdc-np.itcna.vmware.com/compass/landing/";
        this.looperUrl = "https://salesweaver-qa.apps.wdc-np.itcna.vmware.com/compass/looper/";

        this.gateway = "https://salesweaver-qa.apps.wdc-np.itcna.vmware.com/api";
        this.url = this.gateway + "/compass/v1";
        this.capUrl = this.gateway + "/cap"

        this.getOauthUrl();

        this.ssoUrl = {
          method: "POST",
          url:
            "https://salesweaver-qa.apps.wdc-np.itcna.vmware.com/workspaceAirToken?"
        };

        break;
      }

      case "UAT": {
        this.oauth = {
          client_id: "salesweaver-stg",
          secret: "VltsnnTSNREtHnDUeVeDPhtH1TpSUqcIvSFxBYYwD7pAS0oW",
          redirect_uri:
            "https://salesweaver-stg.apps.itcna.vmware.com/landing/authenticate/",
          scope: "openid+user+email+profile"
        };

        this.url =
          "https://salesweaver-stg.apps.itcna.vmware.com/api/compass/v1";
        this.looperApiUrl =
          "https://salesweaver-stg.apps.itcna.vmware.com/api/looper";

        this.optUrl =
          "https://salesweaver-stg.apps.itcna.vmware.com/api/salesweaver/v1";

        this.compassUrl =
          "https://salesweaver-stg.apps.itcna.vmware.com/compass/landing/";
        this.looperUrl = "https://salesweaver-stg.apps.itcna.vmware.com/looper";

        this.getOauthUrl();

        this.ssoUrl = {
          method: "POST",
          url:
            "https://salesweaver-stg.apps.itcna.vmware.com/workspaceAirToken?"
        };

        break;
      }

      case "PROD": {
        this.oauth = {
          client_id: "salesweaver-prod",
          secret: "hsi8oK8U1EPy6PsPBgB7e47HSSCcu0uL0sFjZ3uhrbwhkkSi",
          redirect_uri:
            "https://salesweaver.apps.itcna.vmware.com/landing/authenticate/",
          scope: "openid+user+email+profile"
        };

        this.url = "https://salesweaver.apps.itcna.vmware.com/api/compass/v1";
        this.looperApiUrl =
          "https://salesweaver.apps.itcna.vmware.com/api/looper";

        this.optUrl =
          "https://salesweaver.apps.itcna.vmware.com/api/salesweaver/v1";

        this.compassUrl =
          "https://salesweaver.apps.itcna.vmware.com/compass/landing/";
        this.looperUrl = "https://salesweaver.apps.itcna.vmware.com/looper";

        this.oauthUrl =
          "https://myvmware.workspaceair.com/SAAS/auth/oauth2/authorize?response_type=code&client_id=" +
          this.oauth.client_id +
          "&redirect_uri=" +
          this.oauth.redirect_uri +
          "&state=" +
          this.oauth.secret +
          "&scope=" +
          this.oauth.scope;

        this.ssoUrl = {
          method: "POST",
          url: "https://salesweaver.apps.itcna.vmware.com/workspaceAirToken?"
        };

        break;
      }

      default:
        //JSON Setup
        break;
    }



    this.looperMetrics = {
      method: "GET",
      url:
        this.looperApiUrl + "/feedback/metrics?groupNo=101&source=web&userId="
    };

    this.getUser = {
      method: "GET",
      url: "https://vmwaresearch-prod.vmware.com/orgchart/orgchart.php?guid="
    };

    this.fetchGoals = {
      method: 'GET',
      url: this.capUrl + "/goal?accountPlanId="
    };
    
    this.getKeyMetrics = {
      method: 'GET',
      //url: '/constants/json/keyMetrics.json'
      url: this.capUrl 
      //url: this.gateway + "/cap/49226d08-fe02-11e8-86e2-00505692ad81/keymetrics"
    }

    this.getFootPrint = {
      method: 'GET',
      url: this.capUrl
    }

    this.getBusinessGoals = {
      method: 'GET',
      url: this.capUrl 
    }

    this.saveBusinessGoals = {
      method: 'POST',
      url: this.capUrl 
    }

    this.updateGoal = {
      method: 'POST',
      url: this.capUrl + '/goal'
    };

    this.deleteGoal = {
      method: 'DELETE',
      url: this.capUrl + '/goal'
    };

    this.fetchIssues = {
      method: 'GET',
      url: this.capUrl + "/issue?accountPlanId="
    };

    this.updateIssue = {
      method: 'POST',
      url: this.capUrl + '/issue'
    };

    this.deleteIssue = {
      method: 'DELETE',
      url: this.capUrl + '/issue'
    }

    this.fetchLookupData = {
      method: 'GET',
      url: this.capUrl + "/lookup?reference="
    }

    this.fetchKeyDetails = {
      method: 'GET',
      url: this.capUrl + "/keydetails?accountPlanId="
    }

    this.updateKeyDetails = {
      method: 'POST',
      url: this.capUrl + "/keydetails"
    }

    this.fetchVisionStrategy = {
      method: 'GET',
      url: this.capUrl + "/vision/strategy?accountPlanId="
    }

    this.updateVisionStrategy = {
      method: 'POST',
      url: this.capUrl + '/vision/strategy'
    }

    this.fetchKeyFinencials = {
      method: 'GET',
      url: this.capUrl + '/keyfinancials?accountPlanId='
    }

    this.updateKeyFinencialsAPI = {
      method: 'POST',
      url: this.capUrl + '/keyfinancials'
    }

    this.fetchBusinessPorfolio = {
      method: 'GET',
      url: this.capUrl + "/{param1}/keyfinancials/portfolio",
    }

    this.updatePortfolio = {
      method: 'POST',
      url: this.capUrl + "/keyfinancials/businessportfolio"
    }

    this.fetchSegmentGrowth = {
      method: 'GET',
      url: this.capUrl + "/keyfinancials/segmentgrowth?accountPlanId="
    }

    

    this.getSystems = {
      method: 'GET',
      url: this.capUrl 
    }

    

    this.getThreeYearAmbition = {
      method: 'GET',
      url: this.capUrl 
    }

    this.getAmbitionsGoalPlan = {
      method : 'GET',
      url: this.capUrl
    }

    // key opportunities 
    this.getQuarters = {
      method: 'GET',
      url: this.capUrl + "/quarters"
    }
    this.getStage = {
      method: 'GET',
      url: this.capUrl 
    }
    this.getProducts = {
      method: 'GET',
      url: this.capUrl 
    }
    this.getGraphOpportunities = {
      method: 'GET',
      url: this.capUrl + "/product/details?accountId="
    }
    this.getOpportunitiesDetails = {
      method: 'GET',
      //url: '/constants/json/keyopportunities.json'
      url: this.capUrl + "/opportunity/details?accountId="
    }

    this.getAccess = {
      method: "GET",
      url: this.optUrl + "/fname/access/do/read?email="
    };
    this.compassMetrics = {
      method: "GET",
      url: this.url + "/tile/"
    };
  }
}

export default Config;

import Config from './Config';
import Cookies from 'universal-cookie';
import moment from 'moment';
const cookies = new Cookies();

class Oauth {
    constructor(){
        this.config = new Config();
    }
    authenticate() {
        let session = cookies.get('session_status');
        var sessionObj = cookies.get('session');
        if (session === undefined || session === 'logged_out' || session === 'expired') {
            cookies.set('session_status', 'in_sso', { path: '/' });
            window.location.href = this.config.oauthUrl;
        }
        try{

          let currentTime = moment(new Date());
          var sessionExpires = moment(sessionObj.expires_in);
          if(!currentTime.isBefore(sessionExpires)){
            cookies.remove('session');
            cookies.set('session_status', 'in_sso', { path: '/' });
            window.location.href = this.config.oauthUrl;
          }else{
            //
          }
        }catch(e){
          //console.log(e)
        }
    }
}

export default Oauth;

import React, {Component} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {ActionCreators} from '../actions/';

export default function MainContainer(ComposedComponent) {
  class MainContainer extends Component {
    constructor(props) {
      super(props);
      //My first visit to the app
    }

    render() {
      return (<ComposedComponent {...this.props}/>);
    }
  }

  function mapStateToProps(state) {
    return {
      userReducer: state.user,
      overviewReducer: state.overview,
      footprintReducer: state.footprint,
      keyMetricsReducer: state.keyMetrics,
      strategyReducer: state.strategy
    };
  }

  function mapDispatchToProps(dispatch) {
    return {
      actions: bindActionCreators(ActionCreators, dispatch)
    };
  }
  return connect(mapStateToProps, mapDispatchToProps)(MainContainer);
}


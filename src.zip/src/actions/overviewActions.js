import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import {message} from 'antd';
import _ from 'underscore';
import {urlResolver} from '../Services/Common';
let conf = new Config();

/****************************** GOALS **********************************/

export const fetchGoals = (accountPlanId) => (dispatch) => {
    let params = {
        method: conf.fetchGoals.method,
        url: conf.fetchGoals.url + accountPlanId
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_GOALS,
                payload: response.data.data
            });
        }
    });
}
// Update goal to the reducer
export const updateGoal = (newGoal) => (dispatch) => {
    dispatch({
        type: types.FETCH_GOALS,
        payload: newGoal
    });
}

// update goal to the api
export const updateGoalAPI = (goals) => (dispatch) => {
    let params = {
        method: conf.updateGoal.method,
        url: conf.updateGoal.url,
        data: goals
    }
    axios(params).then(response => {
        updateGoal(response.data.data)(dispatch);
        if (response.status === 200) {
            message.success("Goal updated successfully!");
        }
    });
}

// add a new Goal

export const pushGoal = (accountPlanId) => (dispatch) => {
    dispatch({
        type: types.PUSH_NEW_GOAL,
        payload: accountPlanId
    });
}

// delete goal

export const deleteGoal = (goal,callback) => {
    let params = {
        method: conf.deleteGoal.method,
        url: conf.deleteGoal.url,
        data: goal
    }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("Goal deleted successfully!");
            callback()
        }else{
            message.error('Error occures while deleteing the goal')
        }
    })
}

/****************************** ISSUES **********************************/

export const fetchIssues = (accountPlanId) => (dispatch) => {
    let params = {
        method: conf.fetchIssues.method,
        url: conf.fetchIssues.url + accountPlanId
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_ISSUES,
                payload: response.data.data
            });
        }
    });
}

// Update goal to the reducer
export const updateIssue = (newIssues) => (dispatch) => {
    dispatch({
        type: types.FETCH_ISSUES,
        payload: newIssues
    });
}

// update issue to the api
export const updateIssueAPI = (issues) => (dispatch) => {
    let params = {
        method: conf.updateIssue.method,
        url: conf.updateIssue.url,
        data: issues
    }
    axios(params).then(response => {
        if (response.status === 200) {
            updateIssue(response.data.data)(dispatch);
            message.success("Issue updated successfully!");
        }
    })
}

// add a new Issue

export const pushIssue = (accountPlanId) => (dispatch) => {
    dispatch({
        type: types.PUSH_NEW_ISSUE,
        payload: accountPlanId
    });
}

// delete issue

export const deleteIssue = (issue,callback) => {
    let params = {
        method: conf.deleteIssue.method,
        url: conf.deleteIssue.url,
        data: issue
    }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("Issue deleted successfully!");
            callback()
        }else{
            message.error('Error occures while deleteing the issue')
        }
    })
}


/****************************** LOOKUP API **********************************/

export const fetchLookupData = (referenceArr,accountPlanId=null,callback=null) => (dispatch) => {


    for(let i = 0 ; i < referenceArr.length; i++){
        let reference = referenceArr[i];

        axios({
            method: conf.fetchLookupData.method,
            url: conf.fetchLookupData.url + reference
        }).then((resp)=>{
            if(resp.status === 200){
                dispatch({
                    type: types.FETCH_LOOKUP_DATA,
                    payload:{
                        reference: reference,
                        data: resp.data.data
                    } 
                })
                if(typeof callback === 'function' && i === referenceArr.length - 1){
                    callback(accountPlanId);
                }
            }else{
                message.error(`Error occures while fetching {reference}`)
            }
        })
    }
    
}


/****************************** KEY Details **********************************/

export const fetchKeyDetails = (accountPlanId) => (dispatch) => {
    axios({
        method: conf.fetchKeyDetails.method,
        url: conf.fetchKeyDetails.url + accountPlanId
    }).then((resp)=>{
        if(resp.status === 200){
            // check if the api is returning the data
            if(typeof resp.data.data === 'undefined'){
                dispatch({
                    type: types.FETCH_KEY_DETAILS,
                    payload:{
                        accountPlanId: accountPlanId,
                        industryId: null,
                        employeeRangeId: null,
                        netSales: "",
                        overseasSales: "",
                        operationalIncome: "",
                        currencyId: 1
                    }
                })
            } else {
                // return the normal data
                dispatch({
                    type: types.FETCH_KEY_DETAILS,
                    payload:resp.data.data
                })
            }

            
        }else{
            message.error(`Error occures while Key details`)
        }
    })
}

export const changeOverviewValue = (topKey,key,value) => (dispatch) =>{
    dispatch({
        type: types.CHANGE_OVERVIEW_KEY,
        payload:{
            topKey,key,value
        }
    })
}


export const updateKeyDetails = (keyDetails)  => {
    axios({
        method: conf.updateKeyDetails.method,
        url: conf.updateKeyDetails.url,
        data: keyDetails
    }).then((resp)=>{
        if(resp.status === 200){
            message.success('Key details updated successfully!');
        }else{
            message.error(`Error occures while Key details`);
        }
    })
}

/****************************** Vison & Stratagy **********************************/

export const fetchVisionStrategy = (accountPlanId) => (dispatch) => {
    axios({
        method: conf.fetchVisionStrategy.method,
        url: conf.fetchVisionStrategy.url + accountPlanId
    }).then((resp)=>{
        if(resp.status === 200){
            // check if the api is returning the data
            if(typeof resp.data.data === 'undefined'){
                dispatch({
                    type: types.FETCH_VISION_STRATEGY,
                    payload:{
                        accountPlanId: accountPlanId,
                        vision: "",
                        corporateStrategy: "",
                        highlightEvent: "",
                    }
                })
            } else {
                // return the normal data
                dispatch({
                    type: types.FETCH_VISION_STRATEGY,
                    payload:resp.data.data
                })
            }

            
        }else{
            message.error(`Error occures while Key details`)
        }
    })
}


export const updateVisionStrategy = (visionStrategy)  => (dispatch) =>  {
    axios({
        method: conf.updateVisionStrategy.method,
        url: conf.updateVisionStrategy.url,
        data: visionStrategy
    }).then((resp)=>{
        if(resp.status === 200){
            dispatch({
                type: types.FETCH_VISION_STRATEGY,
                payload:resp.data.data
            })
            message.success('Vision & Strategy updated successfully!');
        }else{
            message.error(`Error occures while Vision & Strategy`);
        }
    })
}

/****************************** Key Finencials **********************************/

export const fetchKeyFinencials = (accountPlanId) => (dispatch) =>{
    axios({
        method: conf.fetchKeyFinencials.method,
        url: conf.fetchKeyFinencials.url + accountPlanId   
    }).then((resp)=>{

        let i = 1;
        _.each(resp.data.data,(obj)=>{
            obj.id = i;
            i = i + 1
        });
        dispatch({
            type: types.FETCH_KEY_FINENCIALS,
            payload: resp.data.data
        })
    })
}

export const updateKeyFinenceField = (id,value) => (dispatch) => {
    dispatch({
        type: types.UPDATE_FINENECE_FIELD,
        payload: {
            id,value
        }
    })
}

export const updateKeyFinencialsAPI = (obj) => {
    axios({
        method: conf.updateKeyFinencialsAPI.method,
        url: conf.updateKeyFinencialsAPI.url,
        data: [obj]
    }).then((resp)=>{
        if(resp.status === 200){
            message.success('Key Financials updated successfully!');
        }
    })
}

/****************************** Fetch Business Portfolio **********************************/

export const fetchBusinessPorfolio = (accountPlanId) => (dispatch) =>{
    let params = {
        method: conf.fetchBusinessPorfolio.method,
        url: urlResolver(conf.fetchBusinessPorfolio.url,[accountPlanId])
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.FETCH_BUSINESS_PORTFOLIO,
                payload: response.data.data.items
            });
        }
    });
}

export const changePortfolioLabel = (index,label) => dispatch =>{
    dispatch({
        type: types.CHANGE_PORTFOLIO_LABEL,
        payload:{
            index: index,
            data: label
        }
    })
}


export const changePortfolioValue = (index,value) => dispatch =>{
    dispatch({
        type: types.CHANGE_PORTFOLIO_VALUE,
        payload:{
            index: index,
            data: value
        }
    })
}

export const updatePortfolio = (obj,index) => (dispatch) => {
    axios({
        method: conf.updatePortfolio.method,
        url: conf.capUrl +"/"+ obj.accountPlanId + "/keyfinancials/portfolio",
        data: {
            portfolio: [obj.portfolio]
        }
    }).then((resp)=>{
        if(resp.status === 200){
            dispatch({
                type: types.UPDATE_PORTFOLIO_OBJ,
                payload: {
                    index: index,
                    label: obj.portfolio.portfolioLabel
                }
            });
            //fetchSegmentGrowth(obj.accountPlanId)(dispatch);
            message.success('Business portfolio updated successfully!');
        }else{
            message.error(`Error occures while Vision & Strategy`);
        }
    })
}

export const pushPortfolio = (accountPlanId,fiscalYear=2017) => (dispatch) => {
    let time = new Date();
    let obj = {
        accountPlanId: accountPlanId,
        fiscalYear: fiscalYear,
        portfolioLabel: "Portfolio " + time.getHours() + "-"+ time.getMinutes() + "-"+time.getSeconds(),
        portfolioValue: null
    };
    
    axios({
        method: conf.updatePortfolio.method,
        url: conf.capUrl + "/"+ accountPlanId + "/keyfinancials/portfolio",
        data: {portfolio:[obj]}
    }).then((resp)=>{
        if(resp.status === 200){
            // dispatch({
            //     type: types.PUSH_PORTFOLIO,
            //     payload:resp.data.data[0]
            // });
            fetchBusinessPorfolio(accountPlanId)(dispatch);

            message.success('Business portfolio added successfully');
        }else{
            message.error(`Error occures while Vision & Strategy`);
        }
    })
}

export const deletePortfolio = (obj,index) => (dispatch) => {
    axios({
        method: 'DELETE',
        url: conf.capUrl +"/"+ obj.accountPlanId + "/keyfinancials/portfolio",
        data: obj.portfolio
    }).then((resp)=>{
        if(resp.status ===  200){
            dispatch({
                type: types.DELETE_PORTFOLIO,
                payload: index
            });

            //fetchSegmentGrowth(obj.accountPlanId)(dispatch);

            message.success('Portfolio deleted successfully');
        } else {
            message.error('Error occures while deleting the portfolio');
        }
    })
}


/****************************** SEGMENT GROWTH **********************************/


export const fetchSegmentGrowth = (accountPlanId) => (dispatch) =>{
    let params = {
        method: conf.fetchSegmentGrowth.method,
        url: conf.fetchSegmentGrowth.url + accountPlanId
    }
    axios(params).then(response => {
        if (response.status === 200) {
            _.each(response.data.data,(obj,index)=>{
                obj.id = index
            });
            dispatch({
                type: types.FETCH_SEGMENT_GROWTH,
                payload: response.data.data
            });
        }
    });
}

export const updateSegmentValue = (pIndex,index,val) => (dispatch) => {
    dispatch({
        type: types.UPDATE_SEGMENT_VALUE,
        payload: {
            pIndex,
            index,
            val
        }
    })
}

export const updateSegmentAPI = (obj,accountPlanId) => (dispatch) => {
    axios({
        method: 'POST',
        url: conf.capUrl +"/" + accountPlanId + "/keyfinancials/segmentGrowth",
        data:obj
    }).then((resp)=>{
        if(resp.status ===  200){
            dispatch({
                type: types.UPDATE_SEGMENT,
                payload: {index,obj}
            });
            message.success('Segment Growth updated successfully');
        } else {
            message.error('Error occures while deleting the portfolio');
        }
    })
}
import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import _ from 'underscore';
import {message} from 'antd';
let conf = new Config();

export const changeKeyTheme = (value,index) => (dispatch) =>{
    
    dispatch({
        type: types.CHANGE_KEY_THEME_FIELD,
        payload: {value,index}
    })
    // const re = /^[0-9\b]+$/;
    //   if (value === '' || re.test(value)) {
    //     dispatch({
    //         type: types.CHANGE_KEY_THEME_FIELD,
    //         payload: {value,index}
    //     })
    //   }
}
export const changeTargetValue = (value,index) => (dispatch) =>{

    dispatch({
        type: types.CHANGE_TARGET_VALUE_FIELD,
        payload: {value,index}
    })
}
export const changeGrowthStrategy = (value,index,growth_index) => (dispatch) =>{
    dispatch({
        type: types.CHANGE_GROWTH_STRATEGY_FIELD,
        payload: {value,index,growth_index}
    })
}
export const changeGoalValue = (value,index) => (dispatch) =>{

    dispatch({
        type: types.CHANGE_GOAL_VALUE,
        payload: {value,index}
    })
}

export const getThreeYearAmbition = (accountPlanId) => (dispatch) => {
   axios({
       url: conf.getThreeYearAmbition.url + "/" +accountPlanId + "/ambition",
       method: conf.getThreeYearAmbition.method
   }).then(resp=>{
       
       if(resp.status === 200){
            dispatch({
                type: types.FETCH_THREE_YEAR_AMBITION,
                payload: resp.data.data.ambitionPlans
            });
       }
   })
}

export const getAmbitionsGoalPlan = (accountPlanId) => (dispatch) => {
    axios({
        url: conf.getAmbitionsGoalPlan.url + "/" +accountPlanId + "/ambition/goals",
        method: conf.getAmbitionsGoalPlan.method
    }).then(resp=>{
        
        if(resp.status === 200){
             dispatch({
                 type: types.FETCH_AMBITION_GOAL_PLAN,
                 payload: resp.data.data
             });
        }
    })
   // console.log(resp);
}
export const submitGoalPlan = (goalPlan,accountPlanId,accountTeamGoalId) => (dispatch) =>{
    let data,flag=false;
    if(accountTeamGoalId === null){
        data = {
            accountTeamGoalId: null,
            teamGoal: goalPlan,
            accountPlanId: accountPlanId
        }
        flag=true;
    }
    else{
        data ={
            accountTeamGoalId: accountTeamGoalId,
            teamGoal: goalPlan,
            accountPlanId: accountPlanId
        }
    }
    //console.log(data);
    axios.post(conf.getAmbitionsGoalPlan.url + "/" + accountPlanId + "/ambition/goals" , data)
    .then((resp)=>{
        if(resp.status === 200){
            message.success('Account Team Goal updated successfully!');
            if(flag){
                dispatch({
                    type: types.SET_TEAM_GOAL_ID,
                    payload: resp.data.data.accountTeamGoalId
                
                });
            }
        }else{
            message.error(`Error occures while updating`);
        }
    })
}


export const createAddmore = (index) => (dispatch) => {
    dispatch({
        type: types.ADD_MORE,
        payload: index
    
    });
   
}

export const addMoreGoal = () => (dispatch) => {
    dispatch({
        type: types.ADD_MORE_GOAL,
    
    });
   
}
export const addGoalValue = () => (dispatch) => {
    dispatch({
        type: types.ADD_GOAL_VALUE,
    
    });
   
}
export const addTeamGoalData = () => (dispatch) => {
    dispatch({
        type: types.ADD_TEAM_GOAL_DATA,
        // payload : accountPlanId
    
    });
   
}

export const deleteElement= (index,growth_index) => (dispatch) => {
    dispatch({
        type: types.DELETE_ELEMENT,
        payload: {index,growth_index}
    
    });
   
}

export const deleteGoalElement= (index,goalPlan,accountPlanId,accountTeamGoalId) => (dispatch) => {
    dispatch({
        type: types.DELETE_GOAL_ELEMENT,
        payload: index
    
    });
    goalPlan.splice(index,1);
    submitGoalPlan(goalPlan,accountPlanId,accountTeamGoalId)(dispatch);
}



export const submitAmbitionsGoalPlan= (ambition,accountPlanId) => (dispatch) =>{
    let data;
    if(ambition.ambitionPlan.ambitionPlanId){
        data ={
            targetValue: ambition.ambitionPlan.targetValue,
            currencyId: ambition.ambitionPlan.currencyId,
            keyTheme: ambition.ambitionPlan.keyTheme,
            ambitionPlanId : ambition.ambitionPlan.ambitionPlanId,
            growthStrategy: ambition.ambitionPlan.growthStrategy,
            accountPlanId: accountPlanId,
            fiscalYear: ambition.fiscalYear
        }
    }
    else{
        data ={
            targetValue: ambition.ambitionPlan.targetValue,
            currencyId: null,
            keyTheme: ambition.ambitionPlan.keyTheme,
            ambitionPlanId : null,
            growthStrategy: ambition.ambitionPlan.growthStrategy,
            accountPlanId: accountPlanId,
            fiscalYear: ambition.fiscalYear
        }
        
    }
     //console.log(data);

    axios.post(conf.getAmbitionsGoalPlan.url + "/" +accountPlanId + "/ambition" , data)
    .then((resp)=>{
        if(resp.status === 200){
            message.success('Ambition Goal Data submitted successfully!');
        }else{
            message.error(`Error occures while Submit`);
        }
    })
}

export const resetAmbition = (ambition,index) => dispatch =>{
    dispatch({
        type: types.RESET_AMBITION,
        payload: {
            index,ambition
        }
    })
}


import * as userActions from './userActions';
import * as overviewActions from './overviewActions';
import * as itLandscapeActions from './itLandscapeActions';
import * as keyMetricsActions from './keyMetricsActions';
import * as footPrintAndWhiteSpaceActions from './footprintWhiteSpaceActions';
import * as strategyActions from './strategyActions';
import * as BusinessITAlignmentActions from './BusinessITAlignmentActions';
import * as landingActions from './landingActions';
export const ActionCreators = Object.assign({},
  userActions,
  overviewActions,
  itLandscapeActions,
  keyMetricsActions,
  footPrintAndWhiteSpaceActions,
  strategyActions,
  BusinessITAlignmentActions,
  landingActions
);

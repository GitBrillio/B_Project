import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import _ from 'underscore';
import {message} from 'antd';
let conf = new Config();


/****************************** GOALS **********************************/

export const getKeyMetrics = (accountPlanId) => (dispatch) => {
    let params = {
        method: conf.getKeyMetrics.method,
        url: conf.getKeyMetrics.url + "/" + "keymetrics?accountName=TECHNIP&customerId=CUST-0000102526"
        //url: conf.getKeyMetrics.url
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.GET_KEY_METRICS,
                payload: response.data.data
            });
        }
        else{
            message.error('Error');
        }
    });
}



export const updatePointField = (key,value) => dispatch => {
    dispatch({
        type: types.UPDATE_DATA_POINTS,
        payload:{
            key,value
        }
    })
}

export const updateDataPoints = (points,accountPlanId) => dispatch => {
    let params = {
        method: 'POST',
        url: conf.getKeyMetrics.url + "/" + accountPlanId + "/keymetrics",
        data: points
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.GET_KEY_METRICS,
                payload: response.data.data
            });
            message.success("Key metrics updated successfully!")
        }
        else if (response.status === 204) {
            message.success("No Account Profile found in VMstar")
        }
        else{
            message.error('Error');
        }
    });
}
import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import _ from 'underscore';
import {message} from 'antd';
let conf = new Config();

export const getFootPrint = (accountPlanId) => (dispatch) => {
    let params = {
        method: conf.getFootPrint.method,
        url: conf.getFootPrint.url + "/" + accountPlanId + "/footprint"
    }
    axios(params).then(response => {
        if (response.status === 200) {
            dispatch({
                type: types.GET_FOOT_PRINT,
                payload: response.data.data
            });
        }
        else{
            message.error('Error in fetching footprint data.');
        }
    });
}

export const updateFootprint = (footprint,accountPlanId) => (dispatch) => {
    let params = {
        method: 'POST',
        url: conf.getFootPrint.url + "/" + accountPlanId + "/footprint/status",
        data: footprint
    }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("Footprint updated successfully!")   
        }
        else{
            message.error('Error in fetching footprint data.');
        }
    });
}

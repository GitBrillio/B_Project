import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import _ from 'underscore';
let conf = new Config();


export const addBusinessGoal = (data) => (dispatch) =>{
    dispatch({
        type: types.ADD_BUSINESS_DATA,
        payload: {data}
    })
}
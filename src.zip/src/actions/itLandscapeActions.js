import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import {message} from 'antd';
import _ from 'underscore';

let conf = new Config();




export const getSystems = (type,accountPlanId) => (dispatch) => {
    let cType = type === 'mcs' ? 'MISSION_CRITICAL_SYSTEM' :'INFORMATION_SYSTEM'
    axios({
        url: conf.getSystems.url + "/" + accountPlanId + "/landscape?type=" + cType,
        method: conf.getSystems.method
    }).then((resp)=>{
        if(type === 'mcs'){
            dispatch({
                type: types.FETCH_DATA,
                payload: {
                    key: 'missionCriticalSystems',
                    data: resp.data.data.landscapes
                }
            })
        }else{
            dispatch({
                type: types.FETCH_DATA,
                payload: {
                    key: 'itSystems', // itSystems
                    data: resp.data.data.landscapes
                }
            })
        }
    })
}

/****************************** GOALS **********************************/

export const pushSystem = (accountPlanId,type) => (dispatch) => {
    let data = {
        "landscape": {
            "landscapeName": "",
            "landscapeType": type,
            "accountPlanId": accountPlanId
        },
        "providerInfo": [
            {
                "providerName": "",
                "providerPlatform": null,
                "landscapeId": ""
            }
        ]
    }
            
    dispatch({
        type: types.PUSH_SYSTEM,
        payload: {
            type: type,
            data: data
        }
    });
}

export const pushProvider = (type,index,landscapeId) => (dispatch) => {

    let data = {
        "providerName": "",
        "providerPlatform": null,
        "landscapeId": landscapeId,
        "providerInfoId": null
    }

    dispatch({
        type: types.PUSH_PROVIDER,
        payload: {
            type: type,
            data: data,
            index: index
        }
    });
}

export const deleteProvider = (obj,type,systemIndex,providerIndex) => (dispatch) => {
    // update it first 
    dispatch({
        type: types.DELETE_PROVIDER,
        payload: {
            type: type,
            data: obj,
            systemIndex: systemIndex,
            providerIndex: providerIndex
        }
    });
}

export const deleteSystem = (accountPlanId,system,index,type,cb) => (dispatch) => {

    axios({
        url: conf.getSystems.url +"/"+ accountPlanId+ "/landscape/" ,
        method: 'DELETE',
        data: {
            capItLandscape: system.landscape,
            capItLandscapeProviderInfo: system.providerInfo
        }
    }).then((resp)=>{
        if(resp.status === 200){
            message.success("System deleted successfully")
        }
        // make api call here
        dispatch({
            type: types.DELETE_SYSTEM,
            payload:{
                type: type,
                index: index
            }
        });
        console.log("Called");
        // after everything call callback
        cb();
    })
    

}

export const changeSystem = (value,index,type) => (dispatch) =>{
    dispatch({
        type: types.CHANGE_SYSTEM_FIELD,
        payload: {value,index,type}
    })
}

export const changeProvider = (value,systemIndex,providerIndex,type,key) => (dispatch) => {
    dispatch({
        type: types.CHANGE_PROVIDER_FIELD,
        payload: {
            value,
            systemIndex,
            providerIndex,
            type,
            key
        }
    })
}

export const updateSystem = (system,systemIndex,type) => (dispatch) => {
    axios({
        url: conf.getSystems.url + "/" +  system.landscape.accountPlanId + "/landscape",
        method: 'POST',
        data: {
            capItLandscape: system.landscape,
            capItLandscapeProviderInfo: system.providerInfo
        }
    }).then((resp)=>{
        if(resp.status === 200){
            message.success("System updated successfully");
            dispatch({
                type: types.UPDATE_SYSTEM,
                payload: {
                    index: systemIndex,
                    type: type,
                    data: {
                        landscape: resp.data.data.capItLandscape,
                        providerInfo: resp.data.data.capItLandscapeProviderInfo
                    }
                }
            })
        }
    })
}


// write your actuion here
    // savve the dat to reducer
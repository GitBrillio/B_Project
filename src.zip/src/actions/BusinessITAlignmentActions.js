import * as types from "../constants/actionTypes";
import axios from 'axios';
import Config from '../config/Config';
import {message} from 'antd';
import _ from 'underscore';

let conf = new Config();

export const getBusinessGoals = (accountPlanId) => (dispatch) => {
    console.log('Here', conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals");
    let params = {
        method: conf.getBusinessGoals.method,
        url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals"
    }
    axios(params).then(response => {
        if (response.status === 200) {
            console.log('getBusinessGoals', response);
            dispatch({
                type: types.GET_BUSINESS_GOALS,
                payload: response.data.data.businessGoals
            });
        }
        else{
            message.error('Error in fetching footprint data.');
        }
    });
}

export const saveBusinessGoal = (requestBody, methodType) => () => {
    console.log('saveBusinessGoal', requestBody);
    console.log('methodType', methodType);
    let params = {
        method: methodType,
        url: conf.saveBusinessGoals.url + "/" + requestBody.accountPlanId + "/business/goals",
        data: requestBody
    }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("Goal Updated successfully!")
        }
        else{
            message.error('Error in fetching footprint data.');
        }
    });
}

export const getBusinessInitiatives = (accountPlanId,biInitiativeId) => (dispatch) => {
    console.log('Here', conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals");
    let params = {
        method: conf.getBusinessGoals.method,
        url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/bi?id="+biInitiativeId
    }
    axios(params).then(response => {
        if (response.status === 200) {
            console.log('getBusinessInitiatives', response);
            dispatch({
                type: types.GET_BUSINESS_INITIATIVES,
                payload: response.data.data
            });
        }
        else{
            message.error('Error in fetching Business Initiatives.');
        }
    });
}

export const saveBusinessInitiative = (requestBody, methodType) => () => {
    console.log('saveBusinessInitiative', requestBody);
    console.log('methodType', methodType);
    let params = {
        method: methodType,
        url: conf.saveBusinessGoals.url + "/" + requestBody.accountPlanId + "/business/goals/bi",
        data: requestBody
    }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("Business Initiative Updated successfully!")
        }
        else{
            message.error('Error in fetching Business Initiative data.');
        }
    });
}


export const getItInitiatives = (accountPlanId,itInitiativeId) => (dispatch) => {
    let params = {
        method: conf.getBusinessGoals.method,
        url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/it?id="+itInitiativeId
    }
    axios(params).then(response => {
        if (response.status === 200) {
            console.log('getItInitiatives', response);
            // dispatch({
            //     type: types.GET_IT_INITIATIVES,
            //     payload: response.data.data
            // });
        }
        else{
            message.error('Error in fetching IT Initiatives.');
        }
    });
}


export const getVMwareInitiatives = (accountPlanId,itInitiativeId) => (dispatch) => {
    let params = {
        method: conf.getBusinessGoals.method,
        url: conf.getBusinessGoals.url + "/" + accountPlanId + "/business/goals/it?vm="+itInitiativeId
    }
    axios(params).then(response => {
        if (response.status === 200) {
            console.log('getVMwareInitiatives', response);
            dispatch({
                type: types.GET_VMWARE_INITIATIVES,
                payload: response.data.data
            });
        }
        else{
            message.error('Error in fetching VMware Initiatives.');
        }
    });
}

export const saveVmInitiative = (requestBody, methodType) => () => {
    console.log('saveVmInitiative', requestBody);
    console.log('methodType', methodType);
    let params = {
        method: methodType,
        url: conf.saveBusinessGoals.url + "/" + requestBody.accountPlanId + "/business/goals/vm",
        data: requestBody
    }
    axios(params).then(response => {
        if (response.status === 200) {
            message.success("VmWare initiative Updated successfully!")
        }
        else{
            message.error('Error while updating.');
        }
    });
}
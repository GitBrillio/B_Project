import {filter,map} from 'lodash';

export const CheckboxDataArray = (checkboxArr) => {
    let statusArray = [];
    checkboxArr.map((val,key)=>(
        statusArray.push({
            index :key,
            label :val,
            status :false   
        })
    ))
    return statusArray;
}
export const CheckboxDataObject = (checkboxObj) => {
    let statusArray = [];
    checkboxObj.map((val,key)=>(
        statusArray.push({
            index :key,
            label :val.value,
            status :false   
        })
    ))
    return statusArray;
}
export const CheckedboxLabelData = (checkboxData) => {
    let filterData = filter(checkboxData,(obj)=>{
        return(obj.status)
    })
    let mapData = map(filterData,"label")
    return(mapData);
}

import React, { Component } from "react";
import PropTypes from "prop-types";
import { ConnectedRouter } from "react-router-redux";
import { Provider } from "react-redux";
import { Switch, Route } from "react-router-dom";
// container
import MainContainer from "./containers/MainContainer.js";
// component
import NotFoundPage from "./components/NotFoundPage";
import RootPage from "./components/RootPage";
import Home from "./components/Home/Home";
import Authenticate from "./components/common/authenticate/Authenticate.jsx";
import Profile from "./components/profile/Profile.jsx";

import createBrowserHistory from "history/createBrowserHistory";
import AccountPlan from "./components/AccountPlan/AccountPlan.js";
import Landing from './components/Landing/Landing';
const history = createBrowserHistory({ basename: "/cap/" });

export default class Routes extends Component {
  render() {
    const { store } = this.props; //history

    return (
      <Provider store={store}>
        <ConnectedRouter history={history}>
          <div>
            <RootPage>
              <Switch>
                <Route
                  path="/authenticate"
                  component={MainContainer(Authenticate)}
                />
                <Route path="/Home" component={MainContainer(Home)} />
                <Route path="/profile" component={Profile} />
                <Route path="/account-plan/:accountPlanId" component={MainContainer(AccountPlan)} />
                <Route path="/landing" component={MainContainer(Landing)} />
                <Route component={NotFoundPage} />
              </Switch>
            </RootPage>
          </div>
        </ConnectedRouter>
      </Provider>
    );
  }
}

Routes.propTypes = {
  store: PropTypes.object.isRequired,
  history: PropTypes.object.isRequired
};

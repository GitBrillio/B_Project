import React, { Component } from 'react';
import PropTypes from "prop-types";
import './LeftNavBar.scss';
import { Layout, Menu, Icon } from 'antd';
import ExportPPT from '../../ExportPPT/exportPPT.js';


const { SubMenu } = Menu;
const { Sider } = Layout;

class LeftNavBar extends Component {

    onMenuChange = (e) => {
        this.props.onMenuChange(e.key)
    }
    render = () => {
        return (
            <section>
                <Sider className="left-navbar">
                    <Menu
                        mode="inline"
                        defaultSelectedKeys={['Overview']} // Overview
                        defaultOpenKeys={['sub1']} //sub1
                        onClick={(e) => this.onMenuChange(e)}
                        style={{ height: '100%', borderRight: 0 }}
                    >
                        <SubMenu key="sub1" title={<span className="sub-menu">Customer Profile</span>}>
                            <Menu.Item key="Overview">
                                <div className="sub-menu-div" >
                                    <Icon type="check-circle-o" />
                                    <span>Overview</span>
                                    <span className="red-star">*</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="OrganizationStructure">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Organization Structure</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="BusinessITAlignment">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Business & IT Alignment</span>
                                    <span className="red-star">*</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="BusinessITInitiatives">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Business & IT Initiatives</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="CustomerStrategyITLandscape">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Customer Strategy & IT Landscape</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="Application Portfolio Evolution">
                                <div className="sub-menu-div no-border">
                                    <Icon type="check-circle-o" />
                                    <span>Application Portfolio Evolution</span>
                                    <span className="red-star">*</span>
                                </div>
                            </Menu.Item>
                        </SubMenu>
                        <SubMenu key="sub2" title={<span className="sub-menu">Footprint</span>}>
                            <Menu.Item key="ITLandscape">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>IT Landscape</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="VMwareBookings">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>VMware Bookings</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="KeyMetrics">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Key Metrics</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="VmwareContracts">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>VMware Contracts</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="ContractsELARenewals">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Contracts & ELA Renewals</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="FootprintWhitespace">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Footprint & Whitespace</span>
                                    <span className="red-star">*</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="KeyCompetitorAnalysis">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Key Competitor Analysis</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="Partners">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Partners</span>
                                    <span className="red-star">*</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="CustomerSuccessSatisfaction">
                                <div className="sub-menu-div no-border">
                                    <Icon type="check-circle-o" />
                                    <span>Customer Success & Satisfaction</span>
                                    <span className="red-star">*</span>
                                </div>
                            </Menu.Item>
                        </SubMenu>
                        <SubMenu key="sub3" title={<span className="sub-menu">Strategy & Actions</span>}>
                            <Menu.Item key="3yearAmbition">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>3-year Ambition</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="CustomerRoadmapAlignmen">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Customer Roadmap Alignmen</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="GameChangerBigBetOpportunities">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Game Changer/Big Bet Opportunities</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="KeyOpportunities">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Key Opportunities</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="eValuePrompter">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>eValue Prompter</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="KeyDecisionMakerCoverage">
                                <div className="sub-menu-div">
                                    <Icon type="check-circle-o" />
                                    <span>Key Decision Maker Coverage</span>
                                </div>
                            </Menu.Item>
                            <Menu.Item key="KeyAction">
                                <div className="sub-menu-div no-border">
                                    <Icon type="check-circle-o" />
                                    <span>Key Action</span>
                                </div>
                            </Menu.Item>
                        </SubMenu>
                    </Menu>
                </Sider>
                {/* <ExportPPT /> */}
            </section>
        );
    }
};

LeftNavBar.propTypes = {
    onMenuChange: PropTypes.func
};
export default LeftNavBar;

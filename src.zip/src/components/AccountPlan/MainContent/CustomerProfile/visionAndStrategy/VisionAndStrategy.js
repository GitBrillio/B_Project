import React, { Component } from 'react';
import { Icon, Popover, Collapse } from 'antd'; //Input
import { taggedUser } from '../taggedUser/taggedUser';
import RichText from '../../../../common/RichText/RichText';
import VmTextarea from '../../../../common/VmTextarea/VmTextarea';
import PropTypes from 'prop-types';
import { isDirty } from '../../../../../Services/Validate';
const Panel = Collapse.Panel;

class VisionAndStrategy extends Component {
    componentDidMount(){
        this.props.actions.fetchVisionStrategy(this.props.accountPlanId)
    }

    updateData(){
        setTimeout(()=>{
            this.props.actions.updateVisionStrategy(this.props.overview.visionStrategy);
        },0)
    }
    render = () => {
        return (
            // defaultActiveKey={['2']}
            <Collapse className="collapse-margin" > 
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Vision &amp; Strategy</span>
                    <span className="red-star">*</span>
                    {/* <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span> */}
                    {/* <Popover placement="leftTop" content={taggedUser()} title="Currently Tagged:">
                        <span className="info-icon">
                            <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                        </span>
                    </Popover> */}
                </div>} key="2">

                    {/* <label className="vs-label">Vision</label>
                    <RichText /> */}

                    <div>
                        <VmTextarea
                            title="Vision"
                            value={this.props.overview.visionStrategy.vision}
                            placeholder="Type your vision..."
                            onChange={e => {
                                this.props.actions.changeOverviewValue('visionStrategy','vision',e.target.value);
                            }}
                            onBlur={this.updateData.bind(this)}
                            maxLength={5000}
                        />
                    </div>
                    <div className="margin-top-forty">
                        <VmTextarea
                            title="Corporate Strategy"
                            value={this.props.overview.visionStrategy.corporateStrategy}
                            placeholder="Type your Corporate Strategy..."
                            onChange={e => {
                                this.props.actions.changeOverviewValue('visionStrategy','corporateStrategy',e.target.value);
                            }}
                            onBlur={this.updateData.bind(this)}
                            maxLength={5000}
                        />
                    </div>
                    <div className="margin-top-forty">
                        <VmTextarea
                            title="Current Highlights & Events"
                            placeholder="Type Current Highlights & Events..."
                            value={this.props.overview.visionStrategy.highlightEvent}
                            onChange={e => {
                                this.props.actions.changeOverviewValue('visionStrategy','highlightEvent',e.target.value);                                
                            }}
                            onBlur={this.updateData.bind(this)}
                            maxLength={5000}
                        />
                    </div>
                    {  !isDirty(this.props.overview.visionStrategy) &&
                        <div className="pull-right reqrd-txt">
                            <Icon type="warning" style={{ color: '#ff153f' }} />
                            <span className="required-txt">Text fields incomplete!</span>
                        </div>
                    }
                </Panel>
            </Collapse>
        )
    }
}

VisionAndStrategy.propTypes = {
    overview: PropTypes.object,
    actions: PropTypes.object,
    accountPlanId: PropTypes.string.isRequired
};

export default VisionAndStrategy;
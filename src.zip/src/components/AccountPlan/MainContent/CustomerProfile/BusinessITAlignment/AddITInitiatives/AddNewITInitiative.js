import React, { Component } from 'react';
import { Modal, Button} from 'antd';
// import './AddNewBusinessInitiative.scss';
import ItInitiativeInput from './ItInitiativeInput';

class AddNewITInitiative extends Component{
    constructor(props) {
        super(props);
        this.state = {
            accountPlanId: this.props.accountPlanId,
            budget: "",
            businessGoalId: this.props.goalId,
            businessInitiativeId: this.props.businessInitiativesId,
            executiveSponsor: "",
            goal: this.props.businessGoalInput,
            initiativeLeader: "",
            initiativeName: "",
            linkStatus: "",
            objectiveAndMetrics: "",
            timeHorizon: ""
        }
    }
      componentDidMount() {
        if(this.props.itId) {
            console.log('componentDidMount');
            this.props.actions.getItInitiatives(this.props.accountPlanId, this.props.itId);
            this.setState({
                accountPlanId: this.props.businessGoalReducer.ItInitiative.accountPlanId,
                budget: this.props.businessGoalReducer.ItInitiative.budget,
                businessGoalId: this.props.businessGoalReducer.ItInitiative.businessGoalId,
                businessInitiativeId: this.props.businessGoalReducer.ItInitiative.businessInitiativeId,
                itInitiativeId: this.props.businessGoalReducer.ItInitiative.itInitiativeId,
                executiveSponsor: this.props.businessGoalReducer.ItInitiative.executiveSponsor,
                goal: this.props.businessGoalReducer.ItInitiative.goal,
                initiativeLeader: this.props.businessGoalReducer.ItInitiative.initiativeLeader,
                initiativeName: this.props.businessGoalReducer.ItInitiative.initiativeName,
                linkStatus: this.props.businessGoalReducer.ItInitiative.linkStatus,
                objectiveAndMetrics: this.props.businessGoalReducer.ItInitiative.objectiveAndMetrics,
                timeHorizon: this.props.businessGoalReducer.ItInitiative.timeHorizon
              })
        }
    }

    handleChange = (e) =>{
        switch(e.target.name){
            case "itName": {
                this.setState({goal : e.target.value});
                break;
            }
            case "time": {
                this.setState({timeHorizon : e.target.value});
                break;
            }
            case "objective": {
                this.setState({objectiveAndMetrics : e.target.value});
                break;
            }
            case "initiativeLeader": {
                this.setState({initiativeLeader : e.target.value});
                break;
            }
            case "budget": {
                this.setState({budget : e.target.value});
                break;
            }
            case "executiveSponser": {
                this.setState({executiveSponsor : e.target.value});
                break;
            }
            case "linkStatus": {
                this.setState({linkStatus : e.target.value});
                break;
            }
            default:{
                break;
            }
        }
        console.log(this.state);
    }
    render = () =>{
        console.log('in IT initatives props', this.props );
        let deleteBtn;
        if (this.props.itId != null){
            deleteBtn = <Button key="submit" type="danger" onClick={()=>this.props.handleDelete()}>Delete</Button>
        }
        return (
            <div className="add-edit-new-group">
            {this.props.visible && <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    deleteBtn ,
                    <Button key="submit" type="primary" onClick={this.props.click}>
                        Save
                    </Button>,
                ]}
            >
                <ItInitiativeInput
                    accountPlanId={this.props.accountPlanId}
                    biName = {this.props.biName}
                    businessInitiativesId = {this.props.businessInitiativesId}
                    itId = {this.props.itId}
                    actions = {this.props.actions}
                    businessGoalReducer = {this.props.businessGoalReducer}
                />
            </Modal>}
        </div>
        )
    }

}

AddNewITInitiative.propTypes = {
}

export default AddNewITInitiative;
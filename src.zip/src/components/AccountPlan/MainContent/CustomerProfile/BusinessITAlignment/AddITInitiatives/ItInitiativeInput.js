import React, { Component } from 'react';
import Input from 'muicss/lib/react/input';
// import './AddNewBusinessInitiative.scss';
import { Row, Col, Radio, Calendar} from 'antd';
const RadioGroup = Radio.Group;

class ItInitiativeInput extends Component{
    

    render = () =>{
        console.log('businessGoalReducer in itInititatives', this.props.businessGoalReducer.ItInitiative);
        return (
            <div>
            <Row padding-bottom>
                <Col span={14}>
                <p className="par">DETAILS</p>
                </Col>
                <Col span={10}>
                <p className="par">SCHEDULE</p>
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        value = {this.props.biName}
                        disabled = {true}
                        label={"Business Initiative"}
                        floatingLabel={true}  
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                    <Input 
                        value = {this.props.businessGoalReducer.ItInitiative.timeHorizon}
                        label={"Time Horizon"}
                        floatingLabel={true}
                        value = {this.state.timeHorizon}
                        onChange = {(e)=>this.handleChange(e)}
                        floatingLabel={true}
                        
                    />
                    {/* <Calendar /> */}
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        value = {this.props.businessGoalReducer.ItInitiative.goal}
                        label={"Enter IT Intitiative*"}
                        value = {this.state.goal}
                        onChange = {(e)=>this.handleChange(e)}
                        name = {"itName"}
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                     <p className="par">PEOPLE</p> 
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        label={"Enter Objective and Metrics"}
                        floatingLabel={true}
                        value = {this.state.objectiveAndMetrics}
                        onChange = {(e)=>this.handleChange(e)}
                        name = {"objective"}
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                <select class="select_style padding" 
                        onChange = {(e)=>this.handleChange(e)}
                        name = {"initiativeLeader"}>
                            <option value="#" selected>Initiative Leader</option>
                            <option value={this.state.initiativeLeader}> {this.state.initiativeLeader}</option>
                          </select>
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        label={"Enter Budget"}
                        floatingLabel={true}
                        value = {this.state.budget}
                        onChange = {(e)=>this.handleChange(e)}
                        name = {"budget"}
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                <select class="select_style padding"
                        onChange = {(e)=>this.handleChange(e)}
                        name = {"executiveSponser"}>
                            <option value="#" selected>Executive Sponsor</option>
                            <option value={this.state.executiveSponsor}>{this.state.executiveSponsor}</option>
                          </select>
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                <p>Clear link to business?</p>
                <RadioGroup onChange = {(e)=>this.handleChange(e)}
                            name = {"linkStatus"} 
                            value = {this.state.linkStatus}>
                        <Radio value={1}>Yes</Radio>
                        <Radio value={2}>No</Radio>
                 </RadioGroup>
                </Col>
            </Row>

        </div> 
        )
    }

}

ItInitiativeInput.propTypes = {
}

export default ItInitiativeInput;
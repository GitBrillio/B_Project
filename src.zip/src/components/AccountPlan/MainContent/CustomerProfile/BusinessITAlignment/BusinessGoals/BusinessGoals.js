import React, { Component } from 'react';
import { Layout } from 'antd';
import './BusinessGoals.scss';
const { Content } = Layout;
import { Button,Collapse,Row,Col } from 'antd'; 
const Panel = Collapse.Panel;
import AddNewBusinessInitiative from '../AddNewBusinessInitiative/AddNewBusinessInitiative';
import AddBusinessGoal from '../AddBusinessGoal/AddBusinessGoal';
import AddInitiatives from '../AddInitiatives/AddInitiatives';

class BusinessGoals extends Component{

    state={
        createModal : false,
        createNewBusiness : false
    }
    addBusinessCancel(){
        this.setState({
            createNewBusiness : false
        })
    }
    addGoalCancel(){
        this.setState({
            createModal : false
        })
    }
 
    render = () =>{
        return(
            <div className="businessGoals">
            <button className="create-goal" onClick={() => this.setState({ createModal: true })}>Create New Goal</button>
            <Collapse defaultActiveKey={['1']}>
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Business Goal: </span>
                </div>} key="1">
                    <section>
                        {false ? <AddInitiatives/>:
                    <div className="btn-new-goal-main">
                                <div className="text-center btn-new-goal-sub">
                                    <button className="create-business" type="dashed" onClick={() => this.setState({ createNewBusiness: true })}>+Create New Business Initiative</button>
                                </div>
                    </div>
                        }
                            <hr className="hr-style"/>
                            <div className="btn-add-edit">
                            {true ?  <button className="add-business" onClick={() => this.setState({ createNewBusiness: true })}>+Add Business Initiative</button>: ""}
                        <button className="edit-goal">Edit Goal</button>
                            </div>
                    </section>
                </Panel>
            </Collapse>
                <AddNewBusinessInitiative
                 visible={this.state.createNewBusiness}
                 heading="Create New Business Initiative"
                 Cancel={() => this.addBusinessCancel()}
                />
                <AddBusinessGoal
                 visible={this.state.createModal}
                 heading="Create New Goal"
                 handleCancel={() => this.addGoalCancel()}
                />
                </div>
        )
    }

}

BusinessGoals.propTypes = {
}

export default BusinessGoals;
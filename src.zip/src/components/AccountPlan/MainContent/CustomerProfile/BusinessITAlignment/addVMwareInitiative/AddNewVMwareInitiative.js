import React, { Component } from 'react';
import { Modal, Button} from 'antd';
// import './AddNewBusinessInitiative.scss';
import VmWareInitiativeInput from './VmWareInitiativeInput';

class AddNewVMwareInitiative extends Component{
    

    render = () =>{
        let deleteBtn = "";
        if (this.props.vmId != null){
            deleteBtn = <Button key="submit" type="danger" onClick={()=>this.props.handleDelete()}>Delete</Button>
        }
        return (
            <div className="add-edit-new-group">
            { this.props.visible && <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    deleteBtn,
                    <Button key="submit" type="primary" onClick={()=>this.props.handleSave()}>
                        Save
                    </Button>
                ]}
            >
                <VmWareInitiativeInput 
                    biName = {this.props.biName}
                    vmWareInputVal = {this.props.vmWareInputVal}
                    vmName = {this.props.vmName}
                />
            </Modal>}
        </div>
        )
    }

}

AddNewVMwareInitiative.propTypes = {
}

export default AddNewVMwareInitiative;
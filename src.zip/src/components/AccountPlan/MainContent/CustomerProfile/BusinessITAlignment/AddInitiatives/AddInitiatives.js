import React, { Component } from 'react';
import { Row,Col } from 'antd'; 
import './AddInitiatives.scss';

class AddInitiatives extends Component{
    render=()=>{
        return(
            <div className="initiatives">
                <div className="add-initiative">
                    <Row>
                        <Col span={8}>
                        <p className="p-style">BUSINESS INITIATIVE</p>
                        </Col>
                        <Col span={8}>
                        <p className="p-style">IT INITIATIVES</p>
                        </Col>
                        <Col span={8}>
                        <p className="p-style">VMWARE INITIATIVES</p>
                        </Col>
                    </Row>
                </div>
            </div>
        )
    }
}
AddInitiatives.propTypes = {
}

export default AddInitiatives;
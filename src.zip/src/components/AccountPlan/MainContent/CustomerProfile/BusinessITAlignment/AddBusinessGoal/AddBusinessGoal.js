import React, { Component } from 'react';
import { Modal, Button} from 'antd';
import './AddBusinessGoal.scss';
import Input from 'muicss/lib/react/input';

class AddBusinessGoal extends Component{

    render = () =>{
        return (
            <div className="add-edit-new-group">
            <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    <Button key="submit" type="primary" onClick={this.props.click}>
                        Save
                    </Button>,
                ]}
            >
               <Input 
                        type="text"
                        label={"Enter Goal"}
                        floatingLabel={true}
                    />
            </Modal>
        </div>
        )
    }

}

AddBusinessGoal.propTypes = {
}

export default AddBusinessGoal;
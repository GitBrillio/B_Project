import React, { Component } from 'react';
import { Modal, Button} from 'antd';
import './AddBusinessGoal.scss';
import Input from 'muicss/lib/react/input';

class AddBusinessGoal extends Component{
    constructor(){
        super();
    }
    deleteGoal() {
        const body =  {
            "goal": "",
            "accountPlanId": this.props.accountPlanId,
            "businessGoalId": this.props.goalId
        }
        this.props.actions.saveBusinessGoal(body, 'DELETE');
    }
    render = () =>{
        console.log('Add business goal', this.props);
        let deleteBtn;
        if (this.props.businessGoalInput != ""){
            deleteBtn = <Button key="submit" type="danger" onClick={()=>this.props.handleDelete()}>Delete</Button>
        }
        return (
            <div>
            {this.props.visible && <Modal
                className="creat-new-goal"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    deleteBtn
                    ,
                    <Button key="submit" type="primary" onClick={()=>this.props.handleSave()}>
                        Save
                    </Button>
                ]}
            >
                <Input 
                    value={this.props.businessGoalInput}
                    type="text"
                    label={"Enter Goal"}
                    floatingLabel={true}
                    onChange={(e)=>this.props.businessGoalInputVal(e)}
                    />
            </Modal>
            }
        </div>
        )
    }

}

AddBusinessGoal.propTypes = {
}

export default AddBusinessGoal;
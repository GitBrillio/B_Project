import React, { Component } from 'react';
import { Layout } from 'antd';
import './BusinessITAlignment.scss';
const { Content } = Layout;
import { Button,Collapse,Row,Col } from 'antd'; 
import AddBusinessGoal from './AddBusinessGoal/AddBusinessGoal'
import BusinessGoals from './BusinessGoals/BusinessGoals'
const Panel = Collapse.Panel;

class BusinessITAlignment extends Component{
    state={
        addnewModal: false
    }
    goalCancel(){
        this.setState({
            addnewModal :false
        })
    }

    render = () =>{
        return (
            <section className="businessITAlignment">
            <Layout>
                <Content style={{ padding: 24, margin: 0 }}>
                <h3 className="h3-style">Customer Profile</h3>
                <h1>Business & IT Alignment</h1>
                {this.state.addnewModal==true ? <div className="new-goal">
                    <div className="btn-new-goal-main">
                                    <div className="text-center btn-new-goal-sub">
                                        <button className="dashed-btn" type="dashed" onClick={() => this.setState({ addnewModal: true })}>Create New Goal</button>
                                    </div>
                    </div>
                </div>:
                    <BusinessGoals/>
                    }
                
                </Content>
                <AddBusinessGoal
                 visible={this.state.addnewModal}
                 heading="Create New Goal"
                 handleCancel={() => this.goalCancel()}
                />
            </Layout>
                
            </section>
        )
    }

}

BusinessITAlignment.propTypes = {
}

export default BusinessITAlignment;


import React, { Component } from 'react';
import Input from 'muicss/lib/react/input';
import './AddNewBusinessInitiative.scss';
import { Row, Col, Radio, Calendar} from 'antd';
const RadioGroup = Radio.Group;

class BusinessInitiativeInput extends Component{
     render = () =>{
        console.log('businessGoalReducer', this.props.businessGoalReducer);
        console.log('PROPS', this.props);
        return (
            <div>
            <Row padding-bottom>
                <Col span={14}>
                <p className="par">DETAILS</p>
                </Col>
                <Col span={10}>
                <p className="par">SCHEDULE</p>
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        value = {this.props.businessGoalInput}
                        label={"Goal"}
                        floatingLabel={true}
                        disabled = {true}
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                    <Input                         
                        label={"Time Horizon"}
                        name = {"time"}
                        value = {this.props.targetValue.timeHorizon}
                        onChange = {(e)=>this.props.handleChangeVal(e)}
                        floatingLabel={true}
                        
                    />
                    {/* <Calendar /> */}
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        label={"Enter Business Initiative Name*"}
                        floatingLabel={true}
                        value = {this.props.targetValue.goal}
                        onChange = {(e)=>this.props.handleChangeVal(e)}
                        name = {"biName"}
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                     <p className="par">PEOPLE</p> 
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        label={"Enter Objective and Metrics"}
                        floatingLabel={true}
                        value = {this.props.targetValue.objectiveAndMetrics}
                        onChange = {(e)=>this.props.handleChangeVal(e)}
                        name = {"objective"}
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                <select class="select_style padding" 
                        onChange = {(e)=>this.props.handleChangeVal(e)}
                        name = {"initiativeLeader"}>
                            <option value="#" selected>Enter Initiative Leader</option>
                            <option value="#">{this.props.targetValue.initiativeLeader}</option>
                          </select>
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                    <Input 
                        label={"Enter Budget"}
                        floatingLabel={true}
                        value = {this.props.targetValue.budget}
                        onChange = {(e)=>this.props.handleChangeVal(e)}
                        name = {"budget"}
                    />
                </Col>
                <Col className="gutter-row padding" span={10}>
                <select class="select_style padding"
                        onChange = {(e)=>this.props.handleChangeVal(e)}
                        name = {"executiveSponser"}>
                            <option value="#" selected>Enter Executive Sponsor</option>
                            <option value="#">{this.props.targetValue.executiveSponsor}</option>
                          </select>
                </Col>
            </Row>
            <Row gutter={32} className="business-initiative-block-main">
                <Col className="gutter-row padding" span={14}>
                <p>Clear link to IT?</p>
                <RadioGroup onChange = {(e)=>this.props.handleChangeVal(e)}
                            name = {"linkStatus"} 
                            value = {this.props.targetValue.linkStatus}>
                        <Radio value={1}>Yes</Radio>
                        <Radio value={2}>No</Radio>
                 </RadioGroup>
                </Col>
            </Row>

        </div> 
        )
    }

}

BusinessInitiativeInput.propTypes = {
}

export default BusinessInitiativeInput;
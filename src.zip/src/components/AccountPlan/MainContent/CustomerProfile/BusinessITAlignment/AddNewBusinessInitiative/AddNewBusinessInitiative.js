import React, { Component } from 'react';
import { Modal, Button} from 'antd';
import './AddNewBusinessInitiative.scss';
import BusinessInitiativeInput from './BusinessInitiativeInput';

class AddNewBusinessInitiative extends Component{

    render = () =>{
        return (
            <div className="add-edit-new-group">
            <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.Cancel}
                footer={[
                    <Button key="submit" type="primary" onClick={this.props.click}>
                        Save
                    </Button>,
                ]}
            >
                <BusinessInitiativeInput/>
            </Modal>
        </div>
        )
    }

}

AddNewBusinessInitiative.propTypes = {
}

export default AddNewBusinessInitiative;
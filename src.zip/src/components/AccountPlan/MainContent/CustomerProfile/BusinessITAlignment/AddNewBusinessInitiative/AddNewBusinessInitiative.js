import React, { Component } from 'react';
import { Modal, Button} from 'antd';
import './AddNewBusinessInitiative.scss';
import BusinessInitiativeInput from './BusinessInitiativeInput';

class AddNewBusinessInitiative extends Component{

    constructor(props) {
        super(props);
        this.state = {
            accountPlanId: this.props.accountPlanId,
            budget: "",
            businessGoalId: this.props.goalId,
            businessInitiativeId: this.props.businessInitiativesId,
            executiveSponsor: "",
            goal: this.props.businessGoalInput,
            initiativeLeader: "",
            initiativeName: "",
            linkStatus: "",
            objectiveAndMetrics: "",
            timeHorizon: ""
        }
    }

    componentDidMount() {
        console.log('componentDidMount BI' , this.props.businessGoalReducer);
        if(this.props.businessInitiativesId) {
        this.props.actions.getBusinessInitiatives(this.props.accountPlanId, this.props.businessInitiativesId);
        this.setState({
            budget: this.props.businessGoalReducer.businessInitiative.budget,
            executiveSponsor: this.props.businessGoalReducer.businessInitiative.executiveSponsor,
            goal: this.props.businessGoalReducer.businessInitiative.goal,
            initiativeLeader: this.props.businessGoalReducer.businessInitiative.initiativeLeader,
            initiativeName: this.props.businessGoalReducer.businessInitiative.initiativeName,
            linkStatus: this.props.businessGoalReducer.businessInitiative.linkStatus,
            objectiveAndMetrics: this.props.businessGoalReducer.businessInitiative.objectiveAndMetrics,
            timeHorizon: this.props.businessGoalReducer.businessInitiative.timeHorizon
          })
        }
    }

    handleChange = (e) =>{
        switch(e.target.name){
            case "biName": {
                this.setState({goal : e.target.value});
                break;
            }
            case "time": {
                this.setState({timeHorizon : e.target.value});
                break;
            }
            case "objective": {
                this.setState({objectiveAndMetrics : e.target.value});
                break;
            }
            case "initiativeLeader": {
                this.setState({initiativeLeader : e.target.value});
                break;
            }
            case "budget": {
                this.setState({budget : e.target.value});
                break;
            }
            case "executiveSponser": {
                this.setState({executiveSponsor : e.target.value});
                break;
            }
            case "linkStatus": {
                this.setState({linkStatus : e.target.value});
                break;
            }
            default:{
                break;
            }
        }
        console.log(this.state);
    }

    render = () =>{
        console.log('businessGoalReducer', this.props.businessGoalReducer);
        console.log('State new', this.state);

        let deleteBtn;
        if (this.props.businessInitiativesId != ""){
            deleteBtn = <Button key="submit" type="danger" onClick={()=>this.props.handleDelete(this.state)}>Delete</Button>
        }
        return (
            <div className="add-edit-new-group">
            { this.props.visible && <Modal
                className="add-edit-new-popup"
                title={this.props.heading}
                visible={this.props.visible}
                centered
                onCancel={this.props.handleCancel}
                footer={[
                    deleteBtn, 
                    <Button key="submit" type="primary" onClick={()=>this.props.handleSave(this.state)}>
                        Save
                    </Button>,
                ]}
            >
                <BusinessInitiativeInput
                    businessGoalInput = {this.props.businessGoalInput}
                    
                    actions = {this.props.actions}
                    handleChangeVal = {(e)=>this.handleChange(e)}
                    targetValue = {this.state}
                />
            </Modal> }
        </div>
        )
    }

}

AddNewBusinessInitiative.propTypes = {
}

export default AddNewBusinessInitiative;
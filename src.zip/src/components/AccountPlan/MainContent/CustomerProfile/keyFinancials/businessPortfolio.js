import React from 'react';
import VmInput from '../../../../common/VmInput/VmInput';
import {Icon} from 'antd'
import VmLabelInput from '../../../../common/VmLabelInput/VmLabelInput';
import { validateMax } from '../../../../../Services/Validate';

export const BusinessPortfolio = ({ portfolio,actions,accountPlanId }) => {
    const validate = validateMax(portfolio.businessPortfolio,'portfolioValue',100)
    return (
        <section>
            <div className="net-sales"> Business Portfolio (%)</div>
            {portfolio.businessPortfolio.map((obj,index)=>(
                <div className="net-sales-info" key={index}>
                    <div className="col-lg-4 col-sm-4 col-xs-12 col-md-4">
                        <VmLabelInput 
                            value={obj.portfolio.portfolioLabel} 
                            onChange={(e)=>actions.changePortfolioLabel(index,e.target.value)}
                            onBlur={()=>setTimeout(()=>
                                    actions.updatePortfolio(obj,index),
                                    0
                                )
                            }
                        />
                    </div>
                    <div className="col-lg-8 col-sm-8 col-xs-12 col-md-8">
                        <VmInput
                            placeholder="Enter Value"
                            value={obj.portfolio.portfolioValue}
                            pattern="^([0-9]*)\.?([0-9]{1,2})?$"
                            max={100}
                            onChange={(e)=>{
                                actions.changePortfolioValue(index,e.target.value)
                            }}
                            onBlur={()=>setTimeout(()=>
                                    actions.updatePortfolio(obj,index),
                                    0
                                )
                            }
                        />
                        <Icon 
                            className="minus-circle" type="minus-circle-o" 
                            onClick={()=>actions.deletePortfolio(obj,index)}
                        />
                    </div>
                </div>
            ))}
            <div className="add-another">
                <Icon type="plus" style={{ color: '#007cbb', fontSize: "10px", fontWeight: 'bold' }} />
                <button onClick={()=>{
                    actions.pushPortfolio(accountPlanId)
                }} className="add-btn">ADD ANOTHER</button>
            </div>
            {  validate.status !== 'EQUAL' &&
                <div className="pull-right reqrd-txt">
                    <Icon type="warning" style={{ color: '#ff153f' }} />
                    <span className="required-txt">{validate.message}</span>
                </div>
            }
        </section>
    )
}
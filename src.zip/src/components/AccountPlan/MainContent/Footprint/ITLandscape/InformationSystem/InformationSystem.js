import React, { Component } from 'react';
import { Collapse, Button,Row,Col } from 'antd'; //Input
import PropTypes from 'prop-types';
import System from '../System/System';
import './is.scss';
import DeletePopup from '../../../../../common/DeletePopup/DeletePopup';
const Panel = Collapse.Panel;

class InformationSystem extends Component{


    state = {
        deletePopup: false,
        type: null,
        systemIndex: null,
        system: null
    }

    deleteCancel(){
        this.setState({
            deletePopup: false
        })
    }

    deleteSystem(type,systemIndex,system){
        this.setState({
            deletePopup: true,
            type: type,
            systemIndex: systemIndex,
            system: system
        })
    }

    deleteOk(){
        this.props.actions.deleteSystem(
            this.props.accountPlanId,
            this.state.system,
            this.state.systemIndex,
            this.state.type,
            this.deleteCancel.bind(this)
        );
    }

    
    render(){
        const {footprint,actions,accountPlanId} = this.props;
        return(
            <Collapse defaultActiveKey={['1']} className="is">
                <Panel header={<div className="collapse-main">
                    <span className="collapse-header">Information Systems</span>
                </div>} key="1">
                    <section>
                            {
                                footprint.itSystems.length === 0 ?
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-30 text-center">
                                    <Button onClick={()=>actions.pushSystem(accountPlanId,'INFORMATION_SYSTEM')} className="dashed-button" type="dashed">Create Information System</Button>
                                </div>
                                :
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-15">
                                    <Button onClick={()=>actions.pushSystem(accountPlanId,'INFORMATION_SYSTEM')} style={{height:'40px'}} type="dashed" block>Create Information System</Button>
                                    <Row className="system-area" gutter={12}>
                                        {
                                            footprint.itSystems.map((obj,index)=>(
                                               <Col span={12} key={index} style={{marginTop:'15px'}}>
                                                    <System 
                                                        system={obj} 
                                                        actions={actions} 
                                                        type="INFORMATION_SYSTEM"
                                                        key={index} 
                                                        systemIndex={index}
                                                        deleteSystem={this.deleteSystem.bind(this)}
                                                    />
                                                </Col>
                                            ))
                                        }
                                    </Row>
                                </div>
                            }
                             <DeletePopup 
                                heading="Delete Information System"
                                visible={this.state.deletePopup} 
                                ok={()=>this.deleteOk()} 
                                cancel={()=>this.deleteCancel()} 
                                okText="Yes delete it" 
                                cancelText="No, cancel it" 
                                contents="Are you sure you want to delete the Information System?" 
                            /> 
                    </section>
                </Panel>
            </Collapse>
                    
        )
    }
}

InformationSystem.propTypes = {
    actions: PropTypes.object,
    footprint: PropTypes.object,
    accountPlanId: PropTypes.string
}


export default InformationSystem;
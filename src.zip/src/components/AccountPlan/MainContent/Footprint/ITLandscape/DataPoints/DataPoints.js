import React, { Component } from 'react';
import Input from 'muicss/lib/react/input';
import './data-points.scss';
import PropTypes from 'prop-types';

export default class DataPoints extends Component{
    render(){
        const {point,actions,accountPlanId} = this.props
        return(
            <div className="data-points">
                <div className="headers">
                    Key Data Points
                </div>
                { point ? 
                <div className="body-port">
                    <div className="heading">Goto VMStar</div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('itSpendAmount',e.target.value)} 
                                label="ANUAL IT SPEND" 
                                floatingLabel={true} 
                                value={point.itSpend} 
                            />
                        </div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('noOfVms',e.target.value)} 
                                label="#VMS" 
                                floatingLabel={true} 
                                value={point.noOfVms} 
                            />
                        </div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('noOfVirtualHosts',e.target.value)}
                                label="# VIRTUAL HOTS (ESX, HyperV)" 
                                floatingLabel={true} 
                                value={point.noOfVirtualHosts} 
                            />
                        </div>
                        <div className="input-box">
                            <Input 
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)}
                                //onChange={(e)=>actions.updatePointField('noOfUnvirtualizedX86Servers',e.target.value)}
                                label="# X86 SERVERS NOT VIRTUALIZED" 
                                floatingLabel={true} 
                                value={point.noOfx86ServersNotVirtualized} 
                            />
                        </div>
                        <div className="input-box">
                            <Input
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)} 
                                //onChange={(e)=>actions.updatePointField('noOfDesktops',e.target.value)}
                                label="# DESKTOPS" 
                                floatingLabel={true} 
                                value={point.noOfDesktops} 
                            />
                        </div>
                        
                        <div className="input-box">
                            <Input 
                                label="% DESKTOP VIRTUALIZED" 
                                floatingLabel={true} 
                                value={point.noOfVirtualHosts} 
                            />
                        </div>
                        <div className="input-box">
                            <Input
                                //onBlur={()=>actions.updateDataPoints(point,accountPlanId)} 
                                label="# MOBILE DEVICES" 
                                //onChange={(e)=>actions.updatePointField('noOfMobileDevices',e.target.value)}
                                floatingLabel={true} 
                                value={point.noOfMobileDevices} 
                            />
                        </div>
                    </div>
                    :
                        <div style={{textAlign:'center',marginTop:'45px'}}>No Data available</div>
                }
                
            </div>
        )
    }
}
DataPoints.propTypes = {
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    point: PropTypes.any
}

import React, { Component } from 'react';
import { Layout, Icon, Collapse } from 'antd'; //Input
import './it-landscape.scss';
import MissionCriticalSystem from './MissionCriticalSystem/MissionCriticalSystem';
import InformationSystem from './InformationSystem/InformationSystem';
import DataPoints from './DataPoints/DataPoints';
import PropTypes from 'prop-types';

const { Content } = Layout;

class ITLandscape extends Component{


    componentDidMount(){
        this.props.actions.getSystems('mcs',this.props.accountPlanId);
        this.props.actions.getSystems('insys',this.props.accountPlanId);
        this.props.actions.getKeyMetrics(this.props.accountPlanId);
        
    }
    render = () =>{
        return (
            <section className="it-landscape">
                <Layout>
                    <Content>
                        <h3>Footprint</h3>
                        <h1>IT Landscape</h1>
                        <div className="row">
                            <div className="col-lg-9">
                                <MissionCriticalSystem 
                                    footprint={this.props.footprintReducer} 
                                    actions={this.props.actions}
                                    accountPlanId={this.props.accountPlanId}
                                />
                                <br/>
                                <InformationSystem 
                                    footprint={this.props.footprintReducer} 
                                    actions={this.props.actions}
                                    accountPlanId={this.props.accountPlanId}
                                />
                            </div>
                            <div className="col-lg-3">
                                <DataPoints 
                                    footprint={this.props.footprintReducer} 
                                    actions={this.props.actions}
                                    updatePoint={this.props.actions.updatePoint}
                                    accountPlanId={this.props.accountPlanId}
                                    point={this.props.keyMetricsReducer.keyMetrics}
                                />
                            </div>
                        </div>
                    </Content>
                </Layout>
                
            </section>
        )
    }
}

ITLandscape.propTypes = {
    actions: PropTypes.object,
    footprintReducer: PropTypes.object,
    accountPlanId: PropTypes.string,
    keyMetricsReducer: PropTypes.object
}

export default ITLandscape;

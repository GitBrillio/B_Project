import React, { Component } from 'react';
import { Layout, Collapse } from 'antd'; //Input
import './key-metrics.scss';
import PropTypes from 'prop-types';
const Panel = Collapse.Panel;
const { Content } = Layout;

class KeyMetrics extends Component{
    componentDidMount(){
        this.props.actions.getKeyMetrics(this.props.accountPlanId);
    }
    render = () =>{
        //const {this.props.keyMetricsReducer.keyMetrics} = this.props.keyMetricsReducer.keyMetrics;
        return (
            <section className="key-metrics">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3>Footprint</h3>
                        <h1>VMstar Key Metrics</h1>
                        <a className="anchor-tag vmstar-btn" target="_blank" href={"https://test.salesforce.com/"+this.props.keyMetricsReducer.keyMetrics.accountId}>Go to VMstar</a>
                        
                        {/* <button className="vmstar-btn">Go to VMstar</button> */}
                        {/* <div className="sub-txt-cont">
                            <span className="left-sub-txt">
                                <span className="sub-txt-title">Last updated on:</span>
                                <span className="sub-txt-date">Today 10:45 AM</span>
                            </span>
                            <button className="vmstar-btn">Go to VMstar</button>
                        </div> */}
                        {
                            this.props.keyMetricsReducer.keyMetrics ? 
                            <div className="clear-both">
                                <Collapse defaultActiveKey={['1']}>
                                <Panel header="Record Detail" key="1">
                                    <section>
                                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding-cont">
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                                <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Account Profile:</div>
                                                <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.accountProfile}</div>
                                            </div>
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6" >
                                                <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Status:</div>
                                                <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.status}</div>
                                            </div>
                                        </div>
                                    </section>
                                </Panel>
                            </Collapse>

                            <Collapse className="margin-twenty" defaultActiveKey={['2']}>
                                <Panel header="Account Information" key="2">
                                    <section>
                                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding-cont">
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Account Name:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.accountName}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Sales Territory:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.salesTerritory}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Industry:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.industry}</div>
                                                </div>
                                            </div>
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6" >
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Customer ID:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                                        <a target="_blank" href={"https://test.salesforce.com/"+this.props.keyMetricsReducer.keyMetrics.accountId}>{this.props.keyMetricsReducer.keyMetrics.customerId}</a>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Zip Code:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.zipcode}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </Panel>
                            </Collapse>

                            <Collapse className="margin-twenty" defaultActiveKey={['3']}>
                                <Panel header="Profile Information" key="3">
                                    <section>
                                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding-cont">
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">No. of x86 Servers not virtualized:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.noOfx86ServersNotVirtualized}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">No. of VMs:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.noOfVms}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">No. of virtual (ESX, HyperV):</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.noOfVirtualHosts}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">IT Spend:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.itSpend}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Installed Applications::</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.installedApplications}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Consolidation Ratio:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.consolidationRatio}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Mobile Devices Managed Percent:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.mobileDevicesManagedPercent}</div>
                                                </div>
                                            </div>
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6" >
                                                <div  className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">No. of Desktops:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.noOfDesktops}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">No. of Mobile Devices:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.noOfMobileDevices}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Customer Addressable Spend:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.customerAddressableSpend}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Main Critical Application:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.mainCriticalApplication}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Virtualization Ratio:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.virtualizationRatio}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Desktops Virtualized Percent:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.desktopsVirtualizedPercent}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </Panel>
                            </Collapse>

                            <Collapse className="margin-twenty" defaultActiveKey={['4']}>
                                <Panel header="Other Information" key="4">
                                <section>
                                    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding-cont">
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">EMC Strategic Relationship:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.emcStrategicRelationship}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">SDDC Competitor:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.sddcCompetitor}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">EUC Virtualization Competitor:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.eucVirtualizationCompetitor}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Public Cloud Competitor:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.publicCloudCompetitor}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">vCAC (vCloud Automation Center):</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.vcac}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">vCloud Suite Ent:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.vcloudSuiteEnt}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Account Development Workshop:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.accountDevelopmentWorkshop}</div>
                                                </div>
                                            </div>
                                            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6" >
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">TAM:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.tam}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">PSO:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.pso}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Accelerate Advisory Services:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.accelerateAdvisoryServices}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">SI/SO:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.siSo}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">CxO Relationship:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.cxoRelationship}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 left-area">Main Hardware x86:</div>
                                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">{this.props.keyMetricsReducer.keyMetrics.mainHardwareX86}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </Panel>
                            </Collapse>
                            </div>
                            : 
                            <div style={{textAlign:'center',marginTop:'45px'}}>No Account Profile found in VMstar</div>
                        }

                            

                    </Content>
                </Layout>
                
            </section>
        )
    }
}

KeyMetrics.propTypes = {
    actions: PropTypes.object,
    accountPlanId: PropTypes.string,
    keyMetricsReducer: PropTypes.object
}

export default KeyMetrics;

import React, { Component } from "react";
import { Layout, Icon, Collapse } from "antd"; //Input
import "./footprint-whitespace.scss";
import PropTypes from "prop-types";
import EndUserComputing from "./EndUserComputing/EndUserComputing";
import CloudManagement from "./CloudManagement/CloudManagement";
import Footprint from "./../Footprint";
import ComputeNetworkStorage from "./ComputeNetworkStorage/ComputeNetworkStorage";

const { Content } = Layout;

class FootPrintAndWhiteSpace extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount(){
    this.props.actions.getFootPrint(this.props.accountPlanId);
  }
  render = () => {
    return (
      <section className="footprint-workspace">
        <Layout>
          <Content>
            <h3>Footprint</h3>
            <h1>Footprint & Whitespace</h1>
            <div className="row fw-row">
              <div className="col-lg-12">
                <EndUserComputing
                  footprint={this.props.footprintReducer}
                  actions={this.props.actions}
                  accountPlanId={this.props.accountPlanId}
                />
              </div>
            </div>
            <div className="row fw-row">
              <div className="col-lg-12">
                <CloudManagement
                  footprint={this.props.footprintReducer}
                  actions={this.props.actions}
                  accountPlanId={this.props.accountPlanId}
                />
              </div>
            </div>
            <div className="row fw-row">
              <div className="col-lg-12">
                <ComputeNetworkStorage
                  footprint={this.props.footprintReducer}
                  actions={this.props.actions}
                  accountPlanId={this.props.accountPlanId}
                />
              </div>
            </div>
          </Content>
        </Layout>
      </section>
    );
  };
}

FootPrintAndWhiteSpace.propTypes = {
  actions: PropTypes.object,
  accountPlanId: PropTypes.string,
  footprintReducer: PropTypes.object
}

export default FootPrintAndWhiteSpace;

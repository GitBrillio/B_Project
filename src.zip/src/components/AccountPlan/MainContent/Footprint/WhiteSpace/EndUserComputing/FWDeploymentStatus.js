import React, { Component } from "react";
import { Menu, Dropdown, Icon, Popover, Button, Layout, Collapse } from "antd";
import "./end-user-computing.scss";
import PropTypes from "prop-types";

class FWDeploymentStatus extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  const menu = (
<Menu>
        <Menu.Item key="0">
          <div>
            <span
              className="deployment-status-selector"
              style={{ background: "#088400" }}
            />
            <span className="title-status-1">Fully Deployed</span>
            <span className="subtitle-status-1">
              Purchased and deployed across entire infrastructure or user base
            </span>
          </div>
        </Menu.Item>
        <Menu.Item key="1">
          <div>
            <span
              className="deployment-status-selector-2"
              style={{ background: " #2880DC" }}
            />
            <span className="title-status-2">Partially Deployed</span>
            <span className="subtitle-status-2">
              Purchased and/or deployed partially, ie. not yet across entire
              infrastructure or user base
            </span>
          </div>
        </Menu.Item>
      </Menu>
  )
  render() {
    return (
        
    );
  }
}

export default FWDeploymentStatus;

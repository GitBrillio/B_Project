import React, { Component } from "react";
import { Menu, Dropdown, Icon, Popover, Button, Layout, Collapse } from "antd";
import "./end-user-computing.scss";
import PropTypes from "prop-types";
import { isEmpty } from "lodash";
import { Select, Divider } from "antd";
import DeploymentStatusMenu from "./../DeploymentStatusMenu";
import _ from 'underscore';

const { Option } = Select;

// const menu = (
//   <Menu className="deployment-status-menu">
//     <span className="deployment-status-header">Deployment Status</span>
//     <Menu.Item key="0" className="test">
//       <div className="deployment-status-wrapper">
//         <span className="deployment-status-selector-1" />
//         <span className="title-status-1">Fully Deployed</span>
//         <span className="subtitle-status">
//           Purchased and deployed across entire infrastructure or user base
//         </span>
//       </div>
//     </Menu.Item>
//     <Menu.Item key="1">
//       <div>
//         <span className="deployment-status-selector-2" />
//         <span className="title-status-2">Partially Deployed</span>
//         <span className="subtitle-status">
//           Purchased and/or deployed partially, ie. not yet across entire
//           infrastructure or user base
//         </span>
//       </div>
//     </Menu.Item>
//     <Menu.Item key="2">
//       <div>
//         <span className="deployment-status-selector-3" />
//         <span className="title-status-3">Active Campaign</span>
//         <span className="subtitle-status">
//           Validated SFDC opportunity or close to it
//         </span>
//       </div>
//     </Menu.Item>
//     <Menu.Item key="3">
//       <div>
//         <span className="deployment-status-selector-4" />
//         <span className="title-status-4">Shelfware</span>
//         <span className="subtitle-status">Purchased but not deployed</span>
//       </div>
//     </Menu.Item>
//     <Menu.Item key="4">
//       <div>
//         <span className="deployment-status-selector-5" />
//         <span className="title-status-5">Competitive Loss</span>
//         <span className="subtitle-status">
//           Validated SFDC opportunity or close to it
//         </span>
//       </div>
//     </Menu.Item>
//     <Menu.Item key="5">
//       <div>
//         <span className="deployment-status-selector-6" />
//         <span className="title-status-6">White Space</span>
//         <span className="subtitle-status">
//           Validated SFDC opportunity or close to it
//         </span>
//       </div>
//     </Menu.Item>
//     <div className="no-status-btn">
//       <Button>No Status</Button>
//     </div>
//   </Menu>
// );

class FWComponents extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentStatus: "",
      menuVisible: false,
      dropdownVisible: false,
      menuClassName: ""
    };
  }

  menuChange = e => {
    console.log("Menu changed", e);
    let menuClassName = e
      .split(" ")
      .join("-")
      .toLowerCase();
    this.setState({ currentStatus: e, menuClassName });
    this.update(e)
  };

  update(menuStr){
    let deploymentStatusId = _.find(this.props.statusMenu,(o)=>{
      return o.statusLabel === menuStr
    });
    this.props.actions.updateFootprint({
      productLookupId: this.props.product.productLookupId,
      deploymentStatusId: deploymentStatusId === undefined ? null : deploymentStatusId.deploymentStatusId
    },this.props.accountPlanId);
  }

  showStatusMenu = e => {
    console.log("Dropdown visible", e);
    this.setState({
      dropdownVisible: true
    });
  };

  getColorById(name){
    switch(name){
      case 'Fully Deploye': 
        return "#0A8400";
      case 'Partially Deployed': 
        return "#2880DC";
      case 'Active Campaign':
        return "#D6089E";
      case 'Shelfware':
        return "#FFA416";
      case 'Competitive Loss':
        return "#FE3333";
      case 'White Space':
        return "#222222";
      default:
        return "#000";
    }
  }
  componentDidMount() {
    let currentStatus = isEmpty(this.props.status)
      ? "No Status"
      : this.props.status.statusLabel;
    let menuClassName = currentStatus
      .split(" ")
      .join("-")
      .toLowerCase();
    this.setState({
      currentStatus,
      menuClassName
    });
  }

  render() {
    const { product, status, statusMenu } = this.props;
    const dropdownStyle = {
      width: "400px"
    };
    if (isEmpty(status)) {
      status.statusLabel = "No Status";
    }
    return (
      <div className={"iot-element " + this.state.menuClassName}>
        {product.productLabel}
        <Select
          defaultValue={this.state.currentStatus}
          style={{ width: "min-content" }}
          onChange={(e)=>this.menuChange(e)}
          dropdownMatchSelectWidth={false}
          // open={true}
          getPopupContainer={node => node.parentNode}
          // dropdownMenuStyle={dropdownStyle}
          dropdownStyle={dropdownStyle}
          value={this.state.currentStatus}
          onDropdownVisibleChange={this.showStatusMenu}
        >
          <Option className="deployment-status-header" value="Deployment Status" disabled={true}>Deployment Status</Option>
          {statusMenu.map((statusObj, i) => {
            return (
              <Option key={i} value={statusObj.statusLabel} className="option-tab" style={{color: statusObj.statusColor}}>
                <div
                  className="deployment-status-wrapper"
                  style={{ cursor: "pointer" }}
                >
                  {
                    <span
                      className="deployment-status-selector-1"
                      style={{ background: this.getColorById(statusObj.statusLabel) }}
                    />
                  }
                  <span className="title-status">{statusObj.statusLabel}</span>
                  {
                    <span className="subtitle-status">
                      {statusObj.statusDescription}
                    </span>
                  }
                </div>
              </Option>
            );
          })}
          <Option className="no-status-btn" value="No Status">
            No Status
          </Option>
        </Select>
      </div>
    );
  }
}

FWComponents.propTypes = {
  product: PropTypes.object,
  status: PropTypes.object,
  statusMenu: PropTypes.array
};

FWComponents.defaultProps = {
  product: {},
  status: {},
  statusMenu: []
};
export default FWComponents;

import React, { Component } from 'react';
//import PropTypes from "prop-types";
import '../MainContent.scss';
import './Footprint.scss';
import { Layout, Icon, Collapse, Popover, Input } from 'antd';
const { TextArea } = Input;
const { Content } = Layout;
import VmFloatingInput from '../../../common/VmFloatingInput/VmFloatingInput';
import StackedBarChrt from '../../../common/Charts/StackedBarChart/StackedBarChrt';
import FootprintData from '../../../../constants/json/Footprint';
const Panel = Collapse.Panel;

export default class Footprint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        const content = <div>
            <div>
                <sapn>John Smith</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Megan Cole</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
            <div>
                <sapn>Ruby Dasmond</sapn>
                <Icon type="close-circle" style={{ color: '#0375b7' }} />
            </div>
        </div>
        const tagContent = <div className="tag-content">
            <Input
                placeholder="Type Name/E-mail ID"
                prefix={<Icon type="plus-circle-o" style={{ color: '#d8d8d8' }} />}
            // suffix={<Icon type="close-circle"/>}
            />
            <div className="no-tag"> No team member tagged</div>
            <div className="select-section">
                <span className="section-txt">Select Sections</span>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>By Product Group</span>
                </div>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>By Product Class</span>
                </div>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>Spend History: ELA & Transaction Purchases</span>
                </div>
                <div className="sub-sectn-div">
                    <Icon type="check-circle-o" />
                    <span>Future Pipeline: By Product Group</span>
                </div>
            </div>
            <TextArea placeholder="Type your comment" className="comment" rows={4} />
            <div className="notify-btn">
                <span className="notify">Notify</span>
            </div>
        </div>
        return (
            <div className="footprint">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <div className="menu-selected">Footprint</div>
                        <div className="submenu-tag-info">
                            <span className="submenu-selected">VMware Bookings</span>
                            <Popover placement="bottomRight" content={tagContent} trigger="click">
                                <span className="tag-team-membr-cont">
                                    <span className="tag-team-membr">Tag a Team Member</span>
                                    <Icon type="caret-down" theme="outlined" style={{ color: '#0375b7' }} />
                                </span>
                            </Popover>
                        </div>

                        <Collapse defaultActiveKey={['1']}>
                            <Panel header={<div className="collapse-main by-prod-grp">
                                <span className="collapse-header">By Product Group</span>
                                <span className="red-star">*</span>
                                <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover>
                            </div>} key="1">
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3 by-prod-grp-left">
                                            <div>
                                                <span className="footprint-yr">FY14</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vcan"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY15</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vcan"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY16</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vcan"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY17</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vcan"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 by-prod-grp-stacked">
                                        <StackedBarChrt
                                            barSize={40}
                                            width={450}
                                            data={FootprintData.byProdGrpData}
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={FootprintData.byProdGrpbarBackgrnd}
                                        />
                                    </div>
                                </div>

                            </Panel>
                        </Collapse>

                        <Collapse className="collapse-margin">
                            <Panel header={<div className="collapse-main">
                                <span className="collapse-header">By Product Class</span>
                                <span className="red-star">*</span>
                                <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover>
                            </div>} key="2">
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY14</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="PSO"
                                            />
                                            <VmFloatingInput
                                                placeholder="SNS"
                                            />
                                            <VmFloatingInput
                                                placeholder="Licence"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY15</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="PSO"
                                            />
                                            <VmFloatingInput
                                                placeholder="SNS"
                                            />
                                            <VmFloatingInput
                                                placeholder="Licence"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY16</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="PSO"
                                            />
                                            <VmFloatingInput
                                                placeholder="SNS"
                                            />
                                            <VmFloatingInput
                                                placeholder="Licence"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY17</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="PSO"
                                            />
                                            <VmFloatingInput
                                                placeholder="SNS"
                                            />
                                            <VmFloatingInput
                                                placeholder="Licence"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 by-prod-class-stacked">
                                        <StackedBarChrt
                                            barSize={40}
                                            width={450}
                                            data={FootprintData.byProdClassData}
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={FootprintData.byProdClassbarBackgrnd}
                                        />
                                    </div>
                                </div>

                            </Panel>
                        </Collapse>

                        <Collapse className="collapse-margin">
                            <Panel header={<div className="collapse-main">
                                <span className="collapse-header">Spend History: ELA and Transaction Purchases</span>
                                <span className="red-star">*</span>
                                <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover>
                            </div>} key="3">
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY12</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Transaction"
                                            />
                                            <VmFloatingInput
                                                placeholder="ELA"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY13</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Transaction"
                                            />
                                            <VmFloatingInput
                                                placeholder="ELA"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY14</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Transaction"
                                            />
                                            <VmFloatingInput
                                                placeholder="ELA"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">FY15</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Transaction"
                                            />
                                            <VmFloatingInput
                                                placeholder="ELA"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 ELA-trans-purchase-stacked">
                                        <StackedBarChrt
                                            barSize={40}
                                            width={450}
                                            data={FootprintData.ELAtransPurchaseData}
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={FootprintData.ELAtransPurchaseBackgrnd}
                                        />
                                    </div>
                                </div>

                            </Panel>
                        </Collapse>

                        <Collapse className="collapse-margin">
                            <Panel header={<div className="collapse-main">
                                <span className="collapse-header">Future Pipeline: by Product Group</span>
                                <span className="red-star">*</span>
                                <span className="collapse-txt">Last updated by John Smith on Aug 11,2017</span>
                                <Popover placement="leftTop" content={content} title="Currently Tagged:">
                                    <span className="info-icon">
                                        <Icon type="info-circle-o" style={{ color: '#007cbb' }} />
                                    </span>
                                </Popover>
                            </div>} key="4">
                                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">Q4'18</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Cloud"
                                            />
                                            <VmFloatingInput
                                                placeholder="Service"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">Q1'19</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Cloud"
                                            />
                                            <VmFloatingInput
                                                placeholder="Service"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">Q2'19</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Cloud"
                                            />
                                            <VmFloatingInput
                                                placeholder="Service"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                        <div className="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <div>
                                                <span className="footprint-yr">Q3'19</span>
                                                <clr-icon shape="pencil" size="15" class="is-solid"></clr-icon>
                                            </div>
                                            <VmFloatingInput
                                                placeholder="Compute"
                                            />
                                            <VmFloatingInput
                                                placeholder="Cloud"
                                            />
                                            <VmFloatingInput
                                                placeholder="Service"
                                            />
                                            <VmFloatingInput
                                                placeholder="Desktop"
                                            />
                                            <VmFloatingInput
                                                placeholder="Mobile"
                                            />
                                            <VmFloatingInput
                                                placeholder="Vsan"
                                            />
                                            <VmFloatingInput
                                                placeholder="NSX"
                                            />
                                            <VmFloatingInput
                                                placeholder="MGMT"
                                            />
                                            <VmFloatingInput
                                                placeholder="Others"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6 future-pipeline-stacked">
                                        <StackedBarChrt
                                            barSize={20}
                                            width={450}
                                            data={FootprintData.futurePipelineData}
                                            xAxisLabel="FINANCIAL YEAR"
                                            yAxisLabel="USD"
                                            barBackgound={FootprintData.futurePipelineBackgrnd}
                                        />
                                    </div>
                                </div>

                            </Panel>
                        </Collapse>


                    </Content>
                </Layout>
            </div>
        );
    }
};


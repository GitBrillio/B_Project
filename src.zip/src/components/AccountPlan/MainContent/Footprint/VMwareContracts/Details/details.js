import React,{Component} from 'react';
import './details.scss';
import arrow  from './arrow-key.png';
import { Row, Col, Icon} from 'antd';
import Input from 'muicss/lib/react/input';

class Details extends Component{
    render(){
        return(
                <div className="details-cont">
                    <section className="details-sec">
                        <Row className="div-style">
                            <p className="para-style">4565346456 <img src={arrow}/></p> 
                        </Row>
                        <Row className ="details-body">
                            <Col span={15} className="padding0">
                                <p className="heading-style">Opportunity Name</p>
                                <p className="regular-font">Luctus molestie auam neque</p>
                            </Col>
                            <Col span={3} className="align-right padding0">
                                <p className="heading-style">Status</p>
                                <p className="regular-font">closing 18Q4</p>
                            </Col>
                            <Col span={4} className="align-right padding0">
                                <p className="heading-style">Contract Period</p>
                                <p className="regular-font">30 Mar,15 – 31 Dec,17</p>
                            </Col>
                            <Col span={2} className="align-right padding0">
                                <p className="heading-style">ELA</p>
                                <p className="regular-font">No</p>
                            </Col>
                        </Row>
                        <Row className="product-main">
                                <div className="left-product">
                                    <p className="heading-style">Products</p>
                                    <div className="product-list">
                                        <span>vCloud Suite STD</span>
                                        <span>NSX</span>
                                        <span>EPP Tokens</span>
                                    </div>
                                </div>
                                <div className="right-product">
                                    <span>Deal Value: </span>
                                    <span className="semi-bold-font"> $ 1.2M</span>
                                </div>
                        </Row>
                        <Row className="add-scope">
                            <button>+ Add Scope of Renewal Opportunity</button>
                            <div className="scope-body">
                                <Input 
                                    //placeholder="Scope of Renewal Opportunity"
                                    label={"Scope of Renewal Opportunity"}
                                    //value={""} 
                                    floatingLabel={true} 
                                    //onChange={(e)=>actions.changeSystem(e.target.value,systemIndex,type)}
                                    //onBlur={()=>actions.updateSystem(system,systemIndex,type)}
                                />
                                <div className="delete-icon" >
                                    <Icon className="minus-circle" type="minus-circle-o" />
                                </div> 
                            </div>
                        </Row>
                    </section>
                </div>
                
        )
    }
}

export default Details;
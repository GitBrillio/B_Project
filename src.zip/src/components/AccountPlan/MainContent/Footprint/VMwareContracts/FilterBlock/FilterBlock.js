import React,{Component} from 'react';
import { Slider,Row, Col,DatePicker,Select} from 'antd'; //Input
import './filter-block.scss';
import PropTypes from 'prop-types';
import close from './Close.png';
const { RangePicker } = DatePicker;
const Option = Select.Option;
//import CustomDropdown from '../CustomDropdown/CustomDropdown';
import CustomDropdown from '../../../../../common/customDropdown/CustomDropdown';
//import data from '../../../../../../constants/json/data.js';
import { CheckboxDataArray,CheckboxDataObject,CheckedboxLabelData } from "../../../../../../Services/CheckboxData";
import {cloneDeep} from 'lodash';

var val1=['stage1','stage2','stage3','stage4','stage5'];
var val2=['MGMT','NSX','vSAN','VCF','Mobile','Desktop'];

const marks={
    0:'250k',
    100:'2M'
}
 
class FilterBlock extends Component{
    state={
        dropdownStage: CheckboxDataArray(val1),
        dropdownProduct: CheckboxDataArray(val2),
        labelsStage:[],
        labelsProduct:[]
    }
    onChangeCheckbox(e,i,val,title){
        let checkedBox = cloneDeep(val);
        checkedBox[i].status = e.target.checked;
        switch(title){
            case "STAGE" :
                        this.setState({ dropdownStage: checkedBox });
                        this.setState({ labelsStage : CheckedboxLabelData(checkedBox)});
                        break;
            case "PRODUCT" :
                        this.setState({ dropdownProduct: checkedBox });
                        this.setState({ labelsProduct : CheckedboxLabelData(checkedBox)});
                        break;
            default:
                        break;
        }
    }
    onChange(date, dateString) {
        console.log(date, dateString);
    }
    render(){
            return(
                    <Row gutter={20} className="filter">
                        <Col span={5} className="contract-period-main">
                            <label className="label-style">CONTRACT PERIOD</label>
                            <RangePicker className="contract-period-select"
                                placeholder = {["From..","To.."]}
                                onChange={this.onChange} 
                            />
                        </Col>
                        <Col span={6} className="stage-main">
                            <CustomDropdown 
                                title="STAGE" 
                                val={this.state.dropdownStage} 
                                selectedCheckboxes = { this.state.labelsStage}
                                placeholder="Select Stage"
                                onChange={(e,key,val,title) => this.onChangeCheckbox(e,key,val,title)}
                                // onChange={(e,key,val,title)=>{
                                //     this.props.actions.onChangeCheckbox(e,key,val,title)
                                // }} 
                            />
                        </Col>
                        <Col span={6} className="product-main">
                            <CustomDropdown 
                                title="PRODUCT" 
                                val={this.state.dropdownProduct} 
                                selectedCheckboxes = { this.state.labelsProduct}
                                placeholder="Select Product"
                                onChange={(e,key,val,title) => this.onChangeCheckbox(e,key,val,title)}
                            />  
                        </Col>
                        <Col span={2} className="ela-main">
                            <label className="label-style">ELA</label>
                            <Select className="ELA-select" placeholder="Select" labelInValue>
                                <Option value="yes">Yes</Option>
                                <Option value="no">No</Option>
                            </Select>
                        </Col>
                        <Col span={4} className="range-main">
                            <p className="label-style">DEAL RANGE</p>
                            <Slider range marks={marks} defaultValue={[0,100]} />
                        </Col>
                        <Col span={1} className="close-icon">
                            <img src={close} onClick = {()=>this.props.handlefilterStatus(false)} />
                        </Col>
                    </Row>
            )
        }
}
FilterBlock.propTypes = {
    handlefilterStatus: PropTypes.func
}

export default FilterBlock;
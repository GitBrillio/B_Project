import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button} from 'antd';
import './contract-modal.scss';
import ContractModalBlock from './ContractModalBlock/ContractModalBlock';

class ContractModal extends Component {
    render = () => {
        const { visible,heading,okText,handleCancel} = this.props
      
        return (
            <div className="contract-modal-main">
                <Modal
                    className="contract-modal"
                    title={heading}
                    visible={visible}
                    centered
                    onCancel={handleCancel}
                    footer={[
                        <Button key="submit" className="pull-right" type="primary" onClick={this.props.create}>
                            {okText} 
                        </Button>,
                        <Button key="submit" className="delete-btn" type="danger" onClick={this.props.delete}>
                            Delete
                        </Button>,
                    ]}
                >
                    <ContractModalBlock 
                        //actions={this.props.actions} 
                        //ambition={this.props.ambition}
                        //index= {this.props.index}
                        //strategyReducer = {this.props.strategyReducer}
                        //accountPlanId={this.props.accountPlanId}
                    />
                </Modal>
        </div>)
    }
}

ContractModal.propTypes = {
    visible: PropTypes.bool.isRequired,
    heading:PropTypes.string,
    okText: PropTypes.string,  
    handleCancel: PropTypes.func,
    create: PropTypes.func,
    delete: PropTypes.func
}

export default ContractModal;

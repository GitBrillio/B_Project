import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Row, Col,Icon,DatePicker } from 'antd';
const { RangePicker } = DatePicker;
import Input from 'muicss/lib/react/input';
import './contract-modal-block.scss';
import { CheckboxData,CheckedboxLabelData } from "../../../../../../../Services/CheckboxData";
import CustomDropdown from "../../../../../../common/customDropdown/CustomDropdown";
import {cloneDeep} from 'lodash';

var products=['VCPP','COMPUTE','STORAGE & AVAILABILITY','DESKTOP','EMERGING SOLUTIONS','VMC ON AWS','MOBILE','NETWORK & SECURITY','VERTUALIZE MANAGEMENT','WORKSPACE ONE','SDDC SOLUTIONS','PREMIER SERVICES','CLOUD NATIVE APPS','SERVICES','Others'];

class ContractModalBlock extends Component {
    state={
        dropdownProduct: CheckboxData(products),
        labelsProduct:[]
    }
    onChangeCheckbox(e,i,val,title){
        let checkedBox = cloneDeep(val);
        checkedBox[i].status = e.target.checked;
        switch(title){
            case "PRODUCT" :
                        this.setState({ dropdownProduct: checkedBox });
                        this.setState({ labelsProduct : CheckedboxLabelData(checkedBox)});
                        break;
            default:
                        break;
        }
    }
    onChange(date, dateString) {
        console.log(date, dateString);
    }
    render = () => {
        return (
        <div className="contract-modal-block-main">
            <Row gutter={16} className="contract-block-main">
                <Col className="gutter-row" span={13}>
                    <Input 
                        label={"Opportunity ID"}
                        //placeholder={"Opportunity ID"}
                        floatingLabel={true}
                        //value ={this.getKeyTheme()}
                        // onChange={(e)=>{
                        //     this.props.actions.changeKeyTheme(e.target.value,this.props.index)
                        // }}    
                    />
                </Col>
                <Col className="gutter-row" span={4}>
                    <Input 
                        label={"Status"}
                        //placeholder={"Status"}
                        floatingLabel={true}
                        // value ={this.getKeyTheme()}
                        // onChange={(e)=>{
                        //     this.props.actions.changeKeyTheme(e.target.value,this.props.index)
                        // }}    
                    />
                </Col>
                <Col className="gutter-row contract-period-main" span={5} >
                    <label className="label-style">CONTRACT PERIOD</label>
                    <RangePicker className="contract-period-select"
                        placeholder = {["From..","To.."]}
                        onChange={this.onChange} 
                    />
                </Col>
                <Col className="gutter-row" span={2}>
                    <Input
                        label={"ELA"}
                        //placeholder={"ELA"}
                        floatingLabel={true} 
                        // value ={this.getTargetValue()}
                        // //onChange={(e)=>this.props.actions.changeTargetValue(e.target.value,this.props.index)}
                        // onChange={(e)=>this.TargetValueCheck(e)}
                    />
                </Col>
            </Row>
            <Row gutter={16} className="contract-block-row-2">
                <Col className="gutter-row" span={21}>
                    <Input 
                        label={"Opportunity Name"}
                        floatingLabel={true}
                    />
                </Col>
                <Col className="gutter-row" span={3}>
                    <Input 
                        label={"Deal Value (USD)"}
                        floatingLabel={true}
                    />
                </Col>
            </Row>
            <Row gutter={16} className="contract-block-row-3">
                <Col className="gutter-row" span={24}>
                    <CustomDropdown 
                        class="custom-dropdown custom-grid-dropdown"
                        title="PRODUCT" 
                        val={this.state.dropdownProduct} 
                        selectedCheckboxes = { this.state.labelsProduct}
                        placeholder="Select Product"
                        onChange={(e,key,val,title) => this.onChangeCheckbox(e,key,val,title)}
                    />  
                </Col>
            </Row>
            <div className="add-custom-contract">
                <button>+ Add Scope of Renewal Opportunity</button>
                <div className="scope-body">
                    <Input 
                        label={"Scope of Renewal Opportunity"}
                        //value={""} 
                        floatingLabel={true} 
                    />
                    <div className="delete-icon" >
                        <Icon className="minus-circle" type="minus-circle-o" />
                    </div> 
                </div>
            </div>
        </div> 
        )
    }
}

ContractModalBlock.propTypes = {
    actions: PropTypes.object,
    strategyReducer: PropTypes.object,
    ambition: PropTypes.any,
    index: PropTypes.any
}

export default ContractModalBlock;
import React, { Component } from 'react';
import { Layout,Icon,Row,Col } from 'antd';
// import PropTypes from 'prop-types';
import './VMware-contracts.scss';
const { Content } = Layout;
import Filter from './filter.png';
import Details from './Details/details';
import ContractModal from './ContractModal/ContractModal';
import FilterBlock from './FilterBlock/FilterBlock';

class VMwareContracts extends Component{
    constructor(props) {
        super(props);
    }
    state = {
        newContractModal: false,
        filterStatus: false
    }
    createContract(){
        this.setState({ newContractModal: false });
    }
    deleteContract(){
        this.setState({ newContractModal: false });
    }
    newContractModalCancel() {
        this.setState({
            newContractModal: false
        });
    }
    filterOpenOrClosed(val){
        this.setState({filterStatus:val})
    }
    render = () =>{
        return (
            <section className="vmware-contracts">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3 className="h3-style">Footprint</h3>
                        <h1>VMware Contracts</h1>
                        <Row className="vmware-contracts-sel-cont">
                            <Col xs={{ span: 5 }} lg={{ span: 5}}>
                                <div className="new-contract-btn text-center">
                                    <button className="new-contract-sub-btn" onClick={()=>this.setState({newContractModal:true})}>Create New Contract</button>
                                </div>
                            </Col>
                            <Col xs={{ span: 5 }} lg={{ span: 5 }}>
                                <div className="search">
                                    <Icon className="icon-style" type="search" size={32}/>
                                    <input type="text" placeholder="Search Contracts"/>
                                </div>
                            </Col>
                            <Col xs={{ span: 14}} lg={{ span: 14}}>
                                <button className="filter-btn" onClick={()=>this.setState({filterStatus:true})}>
                                    <img src={Filter} width="14px"/><span>Filter</span>
                                </button>
                            </Col>
                        </Row>
                        {
                            this.state.filterStatus && 
                            <FilterBlock handlefilterStatus={(data)=>this.filterOpenOrClosed(data)}/>
                        }
                        <ContractModal
                            visible={this.state.newContractModal}
                            heading = { "Create New Contract" }
                            create = {()=>this.createContract()}
                            delete = {()=>this.deleteContract()}
                            okText="Create"
                            handleCancel={() => this.newContractModalCancel()}
                        />
                        <Details />
                        <Details />
                        <Details />
                        <Details />
                    </Content>
                </Layout>
            </section>
        )
    }
}

VMwareContracts.propTypes = {
}

export default VMwareContracts;

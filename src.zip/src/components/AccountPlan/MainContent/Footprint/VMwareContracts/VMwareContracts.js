import React, { Component } from 'react';
import { Layout,Icon } from 'antd';
// import PropTypes from 'prop-types';
import './VMware-contracts.scss';
const { Content } = Layout;

class VMwareContracts extends Component{
   
    render = () =>{
        return (
            <section className="vmware-contracts">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3 className="h3-style">Footprint</h3>
                        <h1>VMware Contracts</h1>
                        <div className="new-contract-sel-cont">
                            <div className="new-contract-btn text-center">
                                <button className="new-contract-sub-btn">Create New Contract</button>
                            </div>
                            <div className="search">
                                <Icon className="icon-style" type="search" size={32}/>
                                <input type="text" placeholder="Search Contracts"/>
                            </div>
                            
                        </div>
                    </Content>
                </Layout>
                
            </section>
        )
    }
}

VMwareContracts.propTypes = {
}

export default VMwareContracts;

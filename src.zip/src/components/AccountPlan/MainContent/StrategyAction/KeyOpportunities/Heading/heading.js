import React,{ Component } from 'react';
import './heading.scss';
import PropTypes from 'prop-types';

class Heading extends Component{
    render(){
        return(
                <div className="p-18">
                    <h4 className="headstyle">{this.props.headerText}</h4>
                </div>
        )
    }
}
Heading.propTypes = {
    headerText : PropTypes.string
}
export default Heading;
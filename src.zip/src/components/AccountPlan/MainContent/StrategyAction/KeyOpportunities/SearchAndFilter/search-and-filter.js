import React,{Component} from 'react';
import './search-and-filter.scss';
import filter  from './filter.png';
import { Icon } from 'antd';
import PropTypes from 'prop-types';
import Filter from './Filter/filter';

class SearchAndFilter extends Component{
    state={
        filterStatus:false,
    }
    filterOpenOrClosed(val){
        this.setState({filterStatus:val})
    }
    show=()=>{
        this.setState({
            filterStatus:true
        })
    }
    render(){
        return( 
                <div className="search">
                    <Icon className="icon-style" type="search" size={32}/>
                    <input type="text" placeholder="Search Opportunities"/>
                    <button className="button" onClick={this.show}><img src={filter} width="14px"/>Filter</button>
                    {
                        this.state.filterStatus && 
                        this.props.keyOpportunitiesReducer && <Filter 
                            actions={this.props.actions}
                            handlefilterStatus={(data)=>this.filterOpenOrClosed(data)}
                            keyOpportunitiesReducer = {this.props.keyOpportunitiesReducer}
                        />
                    }
                </div>
           
        )
    }
}
SearchAndFilter.propTypes = {
    actions: PropTypes.object,
    keyOpportunitiesReducer: PropTypes.object
}
export default SearchAndFilter;
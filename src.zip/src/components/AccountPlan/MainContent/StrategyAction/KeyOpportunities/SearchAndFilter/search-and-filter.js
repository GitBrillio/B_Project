import React,{Component} from 'react';
import './search-and-filter.scss';
import filter  from './filter.png';
import { Icon } from 'antd';
import PropTypes from 'prop-types';
import Filter from './Filter/filter';

class SearchAndFilter extends Component{
    state={
        filterStatus:false,
    }
    filterOpenOrClosed(val){
        this.setState({filterStatus:val})
    }
    show=()=>{
        this.setState({
            filterStatus:true
        })
    }
    // close=()=>{
    //     this.setState({
    //         on:false
    //     });
    // }
    render(){
        return( 
                <div className="search">
                    <Icon className="icon-style" type="search" size={32}/>
                    <input type="text" placeholder="Search Opportunities"/>
                    <button className="button" onClick={this.show}><img src={filter} width="14px"/>Filter</button>
                    {
                        this.state.filterStatus && 
                        <Filter handlefilterStatus={(data)=>this.filterOpenOrClosed(data)}/>
                    }
                </div>
           
        )
    }
}
SearchAndFilter.propTypes = {
}
export default SearchAndFilter;
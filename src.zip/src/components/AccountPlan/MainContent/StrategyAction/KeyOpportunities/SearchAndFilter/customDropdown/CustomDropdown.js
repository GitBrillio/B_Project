import React,{Component} from 'react';
import './custom-dropdown.scss';
import { Checkbox,Icon } from 'antd';
import Input from 'muicss/lib/react/input';
import PropTypes from 'prop-types';

class CustomDropdown extends Component{
    state={
        showMenu :false,
    }
    componentWillMount() {
        window.addEventListener("click", this.handleClickOutside.bind(this));
      }
    
      componentWillUnmount() {
        window.removeEventListener("click", this.handleClickOutside.bind(this));
      }
    handleClickOutside(e) {
        if (
          !e.target.closest(".custom-dropdown")
        ) {
          this.setState({
            showMenu: false
          });
        }
      }

    //   setCheckedFalse(product){
    //     this.product
    //     this.state.arr.product =false
    //     console.log(this.state.arr)
    //     return this.state.arr.product
    //   }
    render(){
        return( 

                <div className="custom-dropdown">
                    <Icon type="down" className="dropdown-icon"  onClick={() => this.setState({ showMenu: !this.state.showMenu })}/>
                    <Input 
                        className="custom-dropdown-input"
                        label={this.props.title}
                        floatingLabel={true} 
                        value={this.props.placeholder}
                        onClick={() => this.setState({ showMenu: !this.state.showMenu })}
                    />
                    {this.state.showMenu &&
                        <div className="menu custom-scroll">
                            {
                                this.props.val.map((product, key) => {
                                    return (
                                        <Checkbox
                                            key={key}
                                            //val= {this.state.arr.product}
                                           // checked={this.setCheckedFalse(product,index)}
                                            value={product}
                                            // onChange={e => this.productChange(e)}
                                        >
                                            {product}
                                        </Checkbox>
                                    );
                                })
                            }
                        </div>
                    }
                </div>
           
        )
    }
}
CustomDropdown.propTypes = {
    title : PropTypes.string,
    val:PropTypes.array,
    placeholder:PropTypes.string
}
export default CustomDropdown;
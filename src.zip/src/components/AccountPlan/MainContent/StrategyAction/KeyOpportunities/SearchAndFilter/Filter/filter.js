import React,{Component} from 'react';
import { Slider,Row, Col} from 'antd'; //Input
import './filter.scss';
import PropTypes from 'prop-types';
import close from './Close.png';
import CustomDropdown from '../customDropdown/CustomDropdown';

var val1=['Quarter1','Quarter2','Quarter2','Quarter2','Quarter2'];
var val2=['Quarter1','Quarter2','Quarter2','Quarter2','Quarter2'];
var val3=['MGMT','NSX','vSAN','VCF','Mobile','Desktop'];
var val4=['Quarter1','Quarter2','Quarter2','Quarter2','Quarter2'];
const marks={
    0:'250k',
    100:'2M'
}
class Filter extends Component{
    
     render(){
            return(
                    <Row gutter={20} className="filter p-t-10">
                        <Col span={4}>
                            <CustomDropdown title="QUARTER" val={val1} placeholder="Select Quarter"/>
                        </Col>
                        <Col span={4}>
                            <CustomDropdown title="STAGE" val={val2} placeholder="Select Stage"/>
                        </Col>
                        <Col span={4}>
                            <CustomDropdown title="PRODUCT" val={val3} placeholder="Select Product"/>
                        </Col>
                        <Col span={4}>
                            <CustomDropdown title="EVP" val={val4} placeholder="Select"/>
                        </Col>
                        <Col span={4}>
                            <p className="label-style">DEAL RANGE</p>
                            <Slider range marks={marks} defaultValue={[0,100]} />
                        </Col>
                        <Col span={4} className="close-icon">
                            <img src={close} onClick = {()=>this.props.handlefilterStatus(false)} />
                        </Col>
                    </Row>
            )
        }
}
Filter.propTypes = {
    handlefilterStatus: PropTypes.func
}

export default Filter;
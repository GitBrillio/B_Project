import React,{Component} from 'react';
import './details.scss';
import arrow  from './arrow-key.png';
import { Row, Col} from 'antd';

class Details extends Component{
    render(){
        return(
                <section className="details">
                    <Row className="div-style">
                        <p className="para-style">4565346456 <img src={arrow}/></p> 
                    </Row>
                    <Row className ="p-15 f-s-15">
                    <Col span={18} className="padding0">
                            <p className="heading-style">Name</p>
                            <p>Phasellus in volutpat odio</p>
                        </Col>
                        <Col span={2} className="align-right padding0">
                            <p className="heading-style">eVP</p>
                            <p>No</p>
                        </Col>
                        <Col span={2} className="align-right padding0">
                            <p className="heading-style">Target Quarter</p>
                            <p>Q2 - 18</p>
                        </Col>
                        <Col span={2} className="align-right padding0">
                            <p className="heading-style">Sales Stage</p>
                            <p>Open</p>
                        </Col>
                        </Row>
                        <Row className="p-l-15 f-s-15">
                        <p className="heading-style">Description</p>
                        <p>Etiam tempor convallis mollis. Nam aliquet quam dui, sit amet suscipit </p>
                        </Row>
                        <Row className="p-15 f-s-13">
                        <Col span={3} className="mgmt">
                            <p className="font-family">MGMT</p>
                            <p>$ 20.2k</p>
                        </Col>
                        <Col span={3} className="nsx">
                            <p className="font-family">NSX</p>
                            <p>$ 56.9k</p>
                        </Col>
                        <Col span={15} className="vmc">
                            <p className="font-family">VMC on AWS</p>
                            <p className="p-l-20">$ 39.2K</p>
                        </Col>
                        <Col span={3} className="total">
                            <p className="font-family">Total</p>
                            <p>$ 1.2M</p>
                        </Col>
                        </Row>
                </section>
        )
    }
}

export default Details;
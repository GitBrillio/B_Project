import React,{Component} from 'react';
import { Collapse,Row } from 'antd'; //Input
import { BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import './overallview.scss';
const Panel = Collapse.Panel;
const data = [
      {name: 'MGMT',pv: 2400},
      {name: 'NSX', pv: 1398},
      {name: 'vSAN', pv: 9800},
      {name: 'VCF', pv: 3908},
      {name: 'Mobile', pv: 4800},
      {name: 'Desk-top', pv: 4300},
      {name: 'PSO', pv: 4300},
      {name: 'Other', pv: 4300},
];
class OverallView extends Component{
    render(){
        return(
            <Collapse defaultActiveKey={['1']} className="wrapper">
            <Panel header={<div className="collapse-main">
                <span className="collapse-header">Overall View</span>
                
            </div>}key='1'>
                <section>
                    <Row className="bar-area">
                            <BarChart width={window.screen.width - document.querySelector(".left-navbar").scrollWidth - 100} height={300} data={data}
                            margin={{top: 5, right: 30, left: 20, bottom: 5}}>
                            <CartesianGrid vertical={false}
                            stroke="#ebf3f0"/>
                            <XAxis dataKey="name"/>
                            <YAxis axisLine={false}/>
                            <Bar dataKey="pv" fill="#8075C8" barSize={20} radius={[20,20,20,20]}/>
                            </BarChart>
                    </Row>
                  
                    
                </section>
            </Panel>
        </Collapse>
        )
    }
}

export default OverallView;
import React,{Component} from 'react';
import { Collapse,Row } from 'antd'; //Input
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Cell,Legend } from 'recharts';
import './overallview.scss';
import PropTypes from 'prop-types';
import { graphLegendData, graphData } from "../../../../../../Services/graphData"
const Panel = Collapse.Panel;
// const data = [
//         {name: 'VCPP',pv: 2400},
//         {name: 'Desktop', pv: 1398},
//         {name: 'Mobile', pv: 3908},
//         {name: 'Workspace One', pv: 4800},
//         {name: 'Cloud Native Apps', pv: 4300},
//         {name: 'Emerging Solutions', pv: 4300},
//         {name: 'Compute',pv: 2400},
//         {name: 'Networking & Security', pv: 1398},
//         {name: 'SDDC Solutions', pv: 9800},
//         {name: 'Services', pv: 3908},
//         {name: 'Storage & Availabilty', pv: 4800},
//         {name: 'VMC on AWS One', pv: 4300},
//         {name: 'Vrealize Management', pv: 4300},
//         {name: 'Premier Services', pv: 4300},
//         {name: 'Other', pv: 4300},
// ];
const colors = ["#F2519B", "#A062FF", "#75B6C8", "#FFDB00", "#CD895D", "#DE52DB", "#54AEFF", "#FF7587", "#FFB1E8", "#8075C8", "#54AEFF", "#00EBFF", "#6BC764", "#2C964C", "#A1A1A1"];
// let coloredArray=[]
// let stylesXAxis = map(colors,(data)=>{
//     <span></span>
// })
class OverallView extends Component{
    render(){
        return(
            <Collapse defaultActiveKey={['1']} className="wrapper">
            <Panel header={<div className="collapse-main">
                <span className="collapse-header">Overall View</span>
                
            </div>}key='1'>
                <section>
                    <Row className="bar-area">
                        <BarChart 
                                width={window.screen.width - document.querySelector(".left-navbar").scrollWidth} 
                                height={300} 
                                data={graphData(this.props.opportunitiesGraph)}
                                margin={{top: 5, right: 10, left: 20, bottom: 20}}>
                            <CartesianGrid 
                                vertical={false}
                                stroke="#ebf3f0"
                            />
                            <XAxis dataKey="name"/>
                            <YAxis axisLine={false}/>
                            {/* <Bar dataKey="pv" fill="#8075C8" label={{ position: 'top' }} barSize={20} radius={[20,20,20,20]}/> */}
                            <Bar dataKey="pv" fill="#8075C8" barSize={10} radius={[8,8,0,0]}>
                                {
                                    graphData(this.props.opportunitiesGraph).map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={colors[index % 20]}/>
                                    ))
                                }
                            </Bar>

                                {/* {
                                    data.map((entry, index) => (
                                        <Bar dataKey={entry.name} key={`cell-${index}`} fill={colors[index % 20]} barSize={10} radius={[8,8,0,0]}></Bar>
                                    ))
                                } */}
                            {/* <Legend iconType="circle" iconSize="10" /> */}
                            
                                <Legend content={
                                    <ul style={{listStyleType: "none"}}>
                                    {
                                        // [{label:"a",color:"red"},{label:"b",color:"green"},{label:"c",color:"blue"},{label:"d",color:"yellow"}].map((entry, index) => (
                                        // <li key={`item-${index}`} style={{display:"inline-block",marginLeft:"25px"}}><div style={{width:"10px",height:"10px",backgroundColor: entry.color ,borderRadius:"50%",display: "inline-block"}}></div><span style={{marginLeft:"5px"}}>{entry.label}</span></li>
                                        // ))
                                        graphLegendData(graphData(this.props.opportunitiesGraph),colors).map((entry, index) => (
                                            <li key={`item-${index}`} style={{display:"inline-block",marginLeft:"25px"}}><div style={{width:"10px",height:"10px",backgroundColor: entry.color ,borderRadius:"50%",display: "inline-block"}}></div><span style={{marginLeft:"5px"}}>{entry.label}</span></li>
                                            ))
                                    }
                                    </ul>
                                } />
                        </BarChart>

                    </Row>
                </section>
            </Panel>
        </Collapse>
        )
    }
}
OverallView.propTypes = {
    opportunitiesGraph: PropTypes.object
}
export default OverallView;
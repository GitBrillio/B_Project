import React, { Component } from 'react';
import { Layout } from 'antd';
// import PropTypes from 'prop-types';
import './key-opportunities.scss';
import OverallView from './OverallView/overallview';
import Heading from './Heading/heading';
import Details from './Details/details';
import SearchAndFilter from './SearchAndFilter/search-and-filter';
const { Content } = Layout;

class KeyOpportunities extends Component{
   
    render = () =>{
        return (
            <section className="key-opportunities">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3 className="h3-style">Strategy & Actions</h3>
                        <h1>Key Opportunities</h1>
                        <SearchAndFilter/>
                        <OverallView />
                        <Heading headerText="Opportunities FY18" />
                        <Details />
                        <Details />
                        <Heading headerText="Opportunities FY19" />
                        <Details />
                    </Content>
                </Layout>
                
            </section>
        )
    }
}

KeyOpportunities.propTypes = {
}

export default KeyOpportunities;

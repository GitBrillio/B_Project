import React, { Component } from 'react';
import { Layout } from 'antd';
import PropTypes from 'prop-types';
import './key-opportunities.scss';
import OverallView from './OverallView/overallview';
import SearchAndFilter from './SearchAndFilter/search-and-filter';
import OpportunityDetails from './OpportunityDetails/OpportunityDetails';
const { Content } = Layout;

class KeyOpportunities extends Component{
    componentDidMount(){
        // make the action call
        this.props.actions.getQuarters();
        this.props.actions.getStage();
        this.props.actions.getProducts();
        this.props.actions.getGraphOpportunities("0018000000hoEG2AAM");
        this.props.actions.getOpportunitiesDetails("0018000000hoEG2AAM"); 
    }
    render = () =>{
        return (
            <section className="key-opportunities">
                <Layout>
                    <Content style={{ background: '#F3F9FB', padding: 24, margin: 0, minHeight: 280 }}>
                        <h3 className="h3-style">Strategy & Actions</h3>
                        <h1>Key Opportunities</h1>
                        {
                            
                                // this.props.strategyReducer.KeyOpportunities.opportunitiesGraph && this.props.strategyReducer.KeyOpportunities.opportunitiesDetails ?
                                    <div>
                                        {
                                            this.props.strategyReducer.KeyOpportunities.quarters && this.props.strategyReducer.KeyOpportunities.stage && this.props.strategyReducer.KeyOpportunities.products &&
                                                <SearchAndFilter 
                                                    actions={this.props.actions}
                                                    keyOpportunitiesReducer = {this.props.strategyReducer.KeyOpportunities}
                                                />
                                        }
                                        <OverallView 
                                            opportunitiesGraph = {this.props.strategyReducer.KeyOpportunities.opportunitiesGraph}
                                        />
                                        <OpportunityDetails 
                                            opportunitiesDetails = {this.props.strategyReducer.KeyOpportunities.opportunitiesDetails}
                                        />
                                    </div>
                                
                                // :
                                // <div style={{textAlign:'center',marginTop:'45px',fontFamily: 'Metropolis-Medium',fontSize: '14px', color: '#354E73'}}>There are no Opportunities associated with this account</div>

                        }
                        
                    </Content>
                </Layout>
                
            </section>
        )
    }
}

KeyOpportunities.propTypes = {
    strategyReducer: PropTypes.object,
    actions: PropTypes.object,
    accountId : PropTypes.string
}

export default KeyOpportunities;

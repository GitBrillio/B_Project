import React,{Component} from 'react';
import './details.scss';
import arrow  from './arrow-key.png';
import { Row, Col} from 'antd';
import PropTypes from 'prop-types';

class Details extends Component{
    render(){
        const {oppDetails} = this.props;
        return(
                <section className="details">
                    <Row className="div-style">
                        <p className="para-style"> {oppDetails.opportunityNo} <img src={arrow}/></p> 
                    </Row>
                    <Row className ="p-15 f-s-15">
                        <Col span={17} className="padding0">
                            <p className="heading-style">Name</p>
                            <p>{oppDetails.opportunityName}</p>
                        </Col>
                        <Col span={1} className="align-right padding0">
                            <p className="heading-style">eVP</p>
                            <p>{oppDetails.evpFlag ? "Yes" : "No"}</p>
                        </Col>
                        <Col span={3} className="align-right padding0">
                            <p className="heading-style">Target Quarter</p>
                            <p>{oppDetails.fiscalPeriod}</p>
                        </Col>
                        <Col span={3} className="align-right padding0">
                            <p className="heading-style">Sales Stage</p>
                            <p>{oppDetails.stageName}</p>
                        </Col>
                    </Row>
                    <Row className="p-l-15 f-s-15">
                        <p className="heading-style">Description</p>
                        <p>{oppDetails.description}</p>
                    </Row>
                    <Row className="p-15 f-s-13">
                        {
                            oppDetails.productDetails.map((val,i)=>
                                <Col span={3} className="mgmt" key={i}>
                                    <p className="font-family">{val.platformGroup}</p>
                                    <p>{"$" + val.totalPriceUsd}</p>
                                </Col>
                            )
                        } 
                        
                        {/* <Col span={3} className="nsx">
                            <p className="font-family">NSX</p>
                            <p>$ 56.9k</p>
                        </Col> */}
                        {/* <Col span={15} className="vmc">
                            <p className="font-family">VMC on AWS</p>
                            <p className="p-l-20">$ 39.2K</p>
                        </Col> */}
                        <Col span={3} className="total pull-right">
                            <p className="font-family">Total</p>
                            <p>$ 1.2M</p>
                        </Col>
                    </Row>
                </section>
        )
    }
}
Details.propTypes = {
    oppDetails: PropTypes.array
}
export default Details;
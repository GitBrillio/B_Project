import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button} from 'antd';
import './add-edit-growth-modal.scss';
import AddEditGrowthModalBlock from './AddEditGrowthModalBlock';

class AddEditGrowthModal extends Component {
  
    
    render = () => {
  
        const { visible,heading, okText,handleCancel,ambition,accountPlanId } = this.props
      
        return (<div className="add-edit-growth-group">
            <Modal
                className="add-edit-growth-popup"
                title={heading}
                visible={visible}
                centered
                onCancel={handleCancel}
                footer={[
                    <Button key="submit" type="primary" onClick={this.props.click}>
                        {okText} 
                    </Button>,
                ]}
            >
                <AddEditGrowthModalBlock 
                    actions={this.props.actions} 
                    ambition={this.props.ambition}
                    index= {this.props.index}
                    strategyReducer = {this.props.strategyReducer}
                    accountPlanId={this.props.accountPlanId}
                />
                <button className="col-lg-12 add-more plr0 disable-back" onClick={()=>this.props.actions.createAddmore(this.props.index)}>
                    + Add Another 
                </button>
            </Modal>
        </div>)
    }
}

AddEditGrowthModal.propTypes = {
    visible: PropTypes.bool.isRequired,
    ok: PropTypes.func,
    handleCancel: PropTypes.func, 
    okText: PropTypes.string,  
    heading:PropTypes.string,
    actions: PropTypes.object,
    strategyReducer: PropTypes.object,
    ambition: PropTypes.any,
    index: PropTypes.any,
    accountPlanId: PropTypes.string,
    click: PropTypes.any
}

export default AddEditGrowthModal;

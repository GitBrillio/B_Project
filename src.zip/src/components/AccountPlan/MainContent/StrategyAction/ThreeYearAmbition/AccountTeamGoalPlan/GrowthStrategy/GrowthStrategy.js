import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './growth-strategy.scss';
import AddEditGrowthModal from './AddEditGrowthModal/AddEditGrowthModal';
import { KMB } from '../../../../../../../Services/Common';

class GrowthStrategy extends Component {
    constructor(props) {
        super(props);
    }
    state = {
        growthModal: false,
        elScrollHeight: 0,
        elOffsetHeight: 0
    }
    growthModalCancel() {
        this.setState({
            growthModal: false
        });
        this.props.actions.resetAmbition(this.state.localAmbition,this.props.index);
    }
    componentWillReceiveProps() {
        try {
            let sh = document.getElementById('key-theme-sol-body-' + this.props.index).scrollHeight;
            this.setState({
                elScrollHeight: sh
            });
        }catch(e){}
       
    }
    postData(){
        this.setState({ growthModal: false });
        this.props.actions.submitAmbitionsGoalPlan(this.props.ambition,this.props.accountPlanId)
    }

    render() {
        const { line, ambition, index } = this.props
        return (
                
            <div className="position-relative">
                <div className="year-info-main" id={this.props.ambition.fiscalYear}>
                    <span className="year-info">FY{this.props.ambition.fiscalYear - 2000}</span>
                    {/* <svg height="120" width="300" className="svg-line-main">
                        <line x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2} className="svg-line" />
                       
                    </svg> */}
                </div>
                <div className="pull-right edit-bt-area">
                    <button className="edit-button" onClick={() => this.setState({ 
                        localAmbition: this.props.ambition,
                        growthModal: true 
                    })}>Edit</button>
                </div>
                <div className={this.props.border === "blue" ? "gutter-box key-theme-sol-main border-blue clear-both" : "gutter-box key-theme-sol-main border-grey clear-both"}>
                    
                    <div className="key-theme-sol">
                        {
                            ambition.ambitionPlan ? 
                                ambition.ambitionPlan.keyTheme
                                :
                                'Key theme / solution'
                            // !ambition.ambitionPlan.keyTheme ? 'Key theme / solution' : ambition.ambitionPlan.keyTheme
                        }
                        
                    </div>


                    <div className="key-theme-sol-body" style={{ height: this.props.size + "px" }}>
                        {this.props.ambition.ambitionPlan === null ?
                            <div className="btn-growth-strategy-main" style={{ height: this.props.size }}>
                                <div className="text-center btn-growth-strategy-sub">
                                    <button className="dashed-btn" type="dashed" onClick={() => this.setState({ growthModal: true })}>Add growth strategy</button>
                                </div>
                            </div> :

                            <div id={"key-theme-sol-body-" + index}>
                                <div className="money-main"><span className="money">
                                    {ambition.ambitionPlan &&
                                        "$" + KMB(ambition.ambitionPlan.targetValue)
                                    }
                                </span><span> (Target)</span></div>
                                <ul className="content">
                                    {ambition.ambitionPlan &&
                                        ambition.ambitionPlan.growthStrategy.map((g, i) => (
                                            <li key={i}>{g}</li>
                                        ))
                                    }

                                </ul>
                                {
                                    this.props.size <= this.state.elScrollHeight ?
                                        <button className="edit-button see-more" onClick={() => this.setState({ growthModal: true })}>See More…</button>
                                        :
                                        ""
                                }
                            </div>
                        }
                    </div>
                    <AddEditGrowthModal
                        actions={this.props.actions}
                        ambition={ambition}
                        index={this.props.index}
                        heading={"FY" + (this.props.ambition.fiscalYear - 2000) +"-  Add/Edit"}
                        visible={this.state.growthModal}
                        click = {()=>this.postData()}
                        ok={() => this.growthModalSave()}
                        okText="Save"
                        handleCancel={() => this.growthModalCancel()}
                        strategyReducer={this.props.strategyReducer}
                        accountPlanId={this.props.accountPlanId}
                    />
                </div>
            </div>
        )
    }
}

GrowthStrategy.propTypes = {
    size: PropTypes.string,
    border: PropTypes.string,
    actions: PropTypes.object,
    strategyReducer: PropTypes.object,
    index: PropTypes.any,
    ambition: PropTypes.any,
    line: PropTypes.any,
    accountPlanId: PropTypes.string
}


export default GrowthStrategy;

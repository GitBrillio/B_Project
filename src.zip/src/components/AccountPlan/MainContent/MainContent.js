import React,{Component} from 'react';
import PropTypes from "prop-types";
import './MainContent.scss';
import { Layout } from 'antd'; //Collapse

import LeftNavBar from '../LeftNavBar/LeftNavBar';
import CustomerProfile from './CustomerProfile/CustomerProfile';
import Footprint from './Footprint/Footprint';
import ITLandscape from './Footprint/ITLandscape/ITLandscape';
import FootPrintAndWhiteSpace from './Footprint/WhiteSpace/FootPrintAndWhiteSpace';
import KeyMetrics from './Footprint/KeyMetrics/KeyMetrics';
import ThreeYearAmbition from './StrategyAction/ThreeYearAmbition/ThreeYearAmbition';
import KeyOpportunities from './StrategyAction/KeyOpportunities/KeyOpportunities';
import BusinessITAlignment from './CustomerProfile/BusinessITAlignment/BusinessITAlignment';
import VMwareContracts from './Footprint/VMwareContracts/VMwareContracts';
// import StrategyAction from './StrategyAction/StrategyAction';
//const Panel = Collapse.Panel;

class MainContent extends Component {
    state = {
        currentTab: 'Overview' //ITLandscape
    }
    constructor(props) {
        super(props);
    }
    renderTab = () =>{
        switch(this.state.currentTab){
            case "Overview": {
                return <CustomerProfile 
                    overviewReducer={this.props.overviewReducer} 
                    actions={this.props.actions}
                    accountPlanId={this.props.accountPlanId}
                />;
            }
            case "VMwareBookings":{
                return <Footprint />;
            }
            case "ITLandscape":{
                return <ITLandscape 
                    footprintReducer={this.props.footprintReducer} 
                    actions={this.props.actions}
                    accountPlanId={this.props.accountPlanId}
                    keyMetricsReducer = {this.props.keyMetricsReducer}
                />
            }
            case "FootprintWhitespace": {
                return <FootPrintAndWhiteSpace 
                    footprintReducer={this.props.footprintReducer}
                    actions={this.props.actions}
                    accountPlanId={this.props.accountPlanId}
                />
            }
            case "KeyMetrics":{
                return <KeyMetrics 
                    keyMetricsReducer = {this.props.keyMetricsReducer}
                    accountPlanId={this.props.accountPlanId}
                    actions={this.props.actions}
                />;
            }
            case "VmwareContracts":{
                return <VMwareContracts />;
            }
            case '3yearAmbition':{
                return <ThreeYearAmbition 
                    accountPlanId={this.props.accountPlanId}
                    actions={this.props.actions}
                    strategyReducer = {this.props.strategyReducer}
                />
            }
            case 'KeyOpportunities':{
                return <KeyOpportunities 
                    actions={this.props.actions}
                    strategyReducer = {this.props.strategyReducer}
                    accountId = { this.props.accountId}
                />
            }
            case 'BusinessITAlignment':{
                return <BusinessITAlignment 
                    accountPlanId={this.props.accountPlanId} 
                    actions={this.props.actions} 
                    businessGoalReducer = {this.props.businessGoalReducer} />
            }
            default:{
                return null;
            }
        }
    }

    menuChange = (menu) =>{
        this.setState({
            currentTab: menu
        });
    }

    render(){
        return (
            <div className="main-content">
                <Layout className="gradient">
                    <LeftNavBar onMenuChange={this.menuChange}  />
                    {this.renderTab()}
                </Layout>
            </div>
        );
    }
};

MainContent.propTypes = {
    overviewReducer: PropTypes.object,
    keyMetricsReducer: PropTypes.object,
    strategyReducer:PropTypes.object,
    footprintReducer: PropTypes.object,
    actions: PropTypes.object,
    accountPlanId: PropTypes.string.isRequired,
    businessGoal:PropTypes.object,
    accountId:PropTypes.string
};

export default MainContent;
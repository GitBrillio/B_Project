import React, { Component } from 'react';
import PropTypes from "prop-types";
import HeaderInfo from '../common/HeaderInfo/HeaderInfo';
import TagInfo from '../common/TagInfo/TagInfo';
import MainContent from './MainContent/MainContent';

class AccountPlan extends Component {
    render = () => {
        return (
            <div>
                <HeaderInfo accounts={["Fujitsu", "New Account Plan"]} percent={"27"} status="Completed" />
                <TagInfo 
                    sectionTagTxt="Only show sections I’m tagged in" 
                    sectionTagChecked={false} 
                    commentTagTxt="Only show sections with comments"
                    commentTagChecked={false}
                />
                <MainContent 
                    overviewReducer={this.props.overviewReducer}
                    footprintReducer={this.props.footprintReducer} 
                    keyMetricsReducer={this.props.keyMetricsReducer}
                    strategyReducer={this.props.strategyReducer}
                    actions={this.props.actions} 
                    accountPlanId={this.props.match.params.accountPlanId}
                />
            </div>
        );
    }
}

AccountPlan.propTypes = {
    overviewReducer: PropTypes.object,
    keyMetricsReducer:PropTypes.object,
    strategyReducer:PropTypes.object,
    footprintReducer: PropTypes.object,
    actions: PropTypes.object,
    match: PropTypes.object
};


export default AccountPlan;
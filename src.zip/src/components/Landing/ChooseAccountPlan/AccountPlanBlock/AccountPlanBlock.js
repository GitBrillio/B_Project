import React, { Component } from 'react';
import PropTypes from "prop-types";
import { Tooltip, Progress } from 'antd';
import arrow from './DD.svg';
import {Link} from 'react-router-dom';

class AccountPlanBlock extends Component {
    render = () => {
        return (
            <Link className="account-plan-block-main" to={{ pathname: "/account-plan/"+this.props.planObj.accountPlanId, state: { accountId: this.props.planObj.accountId} }} >
                <div className="account-plan-block">
                    <div className="account-plan-name">{this.props.planObj.accountPlanName}</div>
                    <div className="account-plan-last-updated">
                        <span>Last Updated: </span>
                        <span>{this.props.lastUpdated}</span>
                    </div>
                    {
                        this.props.plan == "current" ?
                            <div className="account-plan-progress-bar">
                                <Tooltip title={this.props.progress + " %"}>
                                    <Progress percent={this.props.progress} size="small" />
                                </Tooltip>
                            </div>
                            : ""
                    }

                </div>

                <img
                    className="arrow"
                    src={arrow}
                    onClick={() => {
                    }}
                />
            </Link>
        )
    }
}

AccountPlanBlock.propTypes = {
    planName: PropTypes.string,
    lastUpdated: PropTypes.string,
    progress: PropTypes.string,
    plan: PropTypes.string,
    planObj: PropTypes.object
}

export default AccountPlanBlock;

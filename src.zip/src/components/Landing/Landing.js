import React, { Component } from 'react';
import './landing.scss';
import { Row, Col } from 'antd';
import Acconts from './Accounts/Accounts';
import EmptyPage from '../common/EmptyPage/EmptyPage';
import SnapTitle from './SnapTitle';
import NewAccountPlan from './NewAccountPlan/NewAccountPlan';
import ChooseAccountPlan from './ChooseAccountPlan/ChooseAccountPlan';

class Landing extends Component {
    constructor(){
        super();
        this.state = {
            createAccountPlan: false
        }
    }
    componentDidMount() {
        //accounts?salespersonId=bshirk@vmware.com.vmw&role=core_rep&geo=AMER&page=1&size=50&query=west
        this.props.actions.fetchAccounts({
            salespersonId: 'bshirk@vmware.com.vmw',
            role: 'core_rep',
            geo: 'AMER',
            page: 1,
            size: 50,
            query: 'west'
        })
    }
    selectAccount(){
        this.setState({
            createAccountPlan: false
        })
    }

    render = () => {
        const {accounts,selectedAccount,selectedAccountIndex,plans} = this.props.landing;
        const {actions} = this.props;
        return (
           
            <div className="landing">
                <Row gutter={4}>
                    <Col span={4}>
                        <Acconts 
                            accounts={accounts} 
                            selectedAccount={selectedAccount}
                            selectedAccountIndex={selectedAccountIndex}
                            actions={actions} 
                            selectAccount={this.selectAccount.bind(this)}
                        />
                    </Col>
                    <Col span={20}>
                        <div>
                            <div className="row">

                                <SnapTitle selectedAccount={selectedAccount} />
                            </div>
                            {
                                plans.length === 0 && !this.state.createAccountPlan  ?
                                    <EmptyPage
                                        className="vh-100"
                                        actions={

                                            [<button key="create-new-account-plan" onClick={() => this.setState({createAccountPlan: true })}
                                                className={"btn btn-primary"}>+ Create New Account Plan</button>]}
                                        message="<div><div>No Account Planned here! </div><div>Click the button below to create new Account Plan.</div></div>"
                                    />
                                    :
                                    this.state.createAccountPlan ?
                                        <NewAccountPlan 
                                            actions={actions}
                                            account={selectedAccount}
                                            history={this.props.history}
                                            handleAccountPlanCreation={(createAccountPlan)=>this.setState({createAccountPlan: createAccountPlan})}
                                        />
                                        :
                                        <ChooseAccountPlan
                                            plans={plans}
                                            actions={actions}
                                            account={selectedAccount}
                                            history={this.props.history}
                                            handleAccountPlanCreation={(createAccountPlan)=>this.setState({createAccountPlan: createAccountPlan})}
                                        />
                            }



                        </div>
                    </Col>
                </Row>
            </div>
        )
    }
}
export default Landing;
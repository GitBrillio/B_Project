import React,{ Component } from 'react';
import PropTypes from "prop-types";
import './NewAccountPlan.scss';
import Input from 'muicss/lib/react/input';
import VmSelect from '../VmSelect/VmSelect';
import axios from 'axios';
import Config from '../../../config/Config';
import { message } from 'antd';
const conf = new Config();

class NewAccountPlan extends Component{
    constructor(){
        super();
        this.state = {
            fiscalPeriod: null,
            accountPlanName: "",
            fiscalYear: "",
            fiscalPeriods: []
        }
    }
    componentDidMount(){
        axios.get(
            conf.capUrl + "/fiscaldetails"
        ).then(resp=>{
            this.setState({
                fiscalPeriod: resp.data.data,
                fiscalYear: resp.data.data.fiscalYear,
                fiscalPeriods: [
                    resp.data.data.fiscalYear,
                    resp.data.data.fiscalYear + 1
                ],
                accountPlanName: this.props.account.accountName + " FY-"+(parseInt(resp.data.data.fiscalYear)-2000)
            })
        })
    }

    selectChange(year){
        this.setState({
            fiscalYear: year
        })
    }

    // create account plan
    createPlan = () =>{
        const hide = message.loading("Creating account plan",0);
        axios({
            method: 'POST',
            url: conf.capUrl + "/accountplan",
            data: {
                accountId: this.props.account.accountId,
                accountPlanName: this.state.accountPlanName,
                currencyId: 1,
                clientFiscalYear: parseInt(this.state.fiscalYear),
                fiscalPeriod: this.state.fiscalPeriod
            }
        }).then((resp)=>{
            hide();
            this.props.history.push("/account-plan/"+resp.data.data.accountPlanId);
        }).catch(err=>{
            message.error("Error occured while creatinhg account plan");
        })
    }

    render = () =>{
        return(
            <div className={"new-account-plan"}> {/* vh-100 */}
                <div className="header">
                    <span className="text-center header-txt">Create New Account Plan</span>
                </div>
                <div className="body">
                    <div className="account-plan-name">
                        <Input 
                            label={"Account Plan Name"}
                            value={this.state.accountPlanName} 
                            floatingLabel={true} 
                        />
                    </div>
                    <div className="account-financial-period">
                        <VmSelect
                            placeholder={"Account's Current Fiscal Period"}
                            value={this.state.fiscalYear}
                            options={{
                                data: this.state.fiscalPeriods
                            }}
                            onChange={e => {
                                this.selectChange(e);
                            }}
                        />
                    </div>
                    
                    <div className="pull-right">
                        <button 
                            className="btn btn-primary cancel-btn"
                            onClick = {()=>this.props.handleAccountPlanCreation(false)}
                        >
                            Cancel
                        </button>
                        <button 
                            className="btn btn-primary create-btn" 
                            onClick = {()=>this.createPlan()}
                        >
                            Create
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

NewAccountPlan.propTypes = {
    actions: PropTypes.object,
    account: PropTypes.object,
    history: PropTypes.any
}

export default NewAccountPlan;

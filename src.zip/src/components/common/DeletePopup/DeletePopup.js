import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, Button } from 'antd';
import './delete-popup.scss';

const pt = {
    visible: PropTypes.bool.isRequired,
    ok: PropTypes.func,
    cancel: PropTypes.func, 
    okText: PropTypes.string, 
    cancelText: PropTypes.string, 
    heading:PropTypes.string,
    contents: PropTypes.string
}

class DeletePopup extends Component {

    

    render = () => {
        const { visible, ok, cancel, okText, cancelText, contents,heading } = this.props
        return (<div className="delete-popup-group">
            <Modal
                className="delete-popup"
                title={heading}
                visible={visible}
                onCancel={cancel}
                centered
                footer={[
                    <Button key="back" onClick={cancel}>{cancelText}</Button>, //Cancel, Keep it
                    <Button key="submit" type="primary" onClick={ok}>
                        {okText} 
                    </Button>, //Yes Delete it
                ]}
            >
                { contents }
            </Modal>
        </div>)
    }
}

DeletePopup.propTypes = pt;

export default DeletePopup;
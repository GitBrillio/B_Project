import React, { Component } from "react";
import {BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend} from 'recharts';
import "./StackedBarChrt.scss";
import PropTypes from "prop-types";


const propTypes = {
  width: PropTypes.number,
  barSize: PropTypes.number,
  data: PropTypes.array,
  xAxisLabel: PropTypes.string,
  yAxisLabel: PropTypes.string,
  barBackgound: PropTypes.object
};

export default class StackedBarChrt extends Component {
  render() {
    return (
      <BarChart width={this.props.width} height={300} data={this.props.data}  margin={{left: 20,bottom:15}}>
        <CartesianGrid strokeDasharray="0.5" vertical={false}/>
        <XAxis dataKey="name" label={{ value: this.props.xAxisLabel, position: 'insideBottom',offset:-12, fill: 'rgba(53,78,115,0.6)', fontSize: 11,fontFamily: "Metropolis"}} />
        <YAxis label={{ value: this.props.yAxisLabel, angle: -90, position: 'insideLeft',offset:-5, fill: 'rgba(53,78,115,0.6)', fontSize: 11,fontFamily: "Metropolis"}} />
        <Legend iconType="circle" iconSize="10" />
        {
          this.props.barBackgound.data.map((info, index) => (
              <Bar key={index} dataKey={info[0]} stackId="a" barSize={this.props.barSize} fill={info[1]} />
              
            ))
        }
      </BarChart>
    );
  }
}

StackedBarChrt.propTypes = propTypes;

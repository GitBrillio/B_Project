import React, { Component } from "react";
import {BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend} from 'recharts';
import "./StackedBarChrt.scss";
import PropTypes from "prop-types";
import CustomizedLabel from "./CustomizedLabel";


const propTypes = {
  width: PropTypes.number,
  barSize: PropTypes.number,
  data: PropTypes.array,
  xAxisLabel: PropTypes.string,
  yAxisLabel: PropTypes.string,
  barBackgound: PropTypes.object
};


export default class StackedBarChrt extends Component {
  render() {
  const arr = [...this.props.barBackgound.data]
    const data = arr.splice(0,this.props.barBackgound.data.length-1);
    return (
      <BarChart width={this.props.width} height={300} data={this.props.data}  margin={{left: 20,bottom:15}} >
        <CartesianGrid strokeDasharray="0.5" vertical={false}/>
        <XAxis dataKey="name" label={{ value: this.props.xAxisLabel, position: 'insideBottom',offset:-12, fill: 'rgba(53,78,115,0.6)', fontSize: 11,fontFamily: "Metropolis"}} />
        <YAxis label={{ value: this.props.yAxisLabel, angle: -90, position: 'insideLeft',offset:-5, fill: 'rgba(53,78,115,0.6)', fontSize: 11,fontFamily: "Metropolis"}} />
        <Legend iconType="circle" iconSize="10" verticalAlign="bottom" height={36} align="left"/>
        {
          
         data.map((info, index) => (
              <Bar key={index} dataKey={info[0]} stackId="a" barSize={this.props.barSize} fill={info[1]} />
            ))
           
        }
         <Bar dataKey={this.props.barBackgound.data[this.props.barBackgound.data.length-1][0]} stackId="a" barSize={this.props.barSize} fill={this.props.barBackgound.data[this.props.barBackgound.data.length-1][1]} legendType='circle' radius={[8,8,0,0]} label={<CustomizedLabel x={this.props.x} y={this.props.y} fill={this.props.fill} value={this.props.value}/>} />
      </BarChart>
    );
  }
}

StackedBarChrt.propTypes = propTypes;

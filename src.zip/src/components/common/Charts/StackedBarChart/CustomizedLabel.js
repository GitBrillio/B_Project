import React from "react";

const label = (props) =>{
    const {x, y, fill, value} = props;
    return <text 
            x={x} 
            y={y} 
            dy={-8} 
            fontSize='14' 
            fontFamily='Metropolis-SemiBold'
            fill={fill}
            textAnchor="middle">{value.toFixed(2)}</text>
}

export default label;
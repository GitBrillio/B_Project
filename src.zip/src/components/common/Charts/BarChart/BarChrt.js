import React, { Component } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import "./BarChrt.scss";
import PropTypes from "prop-types";
import _ from 'underscore';
import {cloneDeep} from 'lodash';
import KMB from "../CustomLabel/KMB";
const propTypes = {
  data: PropTypes.array,
  xAxisLabel: PropTypes.string,
  yAxisLabel: PropTypes.string,
  barBackgound: PropTypes.string
};

export default class BarChrt extends Component {

  convertData(arr,key){

    let convered = [];
    let arrs = cloneDeep(arr);
    _.each(arrs,(obj)=>{
      obj[key] = parseInt(obj[key]);
      convered.push(obj);
    });
    return convered;
  }

  KMB(labelValue) {

    // Nine Zeroes for Billions
    return Math.abs(Number(labelValue)) >= 1.0e+9

    ? Math.abs(Number(labelValue)) / 1.0e+9 + "B"
    // Six Zeroes for Millions 
    : Math.abs(Number(labelValue)) >= 1.0e+6

    ? Math.abs(Number(labelValue)) / 1.0e+6 + "M"
    // Three Zeroes for Thousands
    : Math.abs(Number(labelValue)) >= 1.0e+3

    ? Math.abs(Number(labelValue)) / 1.0e+3 + "K"

    : Math.abs(Number(labelValue));

}


  render() {
    return (
        <BarChart 
          width={400} 
          height={300} 
          data={this.convertData(this.props.data,this.props.dataValue)} 
          margin={{top: 5, right: 10, left: 20, bottom: 15}}>
            <CartesianGrid 
              strokeDasharray="0.5" 
              vertical={false} />
                <XAxis 
                  dataKey={"fiscalYear"}  //fiscalYear
                  label={{ value: this.props.xAxisLabel, position: 'insideBottom',offset:-12, fill: 'rgba(53,78,115,0.6)', fontSize: 11,fontFamily: "Metropolis"}}>
                </XAxis>
                <YAxis 
                  tickFormatter={(item)=> this.KMB(item) }
                  label={{ value: this.props.yAxisLabel, angle: -90, position: 'insideLeft',offset:-5, fill: 'rgba(53,78,115,0.6)', fontSize: 11,fontFamily: "Metropolis"}}/>
                <Bar 
                  dataKey={this.props.dataValue}  // financialValue
                  barSize={20}
                  fill={this.props.barBackgound} 
                  radius={[20,20,20,20]}/>
                />
                <Tooltip formatter={(e)=> this.KMB(e) } />
      </BarChart>
    );
  }
}

BarChart.propTypes = propTypes;

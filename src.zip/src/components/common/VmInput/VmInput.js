import React, { Component } from "react";
import { Input } from 'antd';
import "./VmInput.scss";
import PropTypes from "prop-types";


const propTypes = {
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
  value:PropTypes.any,
  type: PropTypes.string,
  onBlur: PropTypes.func,
  maxLength: PropTypes.any,
  max: PropTypes.number
};

export default class VmInput extends Component {
  render() {
    return (
            <Input 
                maxLength={this.props.maxLength}
                className = "input-input"
                placeholder={this.props.placeholder} 
                onChange={(e)=>{
                    if(typeof this.props.pattern !== 'undefined'){
                      let re = new RegExp(this.props.pattern);
                      if(re.test(e.target.value)){ // check pattern
                        if(typeof this.props.max !== 'undefined'){ // check max
                          if(parseFloat(Math.abs(e.target.value)) <= this.props.max){
                            this.props.onChange(e);
                          } else { // max fails
                            if(isNaN(parseFloat(e.target.value))){
                              this.props.onChange(e);
                            }else{
                              console.log(`It should be less than ${this.props.max}`)
                            }
                          }
                        } else{ // RegEx passes
                          this.props.onChange(e);
                        }
                        
                      }else{ // Regex fails
                        console.log("Validation fails!")
                      }
                    } else{ // RegEx not defined
                      this.props.onChange(e);
                    }
                }}
                value={this.props.value}
                onBlur={this.props.onBlur}
            />   
    );
  }
}

VmInput.propTypes = propTypes;

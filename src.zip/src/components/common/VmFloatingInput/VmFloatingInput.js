import React, { Component } from "react";
import "./VmFloatingInput.scss";
import PropTypes from "prop-types";

const propTypes = {
  type: PropTypes.string,
  name: PropTypes.string,
  placeholder: PropTypes.string,
  value: PropTypes.string
};

export default class VmFloatingInput extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const {
      name,
      placeholder,
      type,
      value,
      onChange,
      index,
      onBlur,
      maxLength
    } = this.props;


   
    return (
      <div className="vm-floating-label" >
        <input 
          onChange={(e)=>{
            if(typeof this.props.pattern !== 'undefined'){
              let re = new RegExp(this.props.pattern);
              if(re.test(e.target.value)){ // check pattern
                if(typeof this.props.max !== 'undefined'){ // check max
                  if(parseFloat(e.target.value) <= this.props.max){
                    this.props.onChange(e.target.value,index);
                  } else { // max fails
                    if(isNaN(parseFloat(e.target.value))){
                      this.props.onChange(e.target.value,index);
                    }else{
                      console.log(`It should be less than ${this.props.max}`)
                    }
                  }
                } else{ // RegEx passes
                  this.props.onChange(e.target.value,index);
                }
                
              }else{ // Regex fails
                console.log("Validation fails!")
              }
            } else{ // RegEx not defined
              this.props.onChange(e.target.value,index);
            }
        }}
          name={name} 
          value={value} 
          className= "input" 
          onBlur={onBlur}
          maxLength={maxLength}
          // placeholder={placeholder}
        />
        <span className="bar" />
        <label>{placeholder}</label>
      </div>
    );
  }
}

VmFloatingInput.propTypes = propTypes;

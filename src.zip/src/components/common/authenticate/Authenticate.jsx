import React, { Component } from "react";
import { PropTypes } from "prop-types"; //instanceOf
import Config from "../../../config/Config";
import qs from "query-string";
import axios from "axios";
import Cookies from "universal-cookie";
import moment from "moment";

const cookies = new Cookies();

class Authenticate extends Component {
  static propTypes = {
    user: PropTypes.any,
    location: PropTypes.any,
    history: PropTypes.any,
    actions: PropTypes.any
  };

  constructor() {
    super();
    this.config = new Config();
  }

  componentDidMount() {
    let url = this.props.location.search;
    let code = qs.parse(url).code;
    let _this = this;

    axios({
      method: this.config.ssoUrl.method,
      url: this.config.ssoUrl.url,
      data: {
        codeType: "ACCESS_TOKEN",
        code: code,
        redirectUrl: this.config.oauth.redirect_uri,
        headers:{
            "Content-Type":"application/json"
        },
        timeout: 10000
      }
      //headers: this.config.getToken.headers
    }).then(
      (resp) => {
        cookies.set("session_status", "logged_in", { path: "/" });
        let respObj = resp.data;
        let arr = respObj.access_token.split(".");
        let obj = JSON.parse(atob(arr[1]));
        _this.props.actions.getUser(obj.eml);
        axios.defaults.headers.common["Authorization"] =
          "Bearer " + respObj.access_token;
        _this.props.actions.setUserName(obj.eml); //obj.email
        let date = moment(new Date()).add(respObj.expires_in, "seconds");
        let CookieObj = {
          username: obj.eml,
          loggedIn: true,
          expires_in: date,
          access_token: respObj.access_token,
          refresh_token: respObj.refresh_token,
          id_token: respObj.id_token
        };
        cookies.set("session", JSON.stringify(CookieObj), { path: "/" });
        let prevUrl = cookies.get("url");
        if(prevUrl && prevUrl.length > 0 ){
          cookies.set("url","",{ path: "/" });
          setTimeout(()=>{
            window.location.href = prevUrl;
          },10);
        }else{
          _this.props.history.push("/home");
        }

      }
    );
  }

  render = () => {
    return (
      <div>
        <h3>Authenticating....</h3>
      </div>
    );
  };
}

export default Authenticate; //withCookies()

import React from 'react';
import { Link } from 'react-router-dom';
import EmptyPage from '../components/common/EmptyPage/EmptyPage';
const NotFoundPage = () => {
  return (
    <div>
      <EmptyPage
        message="404 Page not found"
        actions={
          [
            <Link key="go-back" to="/home">Go Back</Link>
          ]
        }
      />
    </div>
  );
};

export default NotFoundPage;

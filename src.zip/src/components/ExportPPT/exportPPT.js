import React, {Component} from 'react';

export default class ExportPPT extends Component{
    render = () =>{
        return (
            <button className="export-button">Export</button>
        )
    }
}
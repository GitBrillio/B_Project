import React, { Component } from "react";
import "./home.scss";
import PropTypes from "prop-types";
import Config from "../../config/Config.js";

class Home extends Component {
  called = false;
  constructor() {
    super();
    this.config = new Config();
  }
  componentWillReceiveProps() {

  }



  render() {
    return (
      <div className="container-fluid home">

      </div>
    );
  }
}

Home.propTypes = {
  landingReducer: PropTypes.any,
  actions: PropTypes.any,
  userReducer: PropTypes.any
};

export default Home;

import { combineReducers } from 'redux';
import { user } from './userReducer';
import { overview } from './overviewReducer';
import { footprint } from './footprintReducer';
import { keyMetrics } from './keyMetricsReducer';
import { strategy } from './strategyReducer';

const rootReducer = combineReducers({
    user,
    overview,
    footprint,
    keyMetrics,
    strategy
});

export default rootReducer;

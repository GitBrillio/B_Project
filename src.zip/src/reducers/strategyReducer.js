import { cloneDeep } from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/strategy.json'
import _ from 'underscore';
import { ConfigConsumer } from 'antd/lib/config-provider';

export const strategy = (state = initialState, action = {}) => {
    let newState = {};
    switch (action.type) {
        // case types.CHANGE_KEY_THEME_FIELD: {
        //     newState = cloneDeep(state);
        //     newState.keyMetrics = action.payload;
        //     return newState;
        // }
        case types.CHANGE_KEY_THEME_FIELD: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload.index].ambitionPlan === null) {
                newState.threeYearAmbition[action.payload.index].ambitionPlan = { keyTheme: "", targetValue: "", growthStrategy: [""] };
            }
            newState.threeYearAmbition[action.payload.index].ambitionPlan.keyTheme = action.payload.value
            return newState;
        }
        case types.CHANGE_TARGET_VALUE_FIELD: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload.index].ambitionPlan === null) {
                newState.threeYearAmbition[action.payload.index].ambitionPlan = { keyTheme: "", targetValue: "", growthStrategy: [""] };
            }
            newState.threeYearAmbition[action.payload.index].ambitionPlan.targetValue = action.payload.value
            return newState;
        }
        case types.CHANGE_GROWTH_STRATEGY_FIELD: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload.index].ambitionPlan === null) {
                newState.threeYearAmbition[action.payload.index].ambitionPlan = { keyTheme: "", targetValue: "", growthStrategy: [""] };
            }
            newState.threeYearAmbition[action.payload.index].ambitionPlan.growthStrategy[action.payload.growth_index] = action.payload.value
            return newState;
        }

        case types.FETCH_THREE_YEAR_AMBITION: {
            newState = cloneDeep(state);
            newState.threeYearAmbition = action.payload;
            return newState;
        }

        case types.FETCH_AMBITION_GOAL_PLAN: {
            newState = cloneDeep(state);
            newState.goalPlan = action.payload.teamGoal;
            newState.accountTeamGoalId = action.payload.accountTeamGoalId;
            return newState;
        }
        case types.SET_TEAM_GOAL_ID: {
            newState = cloneDeep(state);
            newState.accountTeamGoalId = action.payload;
            return newState;
        }

        // case types.SUBMIT_AMBITION_GOAL_PLAN:{
        //     newState = cloneDeep(state);
        //     //newState.threeYearAmbition = action.payload;
        //     console.log(action.payload);
        //     return newState;
        // }
        case types.POST_AMBITION_GOAL_PLAN: {
            newState = cloneDeep(state);
            newState.threeYearAmbition = action.payload;
            return newState;
        }
        case types.ADD_MORE: {
            newState = cloneDeep(state);
            if (newState.threeYearAmbition[action.payload].ambitionPlan == null) {
                newState.threeYearAmbition[action.payload].ambitionPlan = {
                    growthStrategy: []
                }
            }
            newState.threeYearAmbition[action.payload].ambitionPlan.growthStrategy.push("");
            return newState;

        }
        case types.DELETE_ELEMENT: {
            newState = cloneDeep(state);
            newState.threeYearAmbition[action.payload.index].ambitionPlan.growthStrategy.splice(action.payload.growth_index, 1);
            return newState;
        }

        case types.DELETE_GOAL_ELEMENT: {
            newState = cloneDeep(state);
            newState.goalPlan.splice(action.payload, 1);
            return newState;
        }

        case types.ADD_MORE_GOAL: {
            newState = cloneDeep(state);
            newState.goalPlan.push("");
            return newState;
        }

        case types.ADD_TEAM_GOAL_DATA: {
            newState = cloneDeep(state);
            newState.goalPlan.accountTeamGoalId = "";

            return newState;
        }

        case types.ADD_GOAL_VALUE: {
            newState = cloneDeep(state);
            newState.goalPlan.teamGoal.push("");
            newState.goalPlan.accountTeamGoalId = null;
            return newState;
        }
        case types.CHANGE_GOAL_VALUE: {
            newState = cloneDeep(state);
            newState.goalPlan[action.payload.index] = action.payload.value;
            return newState;
        }

        case types.RESET_AMBITION:{
            newState = cloneDeep(state);
            newState.threeYearAmbition[action.payload.index] = action.payload.ambition;
            return newState;
        }

        default: {
            return state;
        }
    }
}
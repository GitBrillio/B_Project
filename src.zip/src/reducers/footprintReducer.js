import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/footprint.json'
import _ from 'underscore';

export const footprint = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.FETCH_DATA: {
            newState = cloneDeep(state);
            newState[action.payload.key] = action.payload.data;
            return newState;
        }
        case types.PUSH_SYSTEM:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems.push(action.payload.data)
            } else {
                newState.itSystems.push(action.payload.data)
            }
            return newState;
        }
        case types.PUSH_PROVIDER:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.index].providerInfo.push(action.payload.data)
            } else {
                newState.itSystems[action.payload.index].providerInfo.push(action.payload.data)
            }
            return newState;
        }
        case types.DELETE_PROVIDER:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.systemIndex].providerInfo.splice(action.payload.providerIndex,1)
            } else {
                newState.itSystems[action.payload.systemIndex].providerInfo.splice(action.payload.providerIndex,1)
            }
            return newState;
        }
        case types.DELETE_SYSTEM:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems.splice(action.payload.index,1)
            } else {
                newState.itSystems.splice(action.payload.index,1)
            }
            return newState;
        }

        case types.CHANGE_SYSTEM_FIELD:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.index].landscape.landscapeName = action.payload.value
            } else {
                newState.itSystems[action.payload.index].landscape.landscapeName = action.payload.value
            }
            return newState;
        }

        case types.CHANGE_PROVIDER_FIELD:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.systemIndex].providerInfo[action.payload.providerIndex][action.payload.key] = action.payload.value
            } else {
                newState.itSystems[action.payload.systemIndex].providerInfo[action.payload.providerIndex][action.payload.key] = action.payload.value
            }
            return newState;
        }

        case types.UPDATE_SYSTEM:{
            newState = cloneDeep(state);
            if(action.payload.type === 'MISSION_CRITICAL_SYSTEM'){
                newState.missionCriticalSystems[action.payload.index] = action.payload.data
            } else {
                newState.itSystems[action.payload.index] = action.payload.data
            }
            return newState;
        }
        
        
        case types.GET_FOOT_PRINT:{
            let newState = {};
            switch(action.type) {
                case types.GET_FOOT_PRINT : {
                    newState = {...state}
                    newState.footPrintAndWhiteSpace = action.payload;
                    return newState;
                }
                default: {
                    return state;
                }
            }
        }

        default:{
            return state;
        }
    }
}
import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/overview.json'
import _ from 'underscore';

export const overview = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.FETCH_GOALS: {
            newState = cloneDeep(state);
            newState.goals = action.payload;
            return newState;
        }
        case types.PUSH_NEW_GOAL:{
            newState = cloneDeep(state);
            newState.goals.push({
                goalValue: "",
                accountPlanId: action.payload
            });
            return newState;
        }
        case types.FETCH_ISSUES:{
            newState = cloneDeep(state);
            newState.issues = action.payload;
            return newState;
        }
        case types.PUSH_NEW_ISSUE:{
            newState = cloneDeep(state);
            newState.issues.push({
                issueValue: "",
                accountPlanId: action.payload
            });
            return newState;
        }

        case types.FETCH_LOOKUP_DATA:{
            newState = cloneDeep(state);
            newState[action.payload.reference] = action.payload.data;
            return newState;
        }

        case types.FETCH_KEY_DETAILS:{
            newState = cloneDeep(state);
            newState.keyDetails = action.payload;
            return newState;
        }

        case types.CHANGE_OVERVIEW_KEY:{
            newState = cloneDeep(state);
            newState[action.payload.topKey][action.payload.key] = action.payload.value;
            return newState;
        }

        case types.FETCH_VISION_STRATEGY :{
            newState = cloneDeep(state);
            newState.visionStrategy = action.payload;
            return newState;
        }

        case types.FETCH_KEY_FINENCIALS :{
            newState = cloneDeep(state);
            newState.keyFinencials = action.payload;
            return newState;
        }

        case types.UPDATE_FINENECE_FIELD: {
            newState = cloneDeep(state);
            let theIndex = _.findIndex(newState.keyFinencials,(o)=>{
                return o.id === action.payload.id
            });
            newState.keyFinencials[theIndex].financialValue = action.payload.value;
            return newState;
        }

        case types.FETCH_BUSINESS_PORTFOLIO :{
            newState = cloneDeep(state);
            newState.businessPortfolio = action.payload;
            return newState;
        }

        case types.CHANGE_PORTFOLIO_LABEL:{
            newState = cloneDeep(state);
            newState.businessPortfolio[action.payload.index].portfolio.portfolioLabel = action.payload.data;
            return newState;
        }

        case types.CHANGE_PORTFOLIO_VALUE:{
            newState = cloneDeep(state);
            newState.businessPortfolio[action.payload.index].portfolio.portfolioValue = action.payload.data;
            return newState;
        }

        case types.UPDATE_PORTFOLIO_OBJ:{
            newState = cloneDeep(state);
            newState.businessPortfolio[action.payload.index].label = action.payload.label;
            return newState;
        }

        case types.PUSH_PORTFOLIO :{
            newState = cloneDeep(state);
            newState.businessPortfolio.push(action.payload);
            return newState;
        }

        case types.DELETE_PORTFOLIO: {
            newState = cloneDeep(state);
            newState.businessPortfolio.splice(action.payload,1);
            return newState
        }

        case types.FETCH_SEGMENT_GROWTH: {
            newState = cloneDeep(state);
            newState.segmentGrowth = action.payload;
            return newState
        }

        case types.UPDATE_SEGMENT_VALUE :{
            newState = cloneDeep(state);
            newState.businessPortfolio[action.payload.pIndex].segmentGrowth[action.payload.index].segmentGrowthValue = action.payload.val;
            return newState;
        }

        case types.UPDATE_SEGMENT:{
            newState = cloneDeep(state);
            newState.segmentGrowth[action.payload.index] = action.payload.obj;
            return newState;
        }
        
        
        default:{
            return state
        }
    }
}
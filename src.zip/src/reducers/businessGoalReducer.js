import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/strategy.json'
import _ from 'underscore';
import { ConfigConsumer } from 'antd/lib/config-provider';

export const strategy = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){

        case types.ADD_BUSINESS_DATA:{
            newState = cloneDeep(state);
            return newState;
        }

     }
}
import {cloneDeep} from 'lodash';
import * as types from '../constants/actionTypes';
import initialState from '../constants/initialState/business.json'
import _ from 'underscore';
import { ConfigConsumer } from 'antd/lib/config-provider';

export const businessGoal = ( state = initialState, action = {}) =>{
    let newState = {};
    switch(action.type){
        case types.GET_BUSINESS_GOALS: {
            newState = cloneDeep(state);
            newState.businessGoals = action.payload;
            return newState;
        }
        case types.GET_BUSINESS_INITIATIVES: {

            newState = cloneDeep(state);
            newState.businessInitiative = action.payload;
            console.log('new state', newState);
            return newState;
        }
        case types.GET_IT_INITIATIVES: {
            newState = cloneDeep(state);
            newState.ItInitiative = action.payload;
            return newState;
        }
        case types.GET_VMWARE_INITIATIVES: {
            newState = cloneDeep(state);
            newState.VMwareInitiative = action.payload;
            return newState;
        }
        case types.ADD_BUSINESS_DATA: {
            newState = cloneDeep(state);
            return newState;
        }
        default:{
            return state;
        }
     }
}